'use client';

import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100 font-bengali-sans p-4">
      <div className="text-center max-w-md">
        <h1 className="text-4xl font-bold text-indigo-400 mb-2">404</h1>
        <h2 className="text-xl font-semibold mb-4">পৃষ্ঠাটি পাওয়া যায়নি</h2>
        <p className="text-sm text-slate-400 mb-6">
          আপনি যে পৃষ্ঠাটি খুঁজছেন তা মুছে ফেলা হয়েছে অথবা ভুল ইউআরএল ব্যবহার করা হয়েছে।
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-4 py-2 rounded-lg text-sm transition-colors"
        >
          হোম পেজে ফিরে যান
        </Link>
      </div>
    </div>
  );
}
