import { NextRequest, NextResponse } from 'next/server';
import { executeAIAction, type AIAction } from '@/src/lib/gemini-service';
import { smartCleanAIPaste } from '@/src/lib/text-normalizer';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = (body.action || 'format') as AIAction;
    const rawText = String(body.text || '');
    const categories = Array.isArray(body.categories) ? body.categories : [];
    const noteTitle = body.noteTitle ? String(body.noteTitle) : undefined;

    if (!rawText.trim() && action !== 'auto_categorize') {
      return NextResponse.json(
        { error: 'প্রক্রিয়াকরণের জন্য কোনো টেক্সট পাওয়া যায়নি।' },
        { status: 400 }
      );
    }

    const cleanedInput = smartCleanAIPaste(rawText);

    const outcome = await executeAIAction({
      action,
      text: cleanedInput,
      categories,
      noteTitle,
    });

    if (!outcome.success) {
      return NextResponse.json({ error: outcome.error || 'AI generation failed' }, { status: 500 });
    }

    return NextResponse.json({
      result: outcome.result,
      suggestedCategory: outcome.suggestedCategory,
    });
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : 'এআই সংযোগে সাময়িক সমস্যা হয়েছে।';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
