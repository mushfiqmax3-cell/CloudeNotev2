import type { Metadata, Viewport } from 'next';
import './globals.css';
import { THEME_INIT_SCRIPT } from '../src/lib/theme';
import { ServiceWorkerRegister } from '../src/components/ServiceWorkerRegister';

export const metadata: Metadata = {
  applicationName: 'Cloud Note',
  title: 'Cloud Note - ক্লাউড নোট',
  manifest: '/manifest.json',
  icons: {
    icon: [
      { url: '/icon.svg', type: 'image/svg+xml' },
      { url: '/icon-192.png', sizes: '192x192', type: 'image/png' },
    ],
    apple: [{ url: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' }],
  },
  appleWebApp: {
    capable: true,
    title: 'Cloud Note',
    statusBarStyle: 'default',
  },
  formatDetection: { telephone: false },
  description:
    'আধুনিক বাংলা ও ইউনিভার্সাল ইউনিকোড ক্লাউড নোটবুক, আনলিমিটেড স্টোরেজ, গণিত/ল্যাটেক্স সাপোর্ট এবং এআই রাইটিং অ্যাসিস্ট্যান্ট।',
  openGraph: {
    title: 'Cloud Note - ক্লাউড নোট',
    description:
      'আধুনিক বাংলা ও ইউনিভার্সাল ইউনিকোড ক্লাউড নোটবুক, আনলিমিটেড স্টোরেজ, গণিত/ল্যাটেক্স সাপোর্ট এবং এআই রাইটিং অ্যাসিস্ট্যান্ট।',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Cloud Note - ক্লাউড নোট',
    description:
      'আধুনিক বাংলা ও ইউনিভার্সাল ইউনিকোড ক্লাউড নোটবুক, আনলিমিটেড স্টোরেজ, গণিত/ল্যাটেক্স সাপোর্ট এবং এআই রাইটিং অ্যাসিস্ট্যান্ট।',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#4f46e5',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT_SCRIPT }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=JetBrains+Mono:ital,wght@0,400;0,500;0,600;1,400&family=Noto+Sans:wght@400;500;600;700&family=Noto+Sans+Arabic:wght@400;500;600;700&family=Noto+Sans+Bengali:wght@400;500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600;700&family=Noto+Sans+Math&family=Noto+Sans+Symbols+2&family=Noto+Serif+Bengali:wght@400;500;600;700&family=Tiro+Bangla:ital@0;1&display=swap"
          rel="stylesheet"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css"
          crossOrigin="anonymous"
        />
      </head>
      <body
        suppressHydrationWarning
        className="font-bengali-sans bg-slate-50 text-slate-900 antialiased selection:bg-indigo-600 selection:text-white"
      >
        {children}
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
