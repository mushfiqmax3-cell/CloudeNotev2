'use client';

import { useEffect } from 'react';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error('Unhandled app error:', error);
  }, [error]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100 font-bengali-sans p-4">
      <div className="text-center max-w-md">
        <h1 className="text-2xl font-bold text-rose-400 mb-2">সাময়িক সমস্যা দেখা দিয়েছে</h1>
        <p className="text-sm text-slate-400 mb-6">
          অ্যাপ্লিকেশনে একটি অপ্রত্যাশিত সমস্যা হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।
        </p>
        <button
          onClick={() => reset()}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-4 py-2 rounded-lg text-sm transition-colors"
        >
          পুনরায় চেষ্টা করুন
        </button>
      </div>
    </div>
  );
}
