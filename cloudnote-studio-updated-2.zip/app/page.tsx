'use client';

import dynamic from 'next/dynamic';

const CloudNoteApp = dynamic(() => import('@/src/App'), {
  ssr: false,
  loading: () => (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 font-bengali-sans">
      <div className="flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-slate-500 font-medium">ক্লাউড নোট লোড হচ্ছে...</p>
      </div>
    </div>
  ),
});

export default function HomePage() {
  return <CloudNoteApp />;
}
