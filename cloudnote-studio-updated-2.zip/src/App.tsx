'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  BookOpen,
  Plus,
  Star,
  Trash2,
  Folder,
  FileText,
  Menu,
  X,
  Cloud,
  RefreshCw,
  Pin,
  FolderPlus,
} from 'lucide-react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { auth, isFirebaseConfigured } from './lib/firebase';
import type {
  CategoryItem,
  CloudSyncState,
  NoteItem,
  NoteVersionSnapshot,
  UserProfile,
} from './lib/types';
import {
  loadNotesWithChunkReassembly,
  saveNoteWithChunking,
  permanentlyDeleteNote,
  loadPersistedSessionUser,
  savePersistedSessionUser,
  syncAllNotesWithCloud,
  subscribeToUserNotes,
  hydrateNoteInMemory,
  DEFAULT_CATEGORY_ITEMS,
  loadUserCategories,
  saveUserCategories,
} from './lib/storage';
import { NoteReaderView } from './components/NoteReaderView';
import { NoteEditor } from './components/NoteEditor';
import { RecentNotesView } from './components/RecentNotesView';
import { ReadingModeModal } from './components/ReadingModeModal';
import { AuthModal } from './components/AuthModal';
import { LoginScreen } from './components/LoginScreen';
import { UserProfileSection } from './components/UserProfileSection';
import { PWAInstallButton } from './components/PWAInstallButton';
import { ThemeSwitcher } from './components/ThemeSwitcher';
import { UserProfileModal } from './components/UserProfileModal';
import { applyTheme, loadSavedTheme, type ThemeId } from './lib/theme';
import { PinLockModal } from './components/PinLockModal';
import { CreateCategoryModal } from './components/CreateCategoryModal';

const GUEST_USER: UserProfile = {
  uid: 'local-studio-user',
  email: 'studio@cloudnote.local',
  displayName: 'ক্লাউডনোট স্টুডিও',
  isLocalMode: true,
  authProvider: 'guest',
};

export const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile>(() => {
    if (typeof window !== 'undefined') {
      const persisted = loadPersistedSessionUser();
      if (persisted) return persisted;
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return GUEST_USER;
    }
    return GUEST_USER;
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const persisted = loadPersistedSessionUser();
      if (persisted) return true;
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return true;
    }
    return false;
  });
  const [authReady, setAuthReady] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      if (loadPersistedSessionUser()) return true;
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return true;
    }
    return !isFirebaseConfigured || !auth;
  });
  const [syncState, setSyncState] = useState<CloudSyncState>('synced');

  const [allNotes, setAllNotes] = useState<NoteItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Theme State (Light, Dark, Sepia, Midnight/OLED, Forest, Paper) - persisted in localStorage
  const [theme, setTheme] = useState<ThemeId>(() => loadSavedTheme());

  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);

  // Dynamic Custom Categories State
  const [customCategories, setCustomCategories] = useState<CategoryItem[]>(DEFAULT_CATEGORY_ITEMS);
  const [isCreateCategoryOpen, setIsCreateCategoryOpen] = useState<boolean>(false);

  // Navigation & Workspace State
  const [activeNav, setActiveNav] = useState<'all' | 'favorites' | 'trash' | 'category'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editingNote, setEditingNote] = useState<NoteItem | null>(null);
  const [isReadingModeOpen, setIsReadingModeOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  // PIN Lock State
  const [unlockedNoteIds, setUnlockedNoteIds] = useState<Set<string>>(() => new Set());
  const [pinModalState, setPinModalState] = useState<{
    isOpen: boolean;
    mode: 'set' | 'unlock' | 'manage';
    targetNote: NoteItem | null;
    onVerifiedAction?: (note: NoteItem) => void;
  }>({
    isOpen: false,
    mode: 'unlock',
    targetNote: null,
  });

  // Apply the selected theme on root html (data-theme + dark class) and persist it
  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  // Load saved (custom) categories once per account
  useEffect(() => {
    let cancelled = false;
    loadUserCategories(user.uid).then((saved) => {
      if (!cancelled) setCustomCategories(saved);
    });
    return () => {
      cancelled = true;
    };
  }, [user.uid]);

  // Final list = saved categories + any category discovered from existing notes
  const userCategories = useMemo<CategoryItem[]>(() => {
    const names = new Set(customCategories.map((c) => c.name.trim().toLowerCase()));
    const discovered: CategoryItem[] = [];
    for (const n of allNotes) {
      const name = (n.category || '').trim();
      if (name && !names.has(name.toLowerCase())) {
        discovered.push({
          id: `cat-disc-${name.toLowerCase()}`,
          name,
          color: '#6366f1',
        });
        names.add(name.toLowerCase());
      }
    }
    return [...customCategories, ...discovered];
  }, [customCategories, allNotes]);

  // Firebase Auth Listener
  useEffect(() => {
    if (!isFirebaseConfigured || !auth) {
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        const fbProfile: UserProfile = {
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName || fbUser.email?.split('@')[0] || 'ব্যবহারকারী',
          photoURL: fbUser.photoURL,
          isLocalMode: false,
          authProvider: 'firebase-email',
          lastSyncedAt: new Date().toISOString(),
        };
        setUser(fbProfile);
        savePersistedSessionUser(fbProfile);
        setIsAuthenticated(true);
      }
      setAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  // Load all notes & attach real-time Firestore listener when user is authenticated
  useEffect(() => {
    if (!isAuthenticated) return;
    let mounted = true;

    const fetchNotes = async () => {
      try {
        const loaded = await loadNotesWithChunkReassembly(user.uid);
        if (mounted) {
          setAllNotes(loaded);
          setSyncState('synced');
          setIsLoading(false);
        }
      } catch {
        if (mounted) {
          setSyncState('offline-vault');
          setIsLoading(false);
        }
      }
    };

    void fetchNotes();

    const unsubRealtime = subscribeToUserNotes(user.uid, (liveNotes) => {
      if (mounted) {
        setAllNotes(liveNotes);
        setSyncState('synced');
      }
    });

    return () => {
      mounted = false;
      if (unsubRealtime) {
        unsubRealtime();
      }
    };
  }, [isAuthenticated, user.uid]);

  // Derived Active Notes & Counters
  const activeNotes = useMemo(
    () => allNotes.filter((n) => !Boolean(n.isDeleted)),
    [allNotes]
  );

  const favoriteNotesCount = useMemo(
    () => activeNotes.filter((n) => Boolean(n.isFavorite)).length,
    [activeNotes]
  );

  const trashedNotesCount = useMemo(
    () => allNotes.filter((n) => Boolean(n.isDeleted)).length,
    [allNotes]
  );

  // Filtered Notes with Pin-to-top sorting & category match
  const filteredNotes = useMemo(() => {
    const baseList =
      activeNav === 'trash'
        ? allNotes.filter((n) => Boolean(n.isDeleted))
        : activeNav === 'favorites'
          ? activeNotes.filter((n) => Boolean(n.isFavorite))
          : activeNav === 'category' && selectedCategory
            ? activeNotes.filter(
                (n) =>
                  (n.category || '').trim().toLowerCase() ===
                  selectedCategory.trim().toLowerCase()
              )
            : activeNotes;

    const q = searchQuery.trim().toLowerCase();
    if (!q) return baseList;

    return baseList.filter((n) => {
      const inTitle = (n.title || '').toLowerCase().includes(q);
      const inCat = (n.category || '').toLowerCase().includes(q);
      const inSubCat = (n.subCategory || '').toLowerCase().includes(q);
      const inTags = (n.tags || []).some((t) => t.toLowerCase().includes(q));
      const isPinLockedAndClosed = Boolean(n.pinHash) && !unlockedNoteIds.has(n.id);
      const inContent = !isPinLockedAndClosed && (n.content || '').toLowerCase().includes(q);
      return inTitle || inCat || inSubCat || inTags || inContent;
    });
  }, [activeNav, allNotes, activeNotes, selectedCategory, searchQuery, unlockedNoteIds]);

  const selectedNote = useMemo(
    () => allNotes.find((n) => n.id === selectedNoteId) || null,
    [allNotes, selectedNoteId]
  );

  const handlePersistNote = useCallback(
    async (noteToSave: NoteItem) => {
      setSyncState('syncing');
      const saved = await saveNoteWithChunking(noteToSave, user.uid);
      setAllNotes((prev) => {
        const exists = prev.some((n) => n.id === saved.id);
        const updated = exists
          ? prev.map((n) => (n.id === saved.id ? saved : n))
          : [saved, ...prev];
        return updated.sort((a, b) => {
          const aPinned = Boolean(a.isPinned);
          const bPinned = Boolean(b.isPinned);
          if (aPinned && !bPinned) return -1;
          if (!aPinned && bPinned) return 1;
          return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
        });
      });
      setSyncState('synced');
      return saved;
    },
    [user.uid]
  );

  const handleCreateCategory = async (newCat: CategoryItem) => {
    const updated = [...customCategories, newCat];
    setCustomCategories(updated);
    await saveUserCategories(user.uid, updated);
    setSelectedCategory(newCat.name);
    setActiveNav('category');
  };

  // Called from the note editor's folder picker
  const handleCreateCategoryByName = async (name: string): Promise<string> => {
    const trimmed = name.trim();
    if (!trimmed) return '';
    const existing = userCategories.find((c) => c.name.toLowerCase() === trimmed.toLowerCase());
    if (existing) return existing.name;
    const newCat: CategoryItem = {
      id: `cat-${Date.now()}`,
      name: trimmed,
      color: '#6366f1',
      createdAt: new Date().toISOString(),
    };
    const updated = [...customCategories, newCat];
    setCustomCategories(updated);
    await saveUserCategories(user.uid, updated);
    return newCat.name;
  };

  const handleSaveFromEditor = async (noteData: NoteItem) => {
    const saved = await handlePersistNote(noteData);
    setIsEditing(false);
    setEditingNote(null);
    setSelectedNoteId(saved.id);
  };

  const handleSelectNoteCard = (note: NoteItem) => {
    if (note.pinHash && !unlockedNoteIds.has(note.id)) {
      setPinModalState({
        isOpen: true,
        mode: 'unlock',
        targetNote: note,
        onVerifiedAction: (unlockedNote) => {
          setUnlockedNoteIds((prev) => new Set(prev).add(unlockedNote.id));
          setSelectedNoteId(unlockedNote.id);
          setIsEditing(false);
        },
      });
      return;
    }
    setSelectedNoteId(note.id);
    setIsEditing(false);
  };

  const handleTogglePin = async (note: NoteItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    await handlePersistNote({
      ...note,
      isPinned: !note.isPinned,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleChangeNoteColor = async (note: NoteItem, color: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    await handlePersistNote({
      ...note,
      color: color || undefined,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleToggleFavorite = async (note: NoteItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    await handlePersistNote({
      ...note,
      isFavorite: !note.isFavorite,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleSoftDelete = async (note: NoteItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    await handlePersistNote({
      ...note,
      isDeleted: true,
      deletedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    if (selectedNoteId === note.id) {
      setSelectedNoteId(null);
    }
  };

  const handleRestoreFromTrash = async (note: NoteItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    await handlePersistNote({
      ...note,
      isDeleted: false,
      deletedAt: null,
      updatedAt: new Date().toISOString(),
    });
  };

  const handlePermanentDelete = async (noteId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    await permanentlyDeleteNote(noteId, user.uid);
    setAllNotes((prev) => prev.filter((n) => n.id !== noteId));
    if (selectedNoteId === noteId) {
      setSelectedNoteId(null);
    }
  };

  const handleEmptyTrash = async () => {
    const trashed = allNotes.filter((n) => Boolean(n.isDeleted));
    for (const item of trashed) {
      await permanentlyDeleteNote(item.id, user.uid);
    }
    setAllNotes((prev) => prev.filter((n) => !Boolean(n.isDeleted)));
    setSelectedNoteId(null);
  };

  const handleStartNewNote = () => {
    setEditingNote(null);
    setSelectedNoteId(null);
    setIsEditing(true);
    setSidebarOpen(false);
  };

  const handleLogout = async () => {
    if (isFirebaseConfigured && auth) {
      try {
        await signOut(auth);
      } catch {
        // Ignore
      }
    }
    savePersistedSessionUser(null);
    setUser(GUEST_USER);
    setSelectedNoteId(null);
    setIsEditing(false);
    setIsAuthenticated(false);
  };

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-black p-6">
        <div className="flex items-center gap-3 text-sm font-semibold text-slate-700 dark:text-slate-200">
          <RefreshCw className="w-5 h-5 text-indigo-500 animate-spin" />
          <span>লোড হচ্ছে...</span>
        </div>
      </div>
    );
  }

  // Authentication Gate
  if (!isAuthenticated) {
    return (
      <LoginScreen
        onAuthenticated={(authenticatedUser) => {
          setUser(authenticatedUser);
          savePersistedSessionUser(authenticatedUser);
          setIsAuthenticated(true);
        }}
        onContinueAsGuest={() => {
          setUser(GUEST_USER);
          savePersistedSessionUser(GUEST_USER);
          setIsAuthenticated(true);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen h-screen flex flex-col bg-slate-50 dark:bg-black text-slate-900 dark:text-white overflow-hidden">
      {/* Header Bar */}
      {!isEditing && (
        <header className="flex items-center justify-between gap-4 px-4 sm:px-6 py-2.5 bg-white dark:bg-black border-b border-slate-200 dark:border-[#1f1f1f] shrink-0 z-30">
          {/* Brand */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setSidebarOpen((prev) => !prev)}
              className="lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#141414] rounded-xl"
              aria-label="মেনু"
            >
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedNoteId(null);
                setIsEditing(false);
                setActiveNav('all');
                setSelectedCategory(null);
              }}
              className="flex items-center gap-2 text-base font-bold tracking-tight text-slate-900 dark:text-white"
            >
              <BookOpen className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <span>Cloud Note</span>
            </button>
          </div>

          {/* Quick Nav */}
          <nav
            aria-label="নেভিগেশন"
            className="hidden md:flex items-center gap-5 text-xs font-medium text-slate-600 dark:text-slate-300"
          >
            <button
              type="button"
              onClick={() => {
                setActiveNav('all');
                setSelectedCategory(null);
                setSelectedNoteId(null);
                setIsEditing(false);
              }}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors ${
                activeNav === 'all' && !selectedCategory && !selectedNoteId
                  ? 'text-indigo-600 dark:text-indigo-400 font-bold underline underline-offset-8'
                  : ''
              }`}
            >
              সকল নোট ({activeNotes.length.toLocaleString('bn-BD')})
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveNav('favorites');
                setSelectedCategory(null);
                setSelectedNoteId(null);
                setIsEditing(false);
              }}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors ${
                activeNav === 'favorites' && !selectedNoteId
                  ? 'text-indigo-600 dark:text-indigo-400 font-bold underline underline-offset-8'
                  : ''
              }`}
            >
              প্রিয় নোট ({favoriteNotesCount.toLocaleString('bn-BD')})
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveNav('trash');
                setSelectedCategory(null);
                setSelectedNoteId(null);
                setIsEditing(false);
              }}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors ${
                activeNav === 'trash' && !selectedNoteId
                  ? 'text-rose-600 dark:text-rose-400 font-bold underline underline-offset-8'
                  : ''
              }`}
            >
              ট্র্যাশ বিন ({trashedNotesCount.toLocaleString('bn-BD')})
            </button>
          </nav>

          {/* Right Actions: Theme Switcher + Cloud Sync + New Note */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Theme Switcher (Light, Dark, Sepia, Midnight, Forest, Paper) */}
            <ThemeSwitcher theme={theme} onChange={setTheme} />

            <button
              type="button"
              onClick={() => setIsAuthModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 hover:bg-slate-200 dark:bg-[#0a0a0a] dark:hover:bg-[#141414] border border-slate-200 dark:border-[#262626] rounded-xl transition-colors"
              title="ক্লাউড সিঙ্ক"
            >
              <Cloud
                className={`w-3.5 h-3.5 text-indigo-500 ${
                  syncState === 'syncing' ? 'animate-bounce' : ''
                }`}
              />
              <span className="hidden sm:inline">সিঙ্ক</span>
            </button>

            <PWAInstallButton />

            <button
              type="button"
              onClick={handleStartNewNote}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন নোট</span>
            </button>
          </div>
        </header>
      )}

      {/* Main Workspace: Sidebar + Content */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Mobile Backdrop */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-black/60 backdrop-blur-xs lg:hidden"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />
        )}

        {/* Sidebar */}
        <aside
          aria-label="সাইডবার"
          className={`${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          } fixed lg:static inset-y-0 left-0 z-30 w-64 bg-white dark:bg-black border-r border-slate-200 dark:border-[#1f1f1f] flex flex-col justify-between transition-transform duration-200 shrink-0`}
        >
          <div className="flex-1 overflow-y-auto p-4 space-y-5">
            {/* Nav Group */}
            <div className="space-y-1">
              <p className="px-2 text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">
                লাইব্রেরি
              </p>

              {/* All Notes Option */}
              <button
                type="button"
                onClick={() => {
                  setActiveNav('all');
                  setSelectedCategory(null);
                  setSelectedNoteId(null);
                  setIsEditing(false);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                  activeNav === 'all' && selectedCategory === null && !selectedNoteId && !isEditing
                    ? 'bg-slate-900 text-white dark:bg-indigo-600'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#121212]'
                }`}
              >
                <span className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  <span>সকল নোট</span>
                </span>
                <span className="font-mono text-[11px] opacity-75">
                  {activeNotes.length.toLocaleString('bn-BD')}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveNav('favorites');
                  setSelectedCategory(null);
                  setSelectedNoteId(null);
                  setIsEditing(false);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                  activeNav === 'favorites' && !selectedNoteId && !isEditing
                    ? 'bg-slate-900 text-white dark:bg-indigo-600'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#121212]'
                }`}
              >
                <span className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-amber-500" />
                  <span>প্রিয় নোট</span>
                </span>
                <span className="font-mono text-[11px] opacity-75">
                  {favoriteNotesCount.toLocaleString('bn-BD')}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveNav('trash');
                  setSelectedCategory(null);
                  setSelectedNoteId(null);
                  setIsEditing(false);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                  activeNav === 'trash' && !selectedNoteId && !isEditing
                    ? 'bg-rose-600 text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#121212]'
                }`}
              >
                <span className="flex items-center gap-2">
                  <Trash2 className="w-4 h-4 text-rose-500" />
                  <span>ট্র্যাশ বিন</span>
                </span>
                <span className="font-mono text-[11px] opacity-75">
                  {trashedNotesCount.toLocaleString('bn-BD')}
                </span>
              </button>
            </div>

            {/* Dynamic Custom Categories List */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between px-2">
                <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  ক্যাটাগরি
                </p>
                <button
                  type="button"
                  onClick={() => setIsCreateCategoryOpen(true)}
                  className="p-1 rounded-md text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-[#141414] transition-colors"
                  title="নতুন ক্যাটাগরি তৈরি করুন"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                </button>
              </div>

              {userCategories.map((cat) => {
                const count = activeNotes.filter(
                  (n) => (n.category || '').toLowerCase() === cat.name.toLowerCase()
                ).length;
                const isSelected =
                  activeNav === 'category' &&
                  selectedCategory?.toLowerCase() === cat.name.toLowerCase();

                return (
                  <button
                    key={cat.id || cat.name}
                    type="button"
                    onClick={() => {
                      setActiveNav('category');
                      setSelectedCategory(cat.name);
                      setSelectedNoteId(null);
                      setIsEditing(false);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs transition-colors ${
                      isSelected
                        ? 'bg-indigo-50 dark:bg-[#141414] font-bold text-indigo-700 dark:text-white border border-indigo-200 dark:border-indigo-900/60'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-[#121212]'
                    }`}
                  >
                    <span className="flex items-center gap-2 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: cat.color || '#6366f1' }}
                      />
                      <span className="truncate">{cat.name}</span>
                    </span>
                    <span className="font-mono text-[11px] opacity-70">
                      {count.toLocaleString('bn-BD')}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* User Profile */}
          <UserProfileSection
            user={user}
            syncState={syncState}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onOpenProfile={() => setIsProfileModalOpen(true)}
            onLogout={handleLogout}
            totalNotesCount={activeNotes.length}
          />
        </aside>

        {/* Main Content Viewport */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {isLoading ? (
            <div className="flex-1 p-8 space-y-4">
              <div className="h-8 w-48 bg-slate-200 dark:bg-[#141414] rounded-xl animate-pulse" />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[1, 2, 3].map((n) => (
                  <div
                    key={n}
                    className="h-44 rounded-2xl bg-white dark:bg-[#0a0a0a] border border-slate-200 dark:border-[#1f1f1f] p-5 animate-pulse"
                  />
                ))}
              </div>
            </div>
          ) : isEditing ? (
            <NoteEditor
              initialNote={editingNote}
              categories={userCategories.map((c) => c.name)}
              onCreateCategory={handleCreateCategoryByName}
              onSave={handleSaveFromEditor}
              onCancel={() => {
                setIsEditing(false);
                setEditingNote(null);
              }}
            />
          ) : selectedNote ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              <NoteReaderView
                note={selectedNote}
                categories={userCategories.map((c) => c.name)}
                onBack={() => setSelectedNoteId(null)}
                onEdit={() => {
                  setEditingNote(selectedNote);
                  setIsEditing(true);
                }}
                onToggleFavorite={(n) => handleToggleFavorite(n)}
                onTogglePin={(n) => handleTogglePin(n)}
                onSoftDelete={(n) => handleSoftDelete(n)}
                onRestoreNote={(n) => handleRestoreFromTrash(n)}
                onPermanentDelete={(id) => handlePermanentDelete(id)}
                onOpenReadingMode={() => setIsReadingModeOpen(true)}
                onOpenPinModal={(mode) =>
                  setPinModalState({
                    isOpen: true,
                    mode,
                    targetNote: selectedNote,
                  })
                }
                onUpdateNoteSections={async (updated) => {
                  await handlePersistNote(updated);
                }}
              />
            </div>
          ) : (
            <RecentNotesView
              notes={filteredNotes}
              allCategories={userCategories}
              activeView={activeNav}
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                setActiveNav(cat ? 'category' : 'all');
              }}
              onOpenCreateCategory={() => setIsCreateCategoryOpen(true)}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              unlockedNoteIds={unlockedNoteIds}
              onSelectNote={handleSelectNoteCard}
              onCreateNewNote={handleStartNewNote}
              onToggleFavorite={handleToggleFavorite}
              onTogglePin={handleTogglePin}
              onChangeNoteColor={handleChangeNoteColor}
              onSoftDelete={handleSoftDelete}
              onRestoreNote={handleRestoreFromTrash}
              onPermanentDelete={handlePermanentDelete}
              onEmptyTrash={handleEmptyTrash}
              onApplyAIUpdate={handlePersistNote}
            />
          )}
        </main>
      </div>

      {/* Reading Mode Modal */}
      <ReadingModeModal
        note={selectedNote}
        isOpen={isReadingModeOpen}
        onClose={() => setIsReadingModeOpen(false)}
      />

      {/* PIN Lock Modal */}
      <PinLockModal
        isOpen={pinModalState.isOpen}
        mode={pinModalState.mode}
        noteTitle={pinModalState.targetNote?.title || ''}
        existingPinHash={pinModalState.targetNote?.pinHash}
        onSuccess={(pinHash) => {
          if (pinModalState.mode === 'set' && pinModalState.targetNote) {
            handlePersistNote({
              ...pinModalState.targetNote,
              pinHash,
              isLocked: true,
              updatedAt: new Date().toISOString(),
            });
          } else if (pinModalState.mode === 'manage' && pinModalState.targetNote) {
            handlePersistNote({
              ...pinModalState.targetNote,
              pinHash: null,
              isLocked: false,
              updatedAt: new Date().toISOString(),
            });
            setUnlockedNoteIds((prev) => {
              const next = new Set(prev);
              next.delete(pinModalState.targetNote!.id);
              return next;
            });
          }
          if (pinModalState.onVerifiedAction && pinModalState.targetNote) {
            pinModalState.onVerifiedAction(pinModalState.targetNote);
          }
          setPinModalState((prev) => ({ ...prev, isOpen: false }));
        }}
        onClose={() => setPinModalState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Profile Modal (email + display name) */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        user={user}
        onClose={() => setIsProfileModalOpen(false)}
        onUpdated={(updatedUser) => {
          setUser(updatedUser);
          savePersistedSessionUser(updatedUser);
        }}
      />

      {/* Cloud Sync & Backup Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={user}
        allNotes={activeNotes}
        onSelectUser={(updatedUser) => {
          setUser(updatedUser);
          savePersistedSessionUser(updatedUser);
        }}
        onManualSync={async () => {
          await syncAllNotesWithCloud(user);
        }}
        onRestoreNotes={async (restoredList) => {
          for (const item of restoredList) {
            await handlePersistNote(item);
          }
        }}
        onLogout={handleLogout}
        onRestoreSingleVersion={async (snapshot) => {
          const existing = allNotes.find((n) => n.id === snapshot.noteId);
          const restored = hydrateNoteInMemory({
            ...(existing || {}),
            id: snapshot.noteId,
            title: snapshot.title,
            category: snapshot.category,
            sections: snapshot.sections,
            isFavorite: existing?.isFavorite ?? false,
            isDeleted: false,
            deletedAt: null,
            createdAt: existing?.createdAt || snapshot.savedAt,
            updatedAt: new Date().toISOString(),
            userId: user.uid,
          });
          await handlePersistNote(restored);
        }}
      />

      {/* Create Dynamic Custom Category Modal */}
      <CreateCategoryModal
        isOpen={isCreateCategoryOpen}
        onClose={() => setIsCreateCategoryOpen(false)}
        existingCategories={userCategories.map((c) => c.name)}
        onSave={handleCreateCategory}
      />
    </div>
  );
};

export default App;
