'use client';

import React, { useState } from 'react';
import { X, Plus, Check } from 'lucide-react';
import type { CategoryItem } from '../lib/types';

interface CreateCategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (category: CategoryItem) => void;
  existingCategories: string[];
}

const PRESET_COLORS = [
  '#6366f1', // Indigo
  '#0ea5e9', // Sky
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#f43f5e', // Rose
  '#8b5cf6', // Purple
  '#06b6d4', // Cyan
  '#ec4899', // Pink
  '#64748b', // Slate
  '#d97706', // Orange
];

export const CreateCategoryModal: React.FC<CreateCategoryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  existingCategories,
}) => {
  const [name, setName] = useState('');
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0]);
  const [customColor, setCustomColor] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('ক্যাটাগরির একটি নাম দিন');
      return;
    }
    if (existingCategories.some((c) => c.toLowerCase() === trimmed.toLowerCase())) {
      setError('এই নামের ক্যাটাগরি ইতিমধ্যে বিদ্যমান আছে');
      return;
    }

    const color = customColor.trim() || selectedColor;
    const newCategory: CategoryItem = {
      id: `cat-${Date.now()}`,
      name: trimmed,
      color,
      createdAt: new Date().toISOString(),
    };

    onSave(newCategory);
    setName('');
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-sm rounded-2xl bg-white dark:bg-black border border-slate-200 dark:border-[#222222] shadow-2xl overflow-hidden p-5 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-[#222222]">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Plus className="w-4 h-4 text-indigo-500" />
            <span>নতুন ক্যাটাগরি তৈরি করুন</span>
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#141414]"
            aria-label="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              ক্যাটাগরির নাম
            </label>
            <input
              type="text"
              autoFocus
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              placeholder="যেমন: প্রজেক্ট, গবেষণা, আইডিয়া..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-[#262626] bg-slate-50 dark:bg-[#0a0a0a] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            {error && <p className="text-[11px] text-rose-500 font-medium">{error}</p>}
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              কালার ট্যাগ
            </label>
            <div className="grid grid-cols-5 gap-2">
              {PRESET_COLORS.map((c) => {
                const isSelected = selectedColor === c && !customColor;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setSelectedColor(c);
                      setCustomColor('');
                    }}
                    style={{ backgroundColor: c }}
                    className="h-8 rounded-lg flex items-center justify-center transition-transform hover:scale-105 relative"
                  >
                    {isSelected && <Check className="w-4 h-4 text-white drop-shadow-md" />}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <span className="text-[11px] text-slate-400">কাস্টম কালার:</span>
              <input
                type="color"
                value={customColor || selectedColor}
                onChange={(e) => setCustomColor(e.target.value)}
                className="w-7 h-7 rounded border border-slate-200 dark:border-[#262626] cursor-pointer bg-transparent"
                title="কাস্টম কালার নির্বাচন করুন"
              />
              <span className="text-[11px] font-mono text-slate-500">
                {customColor || selectedColor}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-[#222222]">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#141414] rounded-xl transition-colors"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors"
            >
              সংরক্ষণ করুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateCategoryModal;
