'use client';

import React from 'react';
import { Cloud, HardDrive, LogOut, RefreshCw, ShieldCheck } from 'lucide-react';
import type { CloudSyncState, UserProfile } from '../lib/types';

interface UserProfileSectionProps {
  user: UserProfile;
  syncState?: CloudSyncState;
  onOpenAuthModal: () => void;
  onOpenProfile?: () => void;
  onLogout: () => void;
  totalNotesCount: number;
}

export const UserProfileSection: React.FC<UserProfileSectionProps> = ({
  user,
  syncState = 'synced',
  onOpenAuthModal,
  onOpenProfile,
  onLogout,
  totalNotesCount,
}) => {
  return (
    <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/70 space-y-2">
      <div className="flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={onOpenProfile ?? onOpenAuthModal}
          className="flex items-center gap-2.5 min-w-0 text-left group flex-1"
          title={onOpenProfile ? 'প্রোফাইল দেখুন ও নাম পরিবর্তন করুন' : 'ক্লাউড সিঙ্ক, ব্যাকআপ ও প্রোফাইল হাব খুলুন'}
        >
          <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-semibold text-xs shrink-0 shadow-xs">
            {(user.displayName || user.email || 'ক').slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
              {user.displayName || 'ক্লাউডনোট ব্যবহারকারী'}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate flex items-center gap-1">
              {syncState === 'syncing' ? (
                <>
                  <RefreshCw className="w-3 h-3 shrink-0 text-indigo-600 animate-spin" />
                  <span>ক্লাউডে সিঙ্ক হচ্ছে...</span>
                </>
              ) : user.isLocalMode ? (
                <>
                  <HardDrive className="w-3 h-3 shrink-0 text-emerald-600 dark:text-emerald-400" />
                  <span>স্টুডিও ভল্ট ({totalNotesCount.toLocaleString('bn-BD')} নোট)</span>
                </>
              ) : (
                <>
                  <Cloud className="w-3 h-3 shrink-0 text-indigo-600 dark:text-indigo-400" />
                  <span className="truncate">{user.email || 'ক্লাউড সিঙ্ক সক্রিয়'}</span>
                </>
              )}
            </p>
          </div>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={onOpenAuthModal}
            className="px-2 py-1.5 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 rounded-lg transition-colors flex items-center gap-1"
            title="ক্লাউড সিঙ্ক ও ডেটা ব্যাকআপ"
            aria-label="ক্লাউড সিঙ্ক ও ডেটা ব্যাকআপ"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>ব্যাকআপ</span>
          </button>
          <button
            type="button"
            onClick={onLogout}
            className="p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
            title="লগআউট করুন"
            aria-label="লগআউট করুন"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserProfileSection;
