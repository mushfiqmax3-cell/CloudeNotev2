'use client';

import React, { useEffect, useState } from 'react';
import { X, Mail, User, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { updateProfile } from 'firebase/auth';
import { auth, isFirebaseConfigured } from '../lib/firebase';
import {
  savePersistedSessionUser,
  upsertUserProfileToFirestore,
  updateVaultAccountDisplayName,
} from '../lib/storage';
import { normalizeUnicodeText } from '../lib/text-normalizer';
import type { UserProfile } from '../lib/types';

interface UserProfileModalProps {
  isOpen: boolean;
  user: UserProfile;
  onClose: () => void;
  onUpdated: (user: UserProfile) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  user,
  onClose,
  onUpdated,
}) => {
  const [name, setName] = useState(user.displayName || '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const timer = setTimeout(() => {
      setName(user.displayName || '');
      setError(null);
      setSaved(false);
    }, 0);
    return () => clearTimeout(timer);
  }, [isOpen, user.displayName]);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaved(false);

    const cleanName = normalizeUnicodeText(name).trim().slice(0, 60);
    if (!cleanName) {
      setError('নাম খালি রাখা যাবে না।');
      return;
    }

    setSaving(true);
    try {
      if (isFirebaseConfigured && auth?.currentUser && auth.currentUser.uid === user.uid) {
        try {
          await updateProfile(auth.currentUser, { displayName: cleanName });
        } catch {
          // Local profile is still updated below
        }
      }
      await updateVaultAccountDisplayName(user.email, cleanName);

      const updated: UserProfile = { ...user, displayName: cleanName };
      savePersistedSessionUser(updated);
      await upsertUserProfileToFirestore(updated);
      onUpdated(updated);
      setName(cleanName);
      setSaved(true);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'নাম আপডেট করা যায়নি।');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="profile-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-5 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2
            id="profile-modal-title"
            className="text-base font-bold text-slate-900 dark:text-white"
          >
            প্রোফাইল
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg"
            aria-label="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-semibold text-base shrink-0">
            {(name || user.email || 'ক').slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-[11px] text-slate-500 dark:text-slate-400">ইমেইল</p>
            <p className="text-sm font-semibold text-slate-900 dark:text-white break-all">
              {user.email || 'সংযুক্ত নয় (গেস্ট মোড)'}
            </p>
          </div>
        </div>

        {error && (
          <div
            role="alert"
            className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {saved && (
          <div
            role="status"
            className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>নাম সফলভাবে আপডেট হয়েছে।</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-3" noValidate>
          <div>
            <label
              htmlFor="profile-display-name"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
            >
              আপনার নাম
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                id="profile-display-name"
                type="text"
                value={name}
                maxLength={60}
                onChange={(e) => {
                  setName(e.target.value);
                  setSaved(false);
                }}
                placeholder="আপনার নাম লিখুন"
                className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="profile-email"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
            >
              ইমেইল
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                id="profile-email"
                type="email"
                value={user.email || ''}
                readOnly
                disabled
                className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 opacity-90 cursor-not-allowed"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 rounded-xl transition-colors"
          >
            {saving ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>সংরক্ষণ হচ্ছে...</span>
              </>
            ) : (
              <span>নাম সংরক্ষণ করুন</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default UserProfileModal;
