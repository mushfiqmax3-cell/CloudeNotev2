'use client';

import React, { useEffect, useRef, useState } from 'react';
import { Check, Palette } from 'lucide-react';
import { THEMES, getThemeOption, type ThemeId } from '../lib/theme';

interface ThemeSwitcherProps {
  theme: ThemeId;
  onChange: (theme: ThemeId) => void;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ theme, onChange }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);
  const current = getThemeOption(theme);

  useEffect(() => {
    if (!open) return;
    const handlePointer = (e: MouseEvent | TouchEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handlePointer);
    document.addEventListener('touchstart', handlePointer);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handlePointer);
      document.removeEventListener('touchstart', handlePointer);
      document.removeEventListener('keydown', handleKey);
    };
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-[#262626] bg-slate-100 hover:bg-slate-200/80 dark:bg-[#0a0a0a] dark:hover:bg-[#141414] text-slate-800 dark:text-slate-200 transition-colors"
        title="থিম নির্বাচন করুন"
      >
        <Palette className="w-3.5 h-3.5 text-indigo-500" />
        <span className="hidden sm:inline">{current.label.split(' ')[0]}</span>
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="থিম নির্বাচন"
          className="absolute right-0 mt-2 w-64 z-50 p-1.5 rounded-2xl border border-slate-200 dark:border-[#262626] bg-white dark:bg-[#0a0a0a] shadow-xl"
        >
          {THEMES.map((t) => (
            <button
              key={t.id}
              type="button"
              role="option"
              aria-selected={t.id === theme}
              onClick={() => {
                onChange(t.id);
                setOpen(false);
              }}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left text-xs transition-colors hover:bg-slate-100 dark:hover:bg-[#141414] ${
                t.id === theme
                  ? 'font-bold text-indigo-700 dark:text-indigo-300'
                  : 'font-medium text-slate-800 dark:text-slate-200'
              }`}
            >
              <span
                className="w-6 h-6 rounded-lg border border-slate-300 dark:border-slate-600 flex items-center justify-center shrink-0 text-[11px] font-bold"
                style={{ backgroundColor: t.swatch.bg, color: t.swatch.fg }}
                aria-hidden="true"
              >
                অ
              </span>
              <span className="flex-1 min-w-0">
                <span className="block truncate">{t.labelBn}</span>
                <span className="block truncate text-[10px] font-normal text-slate-500 dark:text-slate-400">
                  {t.label}
                </span>
              </span>
              {t.id === theme && <Check className="w-3.5 h-3.5 shrink-0" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ThemeSwitcher;
