'use client';

import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  ListTree,
  CheckSquare,
  Wand2,
  FolderSync,
  Copy,
  Check,
  Loader2,
  CornerDownLeft,
} from 'lucide-react';
import type { NoteItem } from '../lib/types';
import { executeAIAction, type AIAction } from '../lib/gemini-service';

interface AIActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  note: NoteItem;
  categories: string[];
  initialAction?: AIAction;
  onApplyToNote?: (updatedNote: NoteItem) => Promise<unknown>;
}

export const AIActionModal: React.FC<AIActionModalProps> = ({
  isOpen,
  onClose,
  note,
  categories,
  initialAction = 'summarize',
  onApplyToNote,
}) => {
  const [activeAction, setActiveAction] = useState<AIAction>(initialAction);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [output, setOutput] = useState<string>('');
  const [suggestedCategory, setSuggestedCategory] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [applied, setApplied] = useState<boolean>(false);

  const fullText = (note.sections || [])
    .map((s) => `${s.title}\n${s.content}`)
    .join('\n\n')
    .trim() || note.content || '';

  const runAction = React.useCallback(
    async (action: AIAction) => {
      setIsLoading(true);
      setErrorMessage(null);
      setOutput('');
      setSuggestedCategory(null);
      setCopied(false);
      setApplied(false);

      try {
        const response = await executeAIAction({
          action,
          text: fullText,
          categories,
          noteTitle: note.title,
        });

        if (!response.success) {
          setErrorMessage(response.error || 'এআই প্রক্রিয়াকরণ সম্পন্ন হতে পারেনি।');
        } else {
          setOutput(response.result);
          if (action === 'auto_categorize' && response.suggestedCategory) {
            setSuggestedCategory(response.suggestedCategory);
          }
        }
      } catch (err: unknown) {
        setErrorMessage(
          err instanceof Error ? err.message : 'এআই সার্ভিসের সাথে সংযোগ ব্যর্থ হয়েছে।'
        );
      } finally {
        setIsLoading(false);
      }
    },
    [fullText, categories, note.title]
  );

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        setActiveAction(initialAction);
        runAction(initialAction);
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [isOpen, initialAction, runAction]);

  const handleCopy = async () => {
    if (!output) return;
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApply = async () => {
    if (!onApplyToNote) return;

    if (activeAction === 'auto_categorize' && suggestedCategory) {
      const updated: NoteItem = {
        ...note,
        category: suggestedCategory,
        updatedAt: new Date().toISOString(),
      };
      await onApplyToNote(updated);
      setApplied(true);
      setTimeout(() => {
        onClose();
      }, 900);
    } else if (activeAction === 'summarize' || activeAction === 'extract_todos') {
      // Append as new section or to last section
      const newSection = {
        id: `sec-${Date.now()}`,
        title: activeAction === 'summarize' ? 'সারসংক্ষেপ (AI Summary)' : 'টু-ডু তালিকা (To-Do List)',
        content: output,
      };
      const updated: NoteItem = {
        ...note,
        sections: [...(note.sections || []), newSection],
        updatedAt: new Date().toISOString(),
      };
      await onApplyToNote(updated);
      setApplied(true);
      setTimeout(() => {
        onClose();
      }, 900);
    } else if (activeAction === 'polish_text') {
      // Update first section or single section
      const firstSec = note.sections?.[0];
      const restSecs = (note.sections || []).slice(1);
      const updatedSections = firstSec
        ? [{ ...firstSec, content: output }, ...restSecs]
        : [{ id: 'sec-1', title: note.title, content: output }];

      const updated: NoteItem = {
        ...note,
        sections: updatedSections,
        updatedAt: new Date().toISOString(),
      };
      await onApplyToNote(updated);
      setApplied(true);
      setTimeout(() => {
        onClose();
      }, 900);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-lg rounded-2xl bg-white dark:bg-black border border-slate-200 dark:border-[#222222] shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 dark:border-[#222222]">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Google Gemini AI Assistant
              </h2>
              <p className="text-[11px] text-slate-400 dark:text-slate-500 truncate max-w-xs">
                {note.title}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#141414]"
            aria-label="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 4 Action Buttons Tabs */}
        <div className="p-3 bg-slate-50/80 dark:bg-[#070707] border-b border-slate-100 dark:border-[#222222] grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveAction('summarize');
              runAction('summarize');
            }}
            className={`flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-semibold rounded-xl transition-all ${
              activeAction === 'summarize'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-[#121212]'
            }`}
          >
            <ListTree className="w-3.5 h-3.5" />
            <span>Summarize</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveAction('extract_todos');
              runAction('extract_todos');
            }}
            className={`flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-semibold rounded-xl transition-all ${
              activeAction === 'extract_todos'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-[#121212]'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>Extract To-Dos</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveAction('polish_text');
              runAction('polish_text');
            }}
            className={`flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-semibold rounded-xl transition-all ${
              activeAction === 'polish_text'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-[#121212]'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>Polish Text</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveAction('auto_categorize');
              runAction('auto_categorize');
            }}
            className={`flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-semibold rounded-xl transition-all ${
              activeAction === 'auto_categorize'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-[#121212]'
            }`}
          >
            <FolderSync className="w-3.5 h-3.5" />
            <span>Auto-Category</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-7 h-7 text-indigo-500 animate-spin" />
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 animate-pulse">
                Gemini AI ফলাফল তৈরি করছে...
              </p>
            </div>
          ) : errorMessage ? (
            <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-xs text-rose-600 dark:text-rose-400">
              {errorMessage}
            </div>
          ) : activeAction === 'auto_categorize' && suggestedCategory ? (
            <div className="py-6 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto border border-indigo-200 dark:border-indigo-800">
                <FolderSync className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-slate-400">প্রস্তাবিত উপযুক্ত ক্যাটাগরি:</p>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                  {suggestedCategory}
                </h3>
                <p className="text-[11px] text-slate-500 mt-1">
                  বর্তমান ক্যাটাগরি: <span className="font-semibold">{note.category}</span>
                </p>
              </div>
            </div>
          ) : output ? (
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#0a0a0a] border border-slate-200/80 dark:border-[#222222] font-mono text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
              {output}
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-slate-400">
              ফলাফল পেতে যেকোনো একটি বাটনে চাপুন।
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {output && !isLoading && (
          <div className="flex items-center justify-between px-5 py-3 border-t border-slate-100 dark:border-[#222222] bg-slate-50/50 dark:bg-[#070707]">
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-[#1a1a1a] rounded-xl transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span>কপি হয়েছে</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>কপি করুন</span>
                </>
              )}
            </button>

            {onApplyToNote && (
              <button
                type="button"
                onClick={handleApply}
                disabled={applied}
                className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:bg-emerald-600 rounded-xl transition-colors shadow-xs"
              >
                {applied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>প্রয়োগ করা হয়েছে</span>
                  </>
                ) : (
                  <>
                    <CornerDownLeft className="w-3.5 h-3.5" />
                    <span>
                      {activeAction === 'auto_categorize'
                        ? 'ক্যাটাগরি আপডেট করুন'
                        : activeAction === 'polish_text'
                          ? 'নোট প্রতিস্থাপন করুন'
                          : 'নোটে যোগ করুন'}
                    </span>
                  </>
                )}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default AIActionModal;
