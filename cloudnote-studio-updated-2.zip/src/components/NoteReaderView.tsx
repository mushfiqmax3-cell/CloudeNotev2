'use client';

import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Edit3,
  Star,
  Trash2,
  BookOpen,
  ListTree,
  Search,
  Replace,
  Download,
  FileText,
  FileCode,
  FileType,
  Printer,
  Lock,
  Unlock,
  RotateCcw,
  ChevronRight,
  X,
  Check,
  Database,
  Type,
  Sun,
  Moon,
  Copy,
  SlidersHorizontal,
  Minus,
  Plus,
  ArrowLeft,
  Pin,
  Palette,
  Sparkles,
  CheckSquare,
  Wand2,
  FolderSync,
} from 'lucide-react';
import type { NoteFontFamily, NoteItem } from '../lib/types';
import { AIActionModal } from './AIActionModal';
import type { AIAction } from '../lib/gemini-service';
import {
  computeSectionsMetrics,
  extractTocEntries,
  findMatchesInSections,
  replaceInSections,
} from '../lib/text-normalizer';
import {
  exportNoteToPDF,
  exportNoteToTXT,
  exportNoteToMarkdown,
  exportNoteToWord,
} from '../lib/pdf-export';
import { MarkdownRenderer } from './MarkdownRenderer';

interface NoteReaderViewProps {
  note: NoteItem;
  categories?: string[];
  onBack?: () => void;
  onEdit: () => void;
  onToggleFavorite: (note: NoteItem) => void;
  onTogglePin?: (note: NoteItem) => void;
  onSoftDelete: (note: NoteItem) => void;
  onRestoreNote: (note: NoteItem) => void;
  onPermanentDelete: (noteId: string) => void;
  onOpenReadingMode: () => void;
  onOpenPinModal: (mode: 'set' | 'unlock' | 'manage') => void;
  onUpdateNoteSections: (updatedNote: NoteItem) => Promise<void>;
}

const FONT_CLASS_MAP: Record<NoteFontFamily, string> = {
  sans: 'font-bengali-sans',
  serif: 'font-bengali-serif',
  hind: 'font-bengali-hind',
  tiro: 'font-bengali-tiro',
  mono: 'font-bengali-mono',
};

type ReaderTheme = 'default' | 'sepia' | 'sage' | 'dark';

export const NoteReaderView: React.FC<NoteReaderViewProps> = ({
  note,
  categories = [],
  onBack,
  onEdit,
  onToggleFavorite,
  onTogglePin,
  onSoftDelete,
  onRestoreNote,
  onPermanentDelete,
  onOpenReadingMode,
  onOpenPinModal,
  onUpdateNoteSections,
}) => {
  const [showToc, setShowToc] = useState<boolean>(true);
  const [showMobileToc, setShowMobileToc] = useState<boolean>(false);
  const [showFindReplace, setShowFindReplace] = useState<boolean>(false);
  const [showExportMenu, setShowExportMenu] = useState<boolean>(false);
  const [showAppearanceBar, setShowAppearanceBar] = useState<boolean>(false);

  // Reader Customization Preferences
  const [readerTheme, setReaderTheme] = useState<ReaderTheme>('default');
  const [fontSize, setFontSize] = useState<number>(17);
  const [fontFamily, setFontFamily] = useState<NoteFontFamily>(note.fontFamily || 'sans');

  // Search & Replace
  const [findQuery, setFindQuery] = useState<string>('');
  const [replaceQuery, setReplaceQuery] = useState<string>('');
  const [caseSensitive, setCaseSensitive] = useState<boolean>(false);
  const [replaceFeedback, setReplaceFeedback] = useState<string | null>(null);

  // AI Assistant & Custom Color State
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);
  const [aiInitialAction, setAiInitialAction] = useState<AIAction>('summarize');
  const [showColorPicker, setShowColorPicker] = useState<boolean>(false);
  const [copiedSectionId, setCopiedSectionId] = useState<string | null>(null);
  const [copiedNote, setCopiedNote] = useState<boolean>(false);

  // Scroll Progress
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const metrics = useMemo(() => computeSectionsMetrics(note.sections || []), [note.sections]);
  const tocEntries = useMemo(() => extractTocEntries(note.sections || []), [note.sections]);

  const matchStats = useMemo(
    () => findMatchesInSections(note.sections || [], findQuery, caseSensitive),
    [note.sections, findQuery, caseSensitive]
  );

  const fontClass = FONT_CLASS_MAP[fontFamily];

  // Track scroll percentage
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    const total = scrollHeight - clientHeight;
    if (total > 0) {
      setScrollProgress(Math.min(100, Math.max(0, (scrollTop / total) * 100)));
    }
  };

  const handleJumpTo = (entryId: string) => {
    const target = document.getElementById(entryId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleChangeNoteColor = async (newColor: string) => {
    await onUpdateNoteSections({
      ...note,
      color: newColor || undefined,
      updatedAt: new Date().toISOString(),
    });
    setShowColorPicker(false);
  };

  const handleCopyNote = async () => {
    const text = `# ${note.title}\n\n` + (note.sections || []).map((s) => `## ${s.title}\n\n${s.content}`).join('\n\n');
    await navigator.clipboard.writeText(text);
    setCopiedNote(true);
    setTimeout(() => setCopiedNote(false), 2500);
  };

  const handleCopySection = async (secId: string, content: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedSectionId(secId);
    setTimeout(() => setCopiedSectionId(null), 2500);
  };

  const handleExecuteReplace = async (replaceAll: boolean) => {
    if (!findQuery.trim()) return;
    const { sections: updatedSections, replacedCount } = replaceInSections(
      note.sections || [],
      findQuery,
      replaceQuery,
      { caseSensitive, replaceAll }
    );
    if (replacedCount > 0) {
      await onUpdateNoteSections({
        ...note,
        sections: updatedSections,
        updatedAt: new Date().toISOString(),
      });
      setReplaceFeedback(`${replacedCount.toLocaleString('bn-BD')}টি স্থানে পরিবর্তন হয়েছে`);
      setTimeout(() => setReplaceFeedback(null), 3000);
    } else {
      setReplaceFeedback('কোনো মিল পাওয়া যায়নি');
      setTimeout(() => setReplaceFeedback(null), 2500);
    }
  };

  const formattedBytes =
    metrics.byteSize >= 1024 * 1024
      ? `${(metrics.byteSize / (1024 * 1024)).toFixed(2)} MB`
      : `${Math.max(1, Math.round(metrics.byteSize / 1024))} KB`;

  // Reader theme styles
  const themeClass =
    readerTheme === 'sepia'
      ? 'theme-sepia'
      : readerTheme === 'sage'
        ? 'theme-sage'
        : readerTheme === 'dark'
          ? 'theme-dark'
          : 'bg-slate-50/50 dark:bg-slate-950 text-slate-900 dark:text-slate-100';

  return (
    <div className={`flex flex-col h-full overflow-hidden relative transition-colors duration-200 ${themeClass}`}>
      {/* Real-time Reading Progress Bar */}
      <div
        className="h-1 bg-indigo-600 dark:bg-indigo-500 transition-all duration-150 sticky top-0 z-30"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Reader Action Header - Fully Responsive with Generous Title Width */}
      <header className="px-4 sm:px-6 py-3 border-b border-slate-200/80 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md sticky top-0 z-20 shadow-xs">
        {/* Row 1: Back Navigation + Category & Reading Metadata + Controls */}
        <div className="flex items-center justify-between gap-2.5 mb-2">
          <div className="flex items-center gap-2 min-w-0">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="inline-flex items-center gap-1.5 py-1.5 px-3 min-h-[36px] rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-all active:scale-95 shrink-0"
                title="সকল নোটের তালিকায় ফিরে যান"
              >
                <ArrowLeft className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span className="hidden xs:inline sm:inline">সকল নোট</span>
              </button>
            )}

            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 truncate">
              <span className="font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/70 px-2 py-0.5 rounded-md truncate">
                {note.category}
              </span>
              {note.subCategory && (
                <span className="hidden sm:inline truncate">· {note.subCategory}</span>
              )}
              <span className="tabular-nums font-mono hidden xs:inline truncate">
                · {metrics.wordCount.toLocaleString('bn-BD')} শব্দ ({metrics.readingTimeMinutes} মিনিট পাঠ)
              </span>
              {note.isChunked && (
                <span className="hidden md:inline-flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-medium shrink-0">
                  <Database className="w-3 h-3" />
                  <span>চাংকড ({note.chunkCount} খণ্ড)</span>
                </span>
              )}
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-1.5 shrink-0">
            {note.isDeleted ? (
              <>
                <button
                  type="button"
                  onClick={() => onRestoreNote(note)}
                  className="flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>পুনরুদ্ধার</span>
                </button>
                <button
                  type="button"
                  onClick={() => onPermanentDelete(note.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-xl transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>মুছুন</span>
                </button>
              </>
            ) : (
              <>
                {/* Gemini AI Action Button */}
                <button
                  type="button"
                  onClick={() => setIsAiModalOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-xs"
                  title="Google Gemini AI Assistant (Summarize, Extract To-Dos, Polish, Auto-Categorize)"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Gemini AI</span>
                </button>

                {/* Pin to Top Button */}
                {onTogglePin && (
                  <button
                    type="button"
                    onClick={() => onTogglePin(note)}
                    className={`p-2 min-h-[38px] min-w-[38px] rounded-xl border transition-colors flex items-center justify-center ${
                      note.isPinned
                        ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-950 dark:border-indigo-800 dark:text-indigo-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                    title={note.isPinned ? 'আনপিন করুন' : 'শীর্ষে পিন করুন'}
                  >
                    <Pin className={`w-4 h-4 ${note.isPinned ? 'fill-current' : ''}`} />
                  </button>
                )}

                {/* Color Palette Picker */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowColorPicker((prev) => !prev)}
                    className="p-2 min-h-[38px] min-w-[38px] rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center"
                    title="নোটের কালার পরিবর্তন করুন"
                  >
                    <Palette className="w-4 h-4" />
                  </button>

                  {showColorPicker && (
                    <div className="absolute right-0 top-full mt-2 p-2 bg-white dark:bg-[#111111] border border-slate-200 dark:border-[#262626] rounded-xl shadow-xl z-40 flex items-center gap-1.5">
                      {[
                        { label: 'Default', value: '' },
                        { label: 'Indigo', value: '#6366f1' },
                        { label: 'Emerald', value: '#10b981' },
                        { label: 'Amber', value: '#f59e0b' },
                        { label: 'Rose', value: '#f43f5e' },
                        { label: 'Purple', value: '#a855f7' },
                        { label: 'Sky', value: '#0ea5e9' },
                      ].map((swatch) => (
                        <button
                          key={swatch.value || 'default'}
                          type="button"
                          onClick={() => handleChangeNoteColor(swatch.value)}
                          style={{ backgroundColor: swatch.value || '#94a3b8' }}
                          className="w-5 h-5 rounded-full border border-black/10 dark:border-white/20 transition-transform hover:scale-110 flex items-center justify-center"
                          title={swatch.label}
                        >
                          {note.color === swatch.value && <Check className="w-3 h-3 text-white" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Reader Comfort / Appearance Toggle */}
                <button
                  type="button"
                  onClick={() => setShowAppearanceBar((prev) => !prev)}
                  className={`p-2 min-h-[38px] min-w-[38px] rounded-xl border transition-colors flex items-center justify-center ${
                    showAppearanceBar
                      ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-950 dark:border-indigo-800 dark:text-indigo-300'
                      : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  title="পঠন সুবিধা ও ফন্ট সাইজ নিয়ন্ত্রণ"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                </button>

                {/* Table of Contents Toggle (Desktop) */}
                <button
                  type="button"
                  onClick={() => setShowToc((prev) => !prev)}
                  className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-medium rounded-xl border transition-colors whitespace-nowrap ${
                    showToc
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800'
                      : 'text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  title="সূচিপত্র"
                >
                  <ListTree className="w-3.5 h-3.5" />
                  <span>সূচিপত্র</span>
                </button>

                {/* Find & Replace Toggle */}
                <button
                  type="button"
                  onClick={() => setShowFindReplace((prev) => !prev)}
                  className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-medium rounded-xl border transition-colors whitespace-nowrap ${
                    showFindReplace
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800'
                      : 'text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  title="নোটে শব্দ খুঁজুন ও পরিবর্তন করুন"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>খুঁজুন</span>
                </button>

                {/* Full Reading Mode */}
                <button
                  type="button"
                  onClick={onOpenReadingMode}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-medium text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors whitespace-nowrap"
                  title="পূর্ণ স্ক্রিন পঠন মোড"
                >
                  <BookOpen className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>পঠন মোড</span>
                </button>

                {/* PIN Lock (Visible on sm+ screens) */}
                <button
                  type="button"
                  onClick={() => onOpenPinModal(note.pinHash ? 'manage' : 'set')}
                  className={`hidden sm:flex p-2 min-h-[38px] min-w-[38px] rounded-xl border transition-colors items-center justify-center ${
                    note.pinHash
                      ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                      : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title={note.pinHash ? 'পিন লকড' : 'পিন লক সেট করুন'}
                >
                  {note.pinHash ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                </button>

                {/* Export Menu */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowExportMenu((prev) => !prev)}
                    className="p-2 min-h-[38px] min-w-[38px] rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center"
                    title="এক্সপোর্ট করুন"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  {showExportMenu && (
                    <>
                      <div className="fixed inset-0 z-30" onClick={() => setShowExportMenu(false)} />
                      <div className="absolute right-0 top-full mt-1.5 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl py-2 z-40 text-xs">
                        <div className="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          ডাউনলোড ও এক্সপোর্ট
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setShowExportMenu(false);
                            exportNoteToPDF(note);
                          }}
                          className="w-full px-4 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center gap-2.5"
                        >
                          <Printer className="w-4 h-4 text-indigo-600" />
                          <span>পিডিএফ ফাইল (.pdf)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowExportMenu(false);
                            exportNoteToWord(note);
                          }}
                          className="w-full px-4 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center gap-2.5"
                        >
                          <FileType className="w-4 h-4 text-blue-600" />
                          <span>মাইক্রোসফট ওয়ার্ড (.doc)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowExportMenu(false);
                            exportNoteToMarkdown(note);
                          }}
                          className="w-full px-4 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center gap-2.5"
                        >
                          <FileCode className="w-4 h-4 text-emerald-600" />
                          <span>মার্কডাউন ফাইল (.md)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowExportMenu(false);
                            exportNoteToTXT(note);
                          }}
                          className="w-full px-4 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center gap-2.5"
                        >
                          <FileText className="w-4 h-4 text-slate-600" />
                          <span>প্লেইন টেক্সট (.txt)</span>
                        </button>
                      </div>
                    </>
                  )}
                </div>

                {/* Favorite Star */}
                <button
                  type="button"
                  onClick={() => onToggleFavorite(note)}
                  className={`p-2 min-h-[38px] min-w-[38px] rounded-xl border transition-colors flex items-center justify-center ${
                    note.isFavorite
                      ? 'bg-amber-50 border-amber-200 text-amber-600 dark:bg-amber-950 dark:border-amber-800'
                      : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-800 dark:hover:text-white'
                  }`}
                  title={note.isFavorite ? 'প্রিয় থেকে সরান' : 'প্রিয়তে রাখুন'}
                >
                  <Star className={`w-4 h-4 ${note.isFavorite ? 'fill-current' : ''}`} />
                </button>

                {/* Primary Edit Button (Desktop/Tablet) */}
                <button
                  type="button"
                  onClick={onEdit}
                  className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 min-h-[38px] text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-sm active:scale-95"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>সম্পাদনা</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Row 2: Full Note Title with Beautiful Bengali Typography and NO ugly truncation */}
        <div className="pt-1.5 border-t border-slate-100 dark:border-slate-800/80">
          <h1 className="text-base sm:text-2xl font-bold text-slate-900 dark:text-white leading-snug">
            {note.title}
          </h1>
        </div>

        {/* Reader Comfort / Customization Bar (Expandable) */}
        {showAppearanceBar && (
          <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs animate-slide-down">
            {/* Theme switcher */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">থিম:</span>
              <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-lg p-0.5 bg-slate-100 dark:bg-slate-800">
                <button
                  type="button"
                  onClick={() => setReaderTheme('default')}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    readerTheme === 'default' ? 'bg-white dark:bg-slate-900 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  শুভ্র
                </button>
                <button
                  type="button"
                  onClick={() => setReaderTheme('sepia')}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    readerTheme === 'sepia' ? 'bg-[#fbf7ee] text-[#2c221e] shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  কাগজ
                </button>
                <button
                  type="button"
                  onClick={() => setReaderTheme('sage')}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    readerTheme === 'sage' ? 'bg-[#172621] text-[#a7f3d0] shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  শান্ত সবুজ
                </button>
                <button
                  type="button"
                  onClick={() => setReaderTheme('dark')}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    readerTheme === 'dark' ? 'bg-slate-950 text-indigo-400 shadow-xs font-bold' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  ডার্ক
                </button>
              </div>
            </div>

            {/* Font Size Adjuster */}
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">ফন্ট আকার:</span>
              <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <button
                  type="button"
                  onClick={() => setFontSize((s) => Math.max(14, s - 1))}
                  className="px-2.5 py-1 hover:bg-slate-200 dark:hover:bg-slate-700"
                  aria-label="ছোট করুন"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="px-2 font-mono tabular-nums text-xs font-bold">{fontSize}px</span>
                <button
                  type="button"
                  onClick={() => setFontSize((s) => Math.min(26, s + 1))}
                  className="px-2.5 py-1 hover:bg-slate-200 dark:hover:bg-slate-700"
                  aria-label="বড় করুন"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Font Family selector */}
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">ফন্ট:</span>
              <select
                value={fontFamily}
                onChange={(e) => setFontFamily(e.target.value as NoteFontFamily)}
                className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium focus:outline-none"
              >
                <option value="sans">Noto Sans Bengali</option>
                <option value="serif">Noto Serif Bengali</option>
                <option value="hind">Hind Siliguri</option>
                <option value="tiro">Tiro Bangla</option>
                <option value="mono">JetBrains Mono</option>
              </select>
            </div>

            {/* Copy Full Note CTA */}
            <button
              type="button"
              onClick={handleCopyNote}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 text-xs font-medium"
            >
              {copiedNote ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedNote ? 'কপি হয়েছে!' : 'সম্পূর্ণ নোট কপি'}</span>
            </button>
          </div>
        )}
      </header>

      {/* Find & Replace Bar */}
      {showFindReplace && (
        <div className="px-4 sm:px-6 py-2.5 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 flex-1 min-w-[180px]">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              value={findQuery}
              onChange={(e) => setFindQuery(e.target.value)}
              placeholder="এই নোটে শব্দ বা বাক্য খুঁজুন..."
              aria-label="এই নোটে শব্দ বা বাক্য খুঁজুন"
              className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            {findQuery && (
              <span className="text-xs font-mono tabular-nums text-indigo-600 dark:text-indigo-400 whitespace-nowrap px-1">
                {matchStats.totalMatches.toLocaleString('bn-BD')}টি মিল
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 flex-1 min-w-[180px]">
            <Replace className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              value={replaceQuery}
              onChange={(e) => setReplaceQuery(e.target.value)}
              placeholder="পরিবর্তিত শব্দ লিখুন..."
              aria-label="পরিবর্তিত শব্দ লিখুন"
              className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleExecuteReplace(false)}
              disabled={!findQuery.trim()}
              className="px-2.5 py-1.5 text-xs font-medium bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 disabled:opacity-40"
            >
              ১টি
            </button>
            <button
              type="button"
              onClick={() => handleExecuteReplace(true)}
              disabled={!findQuery.trim()}
              className="px-3 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg disabled:opacity-40"
            >
              সব পরিবর্তন
            </button>
            {replaceFeedback && (
              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>{replaceFeedback}</span>
              </span>
            )}
            <button
              type="button"
              onClick={() => setShowFindReplace(false)}
              className="p-1 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Reading View with Left ToC Sidebar (Desktop) and Smooth Flowing Cards */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Collapsible Table of Contents Sidebar */}
        {showToc && tocEntries.length > 0 && (
          <aside className="hidden md:block w-64 lg:w-72 border-r border-slate-200/80 dark:border-slate-800/80 bg-white/60 dark:bg-slate-900/40 overflow-y-auto p-4 shrink-0">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                <ListTree className="w-3.5 h-3.5 text-indigo-600" />
                <span>সূচিপত্র ({tocEntries.length.toLocaleString('bn-BD')})</span>
              </h2>
            </div>

            <nav aria-label="নোটের সূচিপত্র" className="space-y-1">
              {tocEntries.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  onClick={() => handleJumpTo(entry.id)}
                  className={`w-full text-left flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl text-xs hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors ${
                    entry.level === 0
                      ? 'font-bold text-slate-900 dark:text-white'
                      : entry.level === 1
                        ? 'pl-5 text-slate-700 dark:text-slate-300'
                        : 'pl-8 text-slate-500 dark:text-slate-400'
                  }`}
                >
                  <ChevronRight className="w-3 h-3 shrink-0 text-slate-400" />
                  <span className="truncate">{entry.text}</span>
                </button>
              ))}
            </nav>
          </aside>
        )}

        {/* Main Reading Scroll Canvas */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-6 pb-28 md:pb-12"
        >
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Sections Loop */}
            {(note.sections || []).map((sec, idx) => {
              const secMatches = matchStats.matchesBySection[sec.id] || 0;
              return (
                <article
                  key={sec.id}
                  id={`toc-sec-${sec.id}`}
                  className="p-5 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm scroll-mt-24 transition-shadow hover:shadow-md"
                >
                  {/* Section Title Header Bar */}
                  <header className="flex items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-indigo-600 text-white text-xs sm:text-sm font-bold flex items-center justify-center shrink-0 tabular-nums shadow-xs">
                        {idx + 1}
                      </span>
                      <h2
                        className={`text-base sm:text-xl font-bold text-slate-900 dark:text-white truncate ${fontClass}`}
                      >
                        {sec.title || `অনুচ্ছেদ ${idx + 1}`}
                      </h2>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {findQuery && secMatches > 0 && (
                        <span className="text-xs font-mono tabular-nums text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950">
                          {secMatches}টি মিল
                        </span>
                      )}

                      <button
                        type="button"
                        onClick={() => handleCopySection(sec.id, sec.content)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="এই অনুচ্ছেদ কপি করুন"
                      >
                        {copiedSectionId === sec.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </header>

                  {/* Rendered Markdown with Custom Font Size */}
                  <div style={{ fontSize: `${fontSize}px` }}>
                    <MarkdownRenderer
                      content={sec.content}
                      sectionId={sec.id}
                      fontClassName={fontClass}
                    />
                  </div>
                </article>
              );
            })}

            {/* Note Tags Footer */}
            {note.tags && note.tags.length > 0 && (
              <div className="p-4 rounded-xl bg-slate-100/60 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 flex flex-wrap items-center gap-2">
                <span className="font-semibold">ট্যাগসমূহ:</span>
                {note.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-medium border border-slate-200 dark:border-slate-700"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Floating Bottom Mobile Bar for Reading Actions (< md screens) */}
      <aside aria-label="মোবাইল পঠন টুলবার" className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 p-2.5 px-4 z-30 shadow-2xl safe-pb-bottom">
        <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
          <button
            type="button"
            onClick={() => setShowMobileToc(true)}
            className="flex-1 flex flex-col items-center justify-center py-1 text-slate-700 dark:text-slate-300 hover:text-indigo-600"
          >
            <ListTree className="w-5 h-5 text-indigo-600" />
            <span className="text-[10px] font-medium mt-0.5">সূচিপত্র</span>
          </button>

          <button
            type="button"
            onClick={onOpenReadingMode}
            className="flex-1 flex flex-col items-center justify-center py-1 text-slate-700 dark:text-slate-300 hover:text-indigo-600"
          >
            <BookOpen className="w-5 h-5 text-emerald-600" />
            <span className="text-[10px] font-medium mt-0.5">পঠন মোড</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setAiInitialAction('summarize');
              setIsAiModalOpen(true);
            }}
            className="flex-1 flex flex-col items-center justify-center py-1 text-indigo-600 dark:text-indigo-400"
          >
            <Sparkles className="w-5 h-5" />
            <span className="text-[10px] font-medium mt-0.5">Gemini AI</span>
          </button>

          <button
            type="button"
            onClick={onEdit}
            className="flex-[1.4] flex items-center justify-center gap-1.5 py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl shadow-md active:scale-95 transition-all"
          >
            <Edit3 className="w-4 h-4" />
            <span>সম্পাদনা</span>
          </button>
        </div>
      </aside>

      {/* Mobile Table of Contents Modal Bottom Sheet */}
      {showMobileToc && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-h-[80vh] flex flex-col overflow-hidden animate-slide-up">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ListTree className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  সূচিপত্র (দ্রুত লাফ দিন)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowMobileToc(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-1.5">
              {tocEntries.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-6">কোনো অনুচ্ছেদ পাওয়া যায়নি</p>
              ) : (
                tocEntries.map((entry) => (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() => {
                      setShowMobileToc(false);
                      handleJumpTo(entry.id);
                    }}
                    className={`w-full text-left flex items-center gap-2 p-2.5 rounded-xl text-xs hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors ${
                      entry.level === 0
                        ? 'font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800/50'
                        : 'pl-6 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                    <span className="truncate">{entry.text}</span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Gemini AI Action Modal */}
      {isAiModalOpen && (
        <AIActionModal
          isOpen={isAiModalOpen}
          onClose={() => setIsAiModalOpen(false)}
          note={note}
          categories={categories || []}
          initialAction={aiInitialAction}
          onApplyToNote={onUpdateNoteSections}
        />
      )}
    </div>
  );
};

export default NoteReaderView;
