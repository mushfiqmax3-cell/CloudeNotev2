'use client';

import React from 'react';
import { Download } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, promptInstall } = usePWAInstall();

  if (isInstalled || !isInstallable) {
    return null;
  }

  return (
    <button
      type="button"
      onClick={promptInstall}
      className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
      title="অ্যাপটি ডিভাইসে ইনস্টল করুন"
    >
      <Download className="w-3.5 h-3.5" />
      <span>অ্যাপ ইনস্টল</span>
    </button>
  );
};
export default PWAInstallButton;
