'use client';

import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Save,
  X,
  Plus,
  Trash2,
  ListTree,
  Search,
  Replace,
  Sparkles,
  Eye,
  Edit3,
  Wand2,
  RotateCcw,
  ChevronRight,
  Check,
  Loader2,
  ArrowUp,
  ArrowDown,
  Type,
  Database,
  Bold,
  Italic,
  Heading2,
  Heading3,
  Calculator,
  Table as TableIcon,
  List,
  ListOrdered,
  Code,
  Quote,
  Layers,
  Pin,
  Palette,
  CheckSquare,
  FolderSync,
} from 'lucide-react';
import type {
  AIActionType,
  NoteDraft,
  NoteFontFamily,
  NoteItem,
  NoteSection,
} from '../lib/types';
import { executeAIAction } from '../lib/gemini-service';
import {
  smartCleanAIPaste,
  normalizeUnicodeText,
  computeSectionsMetrics,
  computeTextMetrics,
  extractTocEntries,
  findMatchesInSections,
  replaceInSections,
} from '../lib/text-normalizer';
import {
  saveAutoDraft,
  getAutoDraft,
  clearAutoDraft,
  MAX_FIRESTORE_INLINE_BYTES,
} from '../lib/storage';
import { MarkdownRenderer } from './MarkdownRenderer';

interface NoteEditorProps {
  initialNote?: NoteItem | null;
  categories: string[];
  onCreateCategory?: (name: string) => Promise<string> | string;
  onSave: (noteData: NoteItem) => Promise<void>;
  onCancel: () => void;
}

interface SectionEditorCardProps {
  section: NoteSection;
  index: number;
  totalSections: number;
  isPreview: boolean;
  fontClass: string;
  matchCount: number;
  isAiProcessing: boolean;
  onUpdateTitle: (id: string, title: string) => void;
  onUpdateContent: (id: string, content: string) => void;
  onRemoveSection: (id: string) => void;
  onMoveSection: (index: number, direction: 'up' | 'down') => void;
  onSmartCleanSection: (id: string) => void;
  onRunSectionAI: (id: string, action: AIActionType) => void;
}

const FONT_CLASS_MAP: Record<NoteFontFamily, string> = {
  sans: 'font-bengali-sans',
  serif: 'font-bengali-serif',
  hind: 'font-bengali-hind',
  tiro: 'font-bengali-tiro',
  mono: 'font-bengali-mono',
};

/**
 * Helper to insert markdown or math templates at the current cursor position in a textarea
 */
function insertFormatting(
  textarea: HTMLTextAreaElement | null,
  before: string,
  after: string = '',
  defaultText: string = ''
): { newContent: string; newCursorPos: number } | null {
  if (!textarea) return null;
  const start = textarea.selectionStart ?? 0;
  const end = textarea.selectionEnd ?? 0;
  const value = textarea.value;
  const selected = value.substring(start, end) || defaultText;
  const replacement = `${before}${selected}${after}`;
  const newContent = value.substring(0, start) + replacement + value.substring(end);
  const newCursorPos = start + before.length + selected.length;
  return { newContent, newCursorPos };
}

/**
 * Memoized Section Editor Card:
 * Ensures typing in one section of a 50,000+ word note has zero lag and never re-renders sibling sections.
 */
const SectionEditorCard: React.FC<SectionEditorCardProps> = React.memo(
  ({
    section,
    index,
    totalSections,
    isPreview,
    fontClass,
    matchCount,
    isAiProcessing,
    onUpdateTitle,
    onUpdateContent,
    onRemoveSection,
    onMoveSection,
    onSmartCleanSection,
    onRunSectionAI,
  }) => {
    const [aiMenuOpen, setAiMenuOpen] = useState(false);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // Memoized per-section word count
    const secMetrics = useMemo(() => computeTextMetrics(section.content), [section.content]);

    const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
      const pasted = e.clipboardData.getData('text/plain');
      if (!pasted) return;

      // Smart NFC & AI LaTeX cleaner
      const cleaned = smartCleanAIPaste(pasted);
      if (cleaned !== pasted) {
        e.preventDefault();
        const target = e.currentTarget;
        const start = target.selectionStart ?? section.content.length;
        const end = target.selectionEnd ?? section.content.length;
        const nextValue =
          section.content.slice(0, start) + cleaned + section.content.slice(end);
        onUpdateContent(section.id, nextValue);
      }
    };

    const handleApplyFormatting = (before: string, after: string = '', defaultText: string = '') => {
      const result = insertFormatting(textareaRef.current, before, after, defaultText);
      if (result) {
        onUpdateContent(section.id, result.newContent);
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.focus();
            textareaRef.current.setSelectionRange(result.newCursorPos, result.newCursorPos);
          }
        }, 10);
      }
    };

    return (
      <div
        id={`editor-toc-sec-${section.id}`}
        className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm scroll-mt-28 overflow-hidden transition-all"
      >
        {/* Section Header Bar - Fully Mobile-Friendly */}
        <div className="p-3.5 sm:p-4 bg-slate-50/90 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex flex-col gap-2.5">
          {/* Row 1: Section Number + Section Title Input */}
          <div className="flex items-center gap-2.5 w-full">
            <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-indigo-600 text-white text-xs sm:text-sm font-bold flex items-center justify-center shrink-0 tabular-nums shadow-xs">
              {index + 1}
            </span>
            <input
              type="text"
              value={section.title}
              onChange={(e) => onUpdateTitle(section.id, e.target.value)}
              placeholder={`অনুচ্ছেদ ${index + 1}-এর শিরোনাম...`}
              aria-label={`অনুচ্ছেদ ${index + 1}-এর শিরোনাম`}
              className={`flex-1 min-w-0 px-3 py-1.5 text-sm sm:text-base font-semibold rounded-lg border border-slate-200 dark:border-slate-700 hover:border-indigo-400 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-500 bg-white dark:bg-slate-900 text-slate-900 dark:text-white transition-all ${fontClass}`}
            />
          </div>

          {/* Row 2: Responsive Control Options for Mobile and Desktop */}
          <div className="flex items-center justify-between flex-wrap gap-2 pt-1 border-t border-slate-200/50 dark:border-slate-700/50">
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              <span className="px-2 py-0.5 rounded-md bg-slate-200/60 dark:bg-slate-800 text-[11px] font-medium text-slate-700 dark:text-slate-300">
                {secMetrics.wordCount.toLocaleString('bn-BD')} শব্দ
              </span>
              {matchCount > 0 && (
                <span className="px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-[11px] font-medium text-indigo-600 dark:text-indigo-400">
                  {matchCount}টি মিল
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              {/* Smart Clean & AI LaTeX button */}
              <button
                type="button"
                onClick={() => onSmartCleanSection(section.id)}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 min-h-[36px] text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors active:scale-95"
                title="ইউনিকোড NFC ও AI LaTeX ($$...$$) স্বয়ংক্রিয় রূপান্তর"
              >
                <Wand2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span className="hidden xs:inline sm:inline">ক্লিন ফরম্যাট</span>
              </button>

              {/* AI Writing Assistant Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  disabled={isAiProcessing}
                  onClick={() => setAiMenuOpen((prev) => !prev)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/70 hover:bg-indigo-100 dark:hover:bg-indigo-900 border border-indigo-200 dark:border-indigo-800 rounded-lg transition-colors active:scale-95"
                >
                  {isAiProcessing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  )}
                  <span>এআই সহায়ক</span>
                </button>

                {aiMenuOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-30"
                      onClick={() => setAiMenuOpen(false)}
                    />
                    <div className="absolute right-0 top-full mt-1.5 w-60 sm:w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl py-1.5 z-40 text-xs">
                      <div className="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800">
                        স্মার্ট এআই অ্যাকশন
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setAiMenuOpen(false);
                          onRunSectionAI(section.id, 'summarize');
                        }}
                        className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 flex items-center gap-2"
                      >
                        <ListTree className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Summarize (৩-৪ পয়েন্ট সারসংক্ষেপ)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAiMenuOpen(false);
                          onRunSectionAI(section.id, 'extract_todos');
                        }}
                        className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 flex items-center gap-2"
                      >
                        <CheckSquare className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Extract To-Dos (চেকলিস্ট তৈরি)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAiMenuOpen(false);
                          onRunSectionAI(section.id, 'polish_text');
                        }}
                        className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 flex items-center gap-2"
                      >
                        <Wand2 className="w-3.5 h-3.5 text-amber-500" />
                        <span>Polish Text (টেক্সট পরিমার্জন)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAiMenuOpen(false);
                          onRunSectionAI(section.id, 'auto_categorize');
                        }}
                        className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 flex items-center gap-2"
                      >
                        <FolderSync className="w-3.5 h-3.5 text-blue-500" />
                        <span>Auto-Categorize (ক্যাটাগরি নির্ধারণ)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAiMenuOpen(false);
                          onRunSectionAI(section.id, 'format');
                        }}
                        className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 flex items-center gap-2 border-t border-slate-100 dark:border-slate-800"
                      >
                        <Type className="w-3.5 h-3.5 text-slate-500" />
                        <span>মার্কডাউন ও গণিত ফরম্যাট</span>
                      </button>
                    </div>
                  </>
                )}
              </div>

              {/* Move Up / Down */}
              <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden bg-white dark:bg-slate-800">
                <button
                  type="button"
                  disabled={index === 0}
                  onClick={() => onMoveSection(index, 'up')}
                  className="p-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-30 transition-colors"
                  title="অনুচ্ছেদ উপরে নিন"
                  aria-label="অনুচ্ছেদ উপরে নিন"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  disabled={index === totalSections - 1}
                  onClick={() => onMoveSection(index, 'down')}
                  className="p-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-30 border-l border-slate-200 dark:border-slate-700 transition-colors"
                  title="অনুচ্ছেদ নিচে নিন"
                  aria-label="অনুচ্ছেদ নিচে নিন"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Remove Section */}
              {totalSections > 1 && (
                <button
                  type="button"
                  onClick={() => onRemoveSection(section.id)}
                  className="p-2 min-h-[36px] min-w-[36px] flex items-center justify-center text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 border border-slate-200 dark:border-slate-700 hover:border-rose-300 rounded-lg transition-colors"
                  title="অনুচ্ছেদটি মুছে ফেলুন"
                  aria-label="অনুচ্ছেদটি মুছে ফেলুন"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Quick-Insert Markdown & Math Toolbar (Designed for Phone Touch Control) */}
        {!isPreview && (
          <div className="px-3 py-2 bg-slate-100/70 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto text-xs no-scrollbar">
            <button
              type="button"
              onClick={() => handleApplyFormatting('**', '**', 'বোল্ড টেক্সট')}
              className="p-2 min-w-[36px] h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center justify-center font-bold shrink-0 transition-colors"
              title="বোল্ড (**লেখা**)"
            >
              <Bold className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('*', '*', 'ইটালিক টেক্সট')}
              className="p-2 min-w-[36px] h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center justify-center italic shrink-0 transition-colors"
              title="ইটালিক (*লেখা*)"
            >
              <Italic className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('\n## ', '\n', 'শিরোনাম')}
              className="px-2.5 h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center gap-1 shrink-0 font-semibold transition-colors"
              title="শিরোনাম (## H2)"
            >
              <Heading2 className="w-3.5 h-3.5" />
              <span className="text-[11px]">H2</span>
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('\n### ', '\n', 'সাব-শিরোনাম')}
              className="px-2.5 h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950 flex items-center gap-1 shrink-0 font-semibold transition-colors"
              title="সাব-শিরোনাম (### H3)"
            >
              <Heading3 className="w-3.5 h-3.5" />
              <span className="text-[11px]">H3</span>
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('$', '$', 'E = mc^2')}
              className="px-2.5 h-9 rounded-lg bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 flex items-center gap-1 shrink-0 font-medium transition-colors"
              title="ইনলাইন গণিত সমীকরণ ($...$)"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>$গণিত$</span>
            </button>
            <button
              type="button"
              onClick={() =>
                handleApplyFormatting(
                  '\n\n$$\n\\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}\n$$\n\n',
                  '',
                  ''
                )
              }
              className="px-2.5 h-9 rounded-lg bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 flex items-center gap-1 shrink-0 font-medium transition-colors"
              title="ডিসপ্লে গণিত ব্লক ($$...$$)"
            >
              <span className="font-mono text-xs">$$ব্লক$$</span>
            </button>
            <button
              type="button"
              onClick={() =>
                handleApplyFormatting(
                  '\n\n| বিষয় | বিবরণ | সূত্র |\n| --- | --- | --- |\n| বল | ভর × ত্বরণ | $F = ma$ |\n| শক্তি | কাজের সামর্থ্য | $W = Fd$ |\n\n'
                )
              }
              className="px-2.5 h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 flex items-center gap-1 shrink-0 transition-colors"
              title="টেবিল ইনসার্ট করুন"
            >
              <TableIcon className="w-3.5 h-3.5 text-blue-500" />
              <span>টেবিল</span>
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('\n- ', '\n', 'তালিকা পয়েন্ট')}
              className="p-2 min-w-[36px] h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 flex items-center justify-center shrink-0 transition-colors"
              title="বুলেট তালিকা (- পয়েন্ট)"
            >
              <List className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('\n- [ ] ', '\n', 'করণীয় কাজ')}
              className="px-2.5 h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 flex items-center gap-1 shrink-0 transition-colors"
              title="চেকলিস্ট (- [ ] কাজ)"
            >
              <CheckSquare className="w-3.5 h-3.5 text-emerald-500" />
              <span>চেকলিস্ট</span>
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('\n1. ', '\n', 'ক্রমিক পয়েন্ট')}
              className="p-2 min-w-[36px] h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 flex items-center justify-center shrink-0 transition-colors"
              title="সংখ্যা তালিকা (1. পয়েন্ট)"
            >
              <ListOrdered className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('\n```\n', '\n```\n', '// কোড লিখুন')}
              className="p-2 min-w-[36px] h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 flex items-center justify-center shrink-0 transition-colors"
              title="কোড ব্লক (```code```)"
            >
              <Code className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => handleApplyFormatting('\n> ', '\n', 'উদ্ধৃতি')}
              className="p-2 min-w-[36px] h-9 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 flex items-center justify-center shrink-0 transition-colors"
              title="উদ্ধৃতি (> Quote)"
            >
              <Quote className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Section Body: Live Markdown / KaTeX Preview OR Fast Native Textarea */}
        <div className="p-4 sm:p-5">
          {isPreview ? (
            <div className="min-h-[160px] p-4 bg-slate-50/70 dark:bg-slate-950/50 rounded-xl border border-slate-200/70 dark:border-slate-800/80">
              {section.content.trim() ? (
                <MarkdownRenderer
                  content={section.content}
                  sectionId={section.id}
                  fontClassName={fontClass}
                />
              ) : (
                <p className="text-xs text-slate-400 italic">এই অনুচ্ছেদে কোনো বিষয়বস্তু নেই...</p>
              )}
            </div>
          ) : (
            <textarea
              ref={textareaRef}
              value={section.content}
              onChange={(e) => onUpdateContent(section.id, e.target.value)}
              onPaste={handlePaste}
              placeholder="এখানে নোট লিখুন... মার্কডাউন, গণিত সূত্র ($E=mc^2$), কোড বা টেবিল সমর্থিত..."
              rows={Math.max(6, Math.min(22, (section.content.match(/\n/g) || []).length + 3))}
              className={`w-full p-3 sm:p-4 text-sm sm:text-base leading-relaxed rounded-xl border border-slate-200 dark:border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 resize-y focus:outline-none transition-all ${fontClass}`}
            />
          )}
        </div>
      </div>
    );
  }
);

SectionEditorCard.displayName = 'SectionEditorCard';

export const NoteEditor: React.FC<NoteEditorProps> = ({
  initialNote,
  categories,
  onCreateCategory,
  onSave,
  onCancel,
}) => {
  const [isAddingFolder, setIsAddingFolder] = useState<boolean>(false);
  const [newFolderName, setNewFolderName] = useState<string>('');
  const [noteId] = useState<string>(
    () => initialNote?.id || `note-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
  );

  const [title, setTitle] = useState<string>(initialNote?.title || '');
  const [category, setCategory] = useState<string>(
    initialNote?.category || categories[0] || 'সাধারণ'
  );
  const [subCategory, setSubCategory] = useState<string>(initialNote?.subCategory || '');
  const [tagsInput, setTagsInput] = useState<string>((initialNote?.tags || []).join(', '));
  const [fontFamily, setFontFamily] = useState<NoteFontFamily>(
    initialNote?.fontFamily || 'sans'
  );
  const [sections, setSections] = useState<NoteSection[]>(() =>
    initialNote?.sections && initialNote.sections.length > 0
      ? initialNote.sections
      : [{ id: 'sec-1', title: 'মূল অনুচ্ছেদ', content: initialNote?.content || '' }]
  );

  const [isPreviewMode, setIsPreviewMode] = useState<boolean>(false);
  const [showToc, setShowToc] = useState<boolean>(false);
  const [showMobileTocModal, setShowMobileTocModal] = useState<boolean>(false);
  const [showFindReplace, setShowFindReplace] = useState<boolean>(false);
  const [findQuery, setFindQuery] = useState<string>('');
  const [replaceQuery, setReplaceQuery] = useState<string>('');
  const [caseSensitive, setCaseSensitive] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [aiProcessingSectionId, setAiProcessingSectionId] = useState<string | null>(null);
  const [isFullNoteAiLoading, setIsFullNoteAiLoading] = useState<boolean>(false);
  const [fullAiMenuOpen, setFullAiMenuOpen] = useState<boolean>(false);
  const [isPinned, setIsPinned] = useState<boolean>(Boolean(initialNote?.isPinned));
  const [noteColor, setNoteColor] = useState<string>(initialNote?.color || '');
  const [showColorPicker, setShowColorPicker] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Auto-Draft Recovery State
  const [recoverableDraft, setRecoverableDraft] = useState<NoteDraft | null>(null);
  const isDirtyRef = useRef<boolean>(false);

  const commitNewFolder = async () => {
    const name = newFolderName.trim();
    if (!name) {
      setIsAddingFolder(false);
      return;
    }
    const finalName = onCreateCategory ? await onCreateCategory(name) : name;
    isDirtyRef.current = true;
    setCategory(finalName || name);
    setNewFolderName('');
    setIsAddingFolder(false);
  };

  // Check IndexedDB for an unsaved auto-draft on mount
  useEffect(() => {
    let active = true;
    const checkKey = initialNote?.id || 'new-note-draft';
    getAutoDraft(checkKey).then((draft) => {
      if (!active || !draft) return;
      const initialUpdated = initialNote?.updatedAt
        ? new Date(initialNote.updatedAt).getTime()
        : 0;
      const draftUpdated = new Date(draft.updatedAt).getTime();

      if (draftUpdated > initialUpdated && (draft.title || draft.sections.some((s) => s.content))) {
        setRecoverableDraft(draft);
      }
    });
    return () => {
      active = false;
    };
  }, [initialNote?.id, initialNote?.updatedAt]);

  // Debounced Auto-Draft saving to IndexedDB (every 1.2s when user edits)
  useEffect(() => {
    if (!isDirtyRef.current) return;
    const draftKey = initialNote?.id || 'new-note-draft';
    const timer = setTimeout(() => {
      const parsedTags = tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);
      saveAutoDraft({
        noteId: draftKey,
        title,
        category,
        subCategory,
        sections,
        tags: parsedTags,
        fontFamily,
        updatedAt: new Date().toISOString(),
      });
    }, 1200);

    return () => clearTimeout(timer);
  }, [title, category, subCategory, sections, tagsInput, fontFamily, initialNote?.id]);

  const handleRestoreDraft = () => {
    if (!recoverableDraft) return;
    setTitle(recoverableDraft.title);
    setCategory(recoverableDraft.category);
    setSubCategory(recoverableDraft.subCategory || '');
    setSections(recoverableDraft.sections);
    setTagsInput((recoverableDraft.tags || []).join(', '));
    if (recoverableDraft.fontFamily) {
      setFontFamily(recoverableDraft.fontFamily);
    }
    setRecoverableDraft(null);
    setStatusMessage('অসংরক্ষিত খসড়া সফলভাবে পুনরুদ্ধার করা হয়েছে!');
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleDiscardDraft = async () => {
    const draftKey = initialNote?.id || 'new-note-draft';
    await clearAutoDraft(draftKey);
    setRecoverableDraft(null);
  };

  // Memoized total metrics across all sections
  const totalMetrics = useMemo(() => computeSectionsMetrics(sections), [sections]);

  // Memoized Table of Contents entries
  const tocEntries = useMemo(() => extractTocEntries(sections), [sections]);

  // Memoized Find matches
  const matchStats = useMemo(
    () => findMatchesInSections(sections, findQuery, caseSensitive),
    [sections, findQuery, caseSensitive]
  );

  const handleUpdateSectionTitle = useCallback((id: string, newTitle: string) => {
    isDirtyRef.current = true;
    setSections((prev) =>
      prev.map((sec) => (sec.id === id ? { ...sec, title: newTitle } : sec))
    );
  }, []);

  const handleUpdateSectionContent = useCallback((id: string, newContent: string) => {
    isDirtyRef.current = true;
    setSections((prev) =>
      prev.map((sec) => (sec.id === id ? { ...sec, content: newContent } : sec))
    );
  }, []);

  const handleAddSection = useCallback(() => {
    isDirtyRef.current = true;
    setSections((prev) => [
      ...prev,
      {
        id: `sec-${Date.now()}-${prev.length + 1}`,
        title: `অনুচ্ছেদ ${prev.length + 1}`,
        content: '',
      },
    ]);
    setTimeout(() => {
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    }, 100);
  }, []);

  const handleRemoveSection = useCallback((id: string) => {
    isDirtyRef.current = true;
    setSections((prev) => (prev.length > 1 ? prev.filter((s) => s.id !== id) : prev));
  }, []);

  const handleMoveSection = useCallback((index: number, direction: 'up' | 'down') => {
    isDirtyRef.current = true;
    setSections((prev) => {
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= prev.length) return prev;
      const copy = [...prev];
      const [moved] = copy.splice(index, 1);
      copy.splice(targetIndex, 0, moved);
      return copy;
    });
  }, []);

  const handleSmartCleanSection = useCallback((id: string) => {
    isDirtyRef.current = true;
    setSections((prev) =>
      prev.map((sec) =>
        sec.id === id
          ? {
              ...sec,
              title: normalizeUnicodeText(sec.title),
              content: smartCleanAIPaste(sec.content),
            }
          : sec
      )
    );
    setStatusMessage('ইউনিকোড NFC ও LaTeX সমীকরণ ফরম্যাট করা হয়েছে');
    setTimeout(() => setStatusMessage(null), 2500);
  }, []);

  const handleRunSectionAI = useCallback(
    async (id: string, action: AIActionType) => {
      const targetSection = sections.find((s) => s.id === id);
      if (!targetSection || !targetSection.content.trim()) {
        setStatusMessage('অনুচ্ছেদে কিছু টেক্সট লিখুন');
        setTimeout(() => setStatusMessage(null), 2500);
        return;
      }

      setAiProcessingSectionId(id);
      setStatusMessage('Gemini AI কাজ করছে...');

      try {
        const response = await executeAIAction({
          action: action as any,
          text: targetSection.content,
          categories,
          noteTitle: title || targetSection.title,
        });

        if (!response.success) {
          throw new Error(response.error || 'এআই প্রক্রিয়াকরণ ব্যর্থ হয়েছে');
        }

        isDirtyRef.current = true;
        setSections((prev) =>
          prev.map((sec) => {
            if (sec.id !== id) return sec;
            if (action === 'summarize') {
              return {
                ...sec,
                content: `${sec.content.trim()}\n\n### সারসংক্ষেপ (AI Summary)\n${response.result}`,
              };
            }
            if (action === 'extract_todos') {
              return {
                ...sec,
                content: `${sec.content.trim()}\n\n### টু-ডু চেকলিস্ট (To-Do List)\n${response.result}`,
              };
            }
            if (action === 'auto_categorize' && response.suggestedCategory) {
              setCategory(response.suggestedCategory);
              return sec;
            }
            return {
              ...sec,
              content: response.result,
            };
          })
        );

        if (action === 'auto_categorize' && response.suggestedCategory) {
          setCategory(response.suggestedCategory);
          setStatusMessage(`ক্যাটাগরি সেট: ${response.suggestedCategory}`);
        } else {
          setStatusMessage('Gemini AI সফলভাবে সম্পন্ন করেছে');
        }
      } catch (err: unknown) {
        setStatusMessage(
          err instanceof Error ? err.message : 'এআই সার্ভিসের সাথে যোগাযোগ ব্যর্থ হয়েছে'
        );
      } finally {
        setAiProcessingSectionId(null);
        setTimeout(() => setStatusMessage(null), 3500);
      }
    },
    [sections, categories, title]
  );

  const handleRunWholeNoteAI = async (action: AIActionType) => {
    const fullText = sections
      .map((s) => `${s.title}\n${s.content}`)
      .join('\n\n')
      .trim();

    if (!fullText) {
      setStatusMessage('নোটটিতে কিছু টেক্সট লিখুন');
      setTimeout(() => setStatusMessage(null), 2500);
      return;
    }

    setIsFullNoteAiLoading(true);
    setFullAiMenuOpen(false);
    setStatusMessage('Gemini AI নোট বিশ্লেষণ করছে...');

    try {
      const response = await executeAIAction({
        action: action as any,
        text: fullText,
        categories,
        noteTitle: title,
      });

      if (!response.success) {
        throw new Error(response.error || 'এআই প্রক্রিয়া ব্যর্থ হয়েছে');
      }

      isDirtyRef.current = true;
      if (action === 'auto_categorize' && response.suggestedCategory) {
        setCategory(response.suggestedCategory);
        setStatusMessage(`ক্যাটাগরি নির্বাচন করা হয়েছে: ${response.suggestedCategory}`);
      } else if (action === 'summarize') {
        setSections((prev) => [
          ...prev,
          {
            id: `sec-ai-${Date.now()}`,
            title: 'সারসংক্ষেপ (AI Summary)',
            content: response.result,
          },
        ]);
        setStatusMessage('সারসংক্ষেপ অনুচ্ছেদ যুক্ত করা হয়েছে');
      } else if (action === 'extract_todos') {
        setSections((prev) => [
          ...prev,
          {
            id: `sec-ai-${Date.now()}`,
            title: 'টু-ডু তালিকা (To-Do Checklist)',
            content: response.result,
          },
        ]);
        setStatusMessage('টু-ডু চেকলিস্ট যোগ করা হয়েছে');
      } else if (action === 'polish_text') {
        setSections((prev) => {
          if (prev.length === 0) return prev;
          const [first, ...rest] = prev;
          return [{ ...first, content: response.result }, ...rest];
        });
        setStatusMessage('টেক্সট পরিমার্জন সম্পন্ন হয়েছে');
      }
    } catch (err: unknown) {
      setStatusMessage(
        err instanceof Error ? err.message : 'এআই সার্ভিসের সাথে সংযোগে ত্রুটি'
      );
    } finally {
      setIsFullNoteAiLoading(false);
      setTimeout(() => setStatusMessage(null), 3500);
    }
  };

  const handleReplaceInEditor = (replaceAll: boolean) => {
    if (!findQuery.trim()) return;
    isDirtyRef.current = true;
    const { sections: updated, replacedCount } = replaceInSections(
      sections,
      findQuery,
      replaceQuery,
      { caseSensitive, replaceAll }
    );
    setSections(updated);
    setStatusMessage(
      replacedCount > 0
        ? `${replacedCount.toLocaleString('bn-BD')}টি স্থানে প্রতিস্থাপন করা হয়েছে`
        : 'কোনো মিল পাওয়া যায়নি'
    );
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleSaveSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!title.trim()) {
      setStatusMessage('নোটের একটি শিরোনাম দিন');
      setTimeout(() => setStatusMessage(null), 3000);
      return;
    }

    setIsSaving(true);
    try {
      const parsedTags = tagsInput
        .split(',')
        .map((t) => normalizeUnicodeText(t.trim()))
        .filter(Boolean);

      const now = new Date().toISOString();
      const noteToSave: NoteItem = {
        id: noteId,
        title: normalizeUnicodeText(title.trim()),
        category: normalizeUnicodeText(category.trim() || 'সাধারণ'),
        subCategory: subCategory.trim() ? normalizeUnicodeText(subCategory.trim()) : undefined,
        content: '', // Hydrated automatically
        sections: sections.map((sec, idx) => ({
          id: sec.id || `sec-${idx + 1}`,
          title: normalizeUnicodeText(sec.title || `অনুচ্ছেদ ${idx + 1}`),
          content: smartCleanAIPaste(sec.content || ''),
        })),
        tags: parsedTags,
        isFavorite: initialNote?.isFavorite ?? false,
        isPinned,
        color: noteColor || undefined,
        isDeleted: false,
        deletedAt: null,
        pinHash: initialNote?.pinHash ?? null,
        isLocked: Boolean(initialNote?.pinHash),
        fontFamily,
        createdAt: initialNote?.createdAt || now,
        updatedAt: now,
      };

      await clearAutoDraft(initialNote?.id || 'new-note-draft');
      await onSave(noteToSave);
    } finally {
      setIsSaving(false);
    }
  };

  const fontClass = FONT_CLASS_MAP[fontFamily];
  const willAutoChunk = totalMetrics.byteSize > MAX_FIRESTORE_INLINE_BYTES;

  return (
    <form onSubmit={handleSaveSubmit} className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 overflow-hidden relative">
      {/* Top Header - Responsive for Mobile & Desktop */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-20 shadow-xs">
        {/* Main Header Bar */}
        <div className="flex items-center justify-between gap-2.5 px-4 sm:px-6 py-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={onCancel}
              className="p-2 min-h-[40px] min-w-[40px] rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center shrink-0"
              title="ফিরে যান"
              aria-label="বাতিল ও ফিরে যান"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate">
                {initialNote ? 'নোট সম্পাদনা' : 'নতুন নোট'}
              </h2>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                <span>{totalMetrics.wordCount.toLocaleString('bn-BD')} শব্দ</span>
                <span>·</span>
                <span>{Math.max(1, Math.round(totalMetrics.byteSize / 1024))} KB</span>
                {willAutoChunk && (
                  <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-emerald-600 font-medium">
                    <Database className="w-3 h-3" />
                    <span>চাংকড (&gt;600KB)</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Desktop & Mobile Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {statusMessage && (
              <span className="hidden sm:inline-flex items-center gap-1 text-xs font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2.5 py-1 rounded-lg animate-fade-in">
                <Check className="w-3.5 h-3.5" />
                <span>{statusMessage}</span>
              </span>
            )}

            {/* Desktop Quick Toggles */}
            <div className="hidden md:flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setShowToc((prev) => !prev)}
                className={`flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                  showToc
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800'
                    : 'text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <ListTree className="w-3.5 h-3.5" />
                <span>সূচিপত্র</span>
              </button>

              <button
                type="button"
                onClick={() => setShowFindReplace((prev) => !prev)}
                className={`flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                  showFindReplace
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800'
                    : 'text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                <span>খুঁজুন</span>
              </button>

              <button
                type="button"
                onClick={() => setIsPreviewMode((prev) => !prev)}
                className={`flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                  isPreviewMode
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800'
                    : 'text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {isPreviewMode ? <Edit3 className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{isPreviewMode ? 'এডিট মোড' : 'প্রিভিউ'}</span>
              </button>
            </div>

            {/* Gemini AI Whole Note Assistant */}
            <div className="relative">
              <button
                type="button"
                disabled={isFullNoteAiLoading}
                onClick={() => setFullAiMenuOpen((prev) => !prev)}
                className="flex items-center gap-1.5 px-3 py-1.5 min-h-[38px] text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-xs"
                title="Google Gemini AI Assistant"
              >
                {isFullNoteAiLoading ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>Gemini AI</span>
              </button>

              {fullAiMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-30"
                    onClick={() => setFullAiMenuOpen(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 w-64 bg-white dark:bg-[#111111] border border-slate-200 dark:border-[#262626] rounded-2xl shadow-2xl py-1.5 z-40 text-xs">
                    <div className="px-3.5 py-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-[#222222]">
                      Google Gemini AI Actions
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRunWholeNoteAI('summarize')}
                      className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-[#1a1a1a] flex items-center gap-2"
                    >
                      <ListTree className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Summarize (৩-৪ পয়েন্ট সারসংক্ষেপ)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRunWholeNoteAI('extract_todos')}
                      className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-[#1a1a1a] flex items-center gap-2"
                    >
                      <CheckSquare className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Extract To-Dos (চেকলিস্ট তৈরি)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRunWholeNoteAI('polish_text')}
                      className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-[#1a1a1a] flex items-center gap-2"
                    >
                      <Wand2 className="w-3.5 h-3.5 text-amber-500" />
                      <span>Polish Text (টেক্সট পরিমার্জন)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRunWholeNoteAI('auto_categorize')}
                      className="w-full px-3.5 py-2.5 text-left text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-[#1a1a1a] flex items-center gap-2"
                    >
                      <FolderSync className="w-3.5 h-3.5 text-blue-500" />
                      <span>Auto-Categorize (উপযুক্ত ক্যাটাগরি)</span>
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Pin to Top Button */}
            <button
              type="button"
              onClick={() => setIsPinned((prev) => !prev)}
              className={`p-2 min-h-[38px] min-w-[38px] rounded-xl border transition-colors flex items-center justify-center ${
                isPinned
                  ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-950 dark:border-indigo-800 dark:text-indigo-300'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={isPinned ? 'আনপিন করুন' : 'শীর্ষে পিন করুন'}
            >
              <Pin className={`w-4 h-4 ${isPinned ? 'fill-current' : ''}`} />
            </button>

            {/* Note Color Picker */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowColorPicker((prev) => !prev)}
                className="p-2 min-h-[38px] min-w-[38px] rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center"
                title="নোটের কালার ট্যাগ নির্বাচন করুন"
              >
                <Palette className="w-4 h-4" />
              </button>

              {showColorPicker && (
                <div className="absolute right-0 top-full mt-2 p-2 bg-white dark:bg-[#111111] border border-slate-200 dark:border-[#262626] rounded-xl shadow-xl z-40 flex items-center gap-1.5">
                  {[
                    { label: 'Default', value: '' },
                    { label: 'Indigo', value: '#6366f1' },
                    { label: 'Emerald', value: '#10b981' },
                    { label: 'Amber', value: '#f59e0b' },
                    { label: 'Rose', value: '#f43f5e' },
                    { label: 'Purple', value: '#a855f7' },
                    { label: 'Sky', value: '#0ea5e9' },
                  ].map((swatch) => (
                    <button
                      key={swatch.value || 'default'}
                      type="button"
                      onClick={() => {
                        setNoteColor(swatch.value);
                        setShowColorPicker(false);
                      }}
                      style={{ backgroundColor: swatch.value || '#94a3b8' }}
                      className="w-5 h-5 rounded-full border border-black/10 dark:border-white/20 transition-transform hover:scale-110 flex items-center justify-center"
                      title={swatch.label}
                    >
                      {noteColor === swatch.value && <Check className="w-3 h-3 text-white" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Primary Save Button - Large & Clear */}
            <button
              type="submit"
              disabled={isSaving}
              className="flex items-center justify-center gap-1.5 px-4 py-2 min-h-[40px] text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-sm active:scale-95 shrink-0"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              <span>{isSaving ? 'সংরক্ষণ...' : 'সংরক্ষণ করুন'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Quick Action Pill Bar (< md screens) */}
        <div className="flex md:hidden items-center gap-2 px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setIsPreviewMode((prev) => !prev)}
            className={`flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-medium rounded-lg border shrink-0 transition-colors ${
              isPreviewMode
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
            }`}
          >
            {isPreviewMode ? <Edit3 className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            <span>{isPreviewMode ? 'এডিট' : 'প্রিভিউ'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowMobileTocModal(true)}
            className="flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-medium rounded-lg border bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 shrink-0"
          >
            <ListTree className="w-3.5 h-3.5 text-indigo-500" />
            <span>সূচিপত্র ({tocEntries.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setShowFindReplace((prev) => !prev)}
            className={`flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-medium rounded-lg border shrink-0 ${
              showFindReplace
                ? 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
            }`}
          >
            <Search className="w-3.5 h-3.5 text-slate-500" />
            <span>খুঁজুন/পরিবর্তন</span>
          </button>

          <button
            type="button"
            onClick={handleAddSection}
            className="flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-medium rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ অনুচ্ছেদ</span>
          </button>
        </div>
      </header>

      {/* Auto-Draft Recovery Banner */}
      {recoverableDraft && (
        <div className="px-4 sm:px-6 py-2.5 bg-amber-50 dark:bg-amber-950/70 border-b border-amber-200 dark:border-amber-800 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 text-xs text-amber-900 dark:text-amber-200">
            <RotateCcw className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>অসংরক্ষিত ড্রাফট পাওয়া গেছে!</strong> ({new Date(recoverableDraft.updatedAt).toLocaleTimeString('bn-BD')})
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRestoreDraft}
              className="px-3 py-1 min-h-[32px] text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white rounded-lg transition-colors"
            >
              পুনরুদ্ধার করুন
            </button>
            <button
              type="button"
              onClick={handleDiscardDraft}
              className="px-2.5 py-1 min-h-[32px] text-xs font-medium text-amber-800 dark:text-amber-300 hover:underline"
            >
              বাতিল
            </button>
          </div>
        </div>
      )}

      {/* Find & Replace Bar - Mobile Responsive */}
      {showFindReplace && (
        <div className="p-3 sm:px-6 sm:py-3 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="flex items-center gap-1.5 flex-1 min-w-0">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              value={findQuery}
              onChange={(e) => setFindQuery(e.target.value)}
              placeholder="সব অনুচ্ছেদে শব্দ খুঁজুন..."
              aria-label="সব অনুচ্ছেদে শব্দ খুঁজুন"
              className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            {findQuery && (
              <span className="text-xs font-mono tabular-nums text-indigo-600 dark:text-indigo-400 shrink-0 px-1">
                {matchStats.totalMatches.toLocaleString('bn-BD')} মিল
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 flex-1 min-w-0">
            <Replace className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              value={replaceQuery}
              onChange={(e) => setReplaceQuery(e.target.value)}
              placeholder="পরিবর্তিত শব্দ লিখুন..."
              aria-label="পরিবর্তিত শব্দ লিখুন"
              className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center justify-between sm:justify-start gap-2 pt-1 sm:pt-0">
            <label className="flex items-center gap-1 text-xs text-slate-600 dark:text-slate-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={caseSensitive}
                onChange={(e) => setCaseSensitive(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span className="text-[11px]">Case</span>
            </label>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => handleReplaceInEditor(false)}
                className="px-2.5 py-1.5 text-xs font-medium bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50"
              >
                ১টি
              </button>
              <button
                type="button"
                onClick={() => handleReplaceInEditor(true)}
                className="px-3 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg"
              >
                সব পরিবর্তন
              </button>
              <button
                type="button"
                onClick={() => setShowFindReplace(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white"
                aria-label="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Editor Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Table of Contents Sidebar */}
        {showToc && (
          <aside className="hidden md:block w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-y-auto p-4 shrink-0">
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ListTree className="w-3.5 h-3.5 text-indigo-600" />
                <span>সূচিপত্র ({tocEntries.length.toLocaleString('bn-BD')})</span>
              </span>
              <button
                type="button"
                onClick={() => setShowToc(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </h3>
            <div className="space-y-1">
              {tocEntries.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  onClick={() => {
                    const secEl = document.getElementById(`editor-toc-sec-${entry.sectionId}`);
                    secEl?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className={`w-full text-left flex items-center gap-1.5 py-1.5 px-2 rounded-lg text-xs hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
                    entry.level === 0 ? 'font-semibold text-slate-900 dark:text-white' : 'pl-5 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <ChevronRight className="w-3 h-3 shrink-0 text-slate-400" />
                  <span className="truncate">{entry.text}</span>
                </button>
              ))}
            </div>
          </aside>
        )}

        {/* Scrollable Form & Sections Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-5 pb-28 md:pb-12">
          <div className="max-w-4xl mx-auto space-y-5">
            {/* Note Metadata Card */}
            <div className="p-4 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div>
                <label
                  htmlFor="note-title-input"
                  className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5"
                >
                  নোটের শিরোনাম *
                </label>
                <input
                  id="note-title-input"
                  type="text"
                  required
                  value={title}
                  onChange={(e) => {
                    isDirtyRef.current = true;
                    setTitle(e.target.value);
                  }}
                  placeholder="নোটের শিরোনাম লিখুন..."
                  className={`w-full px-3.5 py-2.5 text-base sm:text-xl font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 ${fontClass}`}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div>
                  <label
                    htmlFor="note-category-input"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    ক্যাটাগরি
                  </label>
                  {isAddingFolder ? (
                    <div className="flex items-center gap-1.5">
                      <input
                        id="note-category-input"
                        autoFocus
                        value={newFolderName}
                        onChange={(e) => setNewFolderName(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            void commitNewFolder();
                          }
                        }}
                        placeholder="নতুন ফোল্ডারের নাম"
                        className="flex-1 min-w-0 px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                      <button
                        type="button"
                        onClick={() => void commitNewFolder()}
                        className="px-2.5 py-2 text-xs font-semibold rounded-lg bg-indigo-600 text-white"
                      >
                        ঠিক আছে
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingFolder(false);
                          setNewFolderName('');
                        }}
                        className="px-2 py-2 text-xs rounded-lg text-slate-500"
                        aria-label="বাতিল"
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <select
                      id="note-category-input"
                      value={category}
                      onChange={(e) => {
                        if (e.target.value === '__new__') {
                          setIsAddingFolder(true);
                          return;
                        }
                        isDirtyRef.current = true;
                        setCategory(e.target.value);
                      }}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    >
                      {!categories.includes(category) && category && (
                        <option value={category}>{category}</option>
                      )}
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                      {onCreateCategory && <option value="__new__">＋ নতুন ফোল্ডার</option>}
                    </select>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="note-subcategory-input"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    উপ-বিভাগ (ঐচ্ছিক)
                  </label>
                  <input
                    id="note-subcategory-input"
                    type="text"
                    value={subCategory}
                    onChange={(e) => {
                      isDirtyRef.current = true;
                      setSubCategory(e.target.value);
                    }}
                    placeholder="যেমন: পদার্থবিজ্ঞান"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label
                    htmlFor="note-tags-input"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    ট্যাগসমূহ (কমা দিয়ে আলাদা)
                  </label>
                  <input
                    id="note-tags-input"
                    type="text"
                    value={tagsInput}
                    onChange={(e) => {
                      isDirtyRef.current = true;
                      setTagsInput(e.target.value);
                    }}
                    placeholder="গণিত, পদার্থ, সূত্র"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label
                    htmlFor="note-font-select"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1"
                  >
                    <Type className="w-3 h-3" />
                    <span>ইউনিকোড ফন্ট</span>
                  </label>
                  <select
                    id="note-font-select"
                    value={fontFamily}
                    onChange={(e) => {
                      isDirtyRef.current = true;
                      setFontFamily(e.target.value as NoteFontFamily);
                    }}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="sans">Noto Sans Bengali (আধুনিক)</option>
                    <option value="serif">Noto Serif Bengali (সাহিত্যিক)</option>
                    <option value="hind">Hind Siliguri (হিন্দ শিলিগুড়ি)</option>
                    <option value="tiro">Tiro Bangla (তিরো বাংলা)</option>
                    <option value="mono">JetBrains Mono (কোড/প্রতীক)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Memoized Sections List */}
            <div className="space-y-5">
              {sections.map((section, idx) => (
                <SectionEditorCard
                  key={section.id}
                  section={section}
                  index={idx}
                  totalSections={sections.length}
                  isPreview={isPreviewMode}
                  fontClass={fontClass}
                  matchCount={matchStats.matchesBySection[section.id] || 0}
                  isAiProcessing={aiProcessingSectionId === section.id}
                  onUpdateTitle={handleUpdateSectionTitle}
                  onUpdateContent={handleUpdateSectionContent}
                  onRemoveSection={handleRemoveSection}
                  onMoveSection={handleMoveSection}
                  onSmartCleanSection={handleSmartCleanSection}
                  onRunSectionAI={handleRunSectionAI}
                />
              ))}
            </div>

            {/* Add Section CTA */}
            <button
              type="button"
              onClick={handleAddSection}
              className="w-full py-4 rounded-2xl border-2 border-dashed border-indigo-200 dark:border-indigo-900/60 hover:border-indigo-500 text-xs sm:text-sm font-semibold text-indigo-700 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/20 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 flex items-center justify-center gap-2 transition-all active:scale-98 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন অনুচ্ছেদ (Add Section) যুক্ত করুন</span>
            </button>
          </div>
        </div>
      </div>

      {/* Floating Bottom Action Bar for Mobile (< md) - Always Accessible With Thumbs */}
      <aside aria-label="দ্রুত মোবাইল অ্যাকশন বার" className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 p-2.5 px-4 z-30 shadow-2xl safe-pb-bottom">
        <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
          <button
            type="button"
            onClick={handleAddSection}
            className="flex-1 flex flex-col items-center justify-center py-1 text-slate-700 dark:text-slate-300 hover:text-indigo-600 transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span className="text-[10px] font-medium mt-0.5">+ অনুচ্ছেদ</span>
          </button>

          <button
            type="button"
            onClick={() => setShowMobileTocModal(true)}
            className="flex-1 flex flex-col items-center justify-center py-1 text-slate-700 dark:text-slate-300 hover:text-indigo-600 transition-colors"
          >
            <ListTree className="w-5 h-5" />
            <span className="text-[10px] font-medium mt-0.5">সূচিপত্র</span>
          </button>

          <button
            type="button"
            onClick={() => setIsPreviewMode((prev) => !prev)}
            className="flex-1 flex flex-col items-center justify-center py-1 text-slate-700 dark:text-slate-300 hover:text-indigo-600 transition-colors"
          >
            {isPreviewMode ? <Edit3 className="w-5 h-5 text-indigo-600" /> : <Eye className="w-5 h-5" />}
            <span className="text-[10px] font-medium mt-0.5">{isPreviewMode ? 'এডিট' : 'প্রিভিউ'}</span>
          </button>

          <button
            type="button"
            onClick={() => handleSaveSubmit()}
            disabled={isSaving}
            className="flex-[1.4] flex items-center justify-center gap-1.5 py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl shadow-md active:scale-95 transition-all"
          >
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span>সংরক্ষণ</span>
          </button>
        </div>
      </aside>

      {/* Mobile Table of Contents Bottom Sheet Modal */}
      {showMobileTocModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-h-[80vh] flex flex-col overflow-hidden animate-slide-up">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ListTree className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  সূচিপত্র (দ্রুত লাফ দিন)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowMobileTocModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-1.5">
              {tocEntries.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-6">কোনো অনুচ্ছেদ পাওয়া যায়নি</p>
              ) : (
                tocEntries.map((entry) => (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() => {
                      setShowMobileTocModal(false);
                      const secEl = document.getElementById(`editor-toc-sec-${entry.sectionId}`);
                      secEl?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }}
                    className={`w-full text-left flex items-center gap-2 p-2.5 rounded-xl text-xs hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors ${
                      entry.level === 0
                        ? 'font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800/50'
                        : 'pl-6 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                    <span className="truncate">{entry.text}</span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </form>
  );
};

export default NoteEditor;
