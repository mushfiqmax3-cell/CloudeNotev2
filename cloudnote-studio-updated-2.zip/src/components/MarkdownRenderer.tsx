'use client';

import React, { useMemo, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import remarkBreaks from 'remark-breaks';
import rehypeKatex from 'rehype-katex';
import { prepareMarkdownForRender } from '../lib/text-normalizer';
import { highlightCode, normalizeLanguage } from '../lib/syntax-highlight';

interface MarkdownRendererProps {
  content: string;
  sectionId?: string;
  fontClassName?: string;
}

/** Fenced code block with language label, copy button and lightweight syntax highlighting. */
const CodeBlock: React.FC<{ code: string; language: string }> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);
  const tokens = useMemo(() => highlightCode(code, language), [code, language]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard may be unavailable (insecure context); fail silently
    }
  };

  return (
    <div className="cn-codeblock">
      <div className="cn-codeblock-header">
        <span>{language || 'code'}</span>
        <button type="button" className="cn-codeblock-copy" onClick={handleCopy}>
          {copied ? 'কপি হয়েছে ✓' : 'কপি'}
        </button>
      </div>
      <pre>
        <code>
          {tokens.map((tok, i) =>
            tok.type === 'plain' ? (
              <React.Fragment key={i}>{tok.text}</React.Fragment>
            ) : (
              <span key={i} className={`tok-${tok.type}`}>
                {tok.text}
              </span>
            )
          )}
        </code>
      </pre>
    </div>
  );
};

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = React.memo(
  ({ content, sectionId = 'sec', fontClassName = '' }) => {
    const preparedText = useMemo(() => prepareMarkdownForRender(content), [content]);

    // Track heading counter per render pass so Table of Contents IDs match extractTocEntries
    let headingCounter = 0;
    const nextHeadingId = () => `toc-sec-${sectionId}-h-${headingCounter++}`;

    return (
      <div className={`cloudnote-markdown ${fontClassName}`}>
        <ReactMarkdown
          remarkPlugins={[remarkGfm, remarkMath, remarkBreaks]}
          rehypePlugins={[rehypeKatex]}
          components={{
            h1: ({ children }) => <h1 id={nextHeadingId()}>{children}</h1>,
            h2: ({ children }) => <h2 id={nextHeadingId()}>{children}</h2>,
            h3: ({ children }) => <h3 id={nextHeadingId()}>{children}</h3>,
            h4: ({ children }) => <h4 id={nextHeadingId()}>{children}</h4>,
            a: ({ href, children }) => (
              <a href={href} target="_blank" rel="noopener noreferrer">
                {children}
              </a>
            ),
            pre: ({ children }) => {
              const child = React.Children.toArray(children)[0];
              if (React.isValidElement<{ className?: string; children?: React.ReactNode }>(child)) {
                const raw = child.props.children;
                const text = (Array.isArray(raw) ? raw.join('') : String(raw ?? '')).replace(/\n$/, '');
                const language = normalizeLanguage(
                  /language-([\w+#.-]+)/.exec(child.props.className || '')?.[1]
                );
                return <CodeBlock code={text} language={language} />;
              }
              return <pre>{children}</pre>;
            },
          }}
        >
          {preparedText}
        </ReactMarkdown>
      </div>
    );
  }
);

MarkdownRenderer.displayName = 'MarkdownRenderer';

export default MarkdownRenderer;
