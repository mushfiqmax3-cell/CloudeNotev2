'use client';

import React, { useState } from 'react';
import {
  BookOpen,
  ArrowRight,
  Mail,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { auth, isFirebaseConfigured } from '../lib/firebase';
import {
  registerAccountInVault,
  authenticateAccountInVault,
  resetPasswordInVault,
  savePersistedSessionUser,
  upsertUserProfileToFirestore,
} from '../lib/storage';
import type { UserProfile } from '../lib/types';

interface LoginScreenProps {
  onAuthenticated: (user: UserProfile) => void;
  onContinueAsGuest: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onAuthenticated,
  onContinueAsGuest,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const switchMode = (nextMode: 'login' | 'register' | 'reset') => {
    setMode(nextMode);
    setError(null);
    setSuccessMsg(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setError('অনুগ্রহ করে একটি সঠিক ইমেইল ঠিকানা লিখুন।');
      return;
    }

    if (mode === 'reset') {
      if (!password || password.length < 6) {
        setError('নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
        return;
      }
      setLoading(true);
      try {
        if (isFirebaseConfigured && auth) {
          try {
            await sendPasswordResetEmail(auth, cleanEmail);
          } catch {
            // Update local vault
          }
        }
        const updatedProfile = await resetPasswordInVault(cleanEmail, password);
        setSuccessMsg('পাসওয়ার্ড আপডেট সম্পন্ন হয়েছে!');
        onAuthenticated(updatedProfile);
      } catch (err: unknown) {
        setError(
          err instanceof Error ? err.message : 'পাসওয়ার্ড রিসেট সম্পন্ন করা যায়নি।'
        );
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!password || password.length < 6) {
      setError('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }

    setLoading(true);

    if (mode === 'register') {
      try {
        if (isFirebaseConfigured && auth) {
          try {
            const userCred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
            const profile: UserProfile = {
              uid: userCred.user.uid,
              email: cleanEmail,
              displayName: cleanEmail.split('@')[0],
              photoURL: null,
              isLocalMode: false,
              authProvider: 'firebase-email',
              lastSyncedAt: new Date().toISOString(),
            };
            savePersistedSessionUser(profile);
            await upsertUserProfileToFirestore(profile);
            onAuthenticated(profile);
            return;
          } catch (fbErr: unknown) {
            const errStr = String(fbErr);
            if (errStr.includes('email-already-in-use')) {
              setError('এই ইমেইলটি ইতিমধ্যে ব্যবহৃত হয়েছে। দয়া করে লগইন করুন।');
              setLoading(false);
              return;
            }
          }
        }

        // Vault registration fallback
        const vaultProfile = await registerAccountInVault(
          cleanEmail,
          password,
          cleanEmail.split('@')[0]
        );
        savePersistedSessionUser(vaultProfile);
        onAuthenticated(vaultProfile);
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'নিবন্ধন সম্পন্ন করা যায়নি।');
      } finally {
        setLoading(false);
      }
    } else {
      // Login mode
      try {
        if (isFirebaseConfigured && auth) {
          try {
            const userCred = await signInWithEmailAndPassword(auth, cleanEmail, password);
            const profile: UserProfile = {
              uid: userCred.user.uid,
              email: cleanEmail,
              displayName: userCred.user.displayName || cleanEmail.split('@')[0],
              photoURL: userCred.user.photoURL,
              isLocalMode: false,
              authProvider: 'firebase-email',
              lastSyncedAt: new Date().toISOString(),
            };
            savePersistedSessionUser(profile);
            await upsertUserProfileToFirestore(profile);
            onAuthenticated(profile);
            return;
          } catch (fbErr: unknown) {
            const errStr = String(fbErr);
            if (errStr.includes('wrong-password') || errStr.includes('user-not-found')) {
              setError('ভুল ইমেইল অথবা পাসওয়ার্ড দেওয়া হয়েছে।');
              setLoading(false);
              return;
            }
          }
        }

        // Vault login
        const vaultProfile = await authenticateAccountInVault(cleanEmail, password);
        savePersistedSessionUser(vaultProfile);
        onAuthenticated(vaultProfile);
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'লগইন ব্যর্থ হয়েছে। তথ্য যাচাই করুন।');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-6 bg-slate-50 dark:bg-black text-slate-900 dark:text-white transition-colors">
      <div className="w-full max-w-md bg-white dark:bg-[#080808] border border-slate-200 dark:border-[#1f1f1f] rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
        {/* Minimal App Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-indigo-600 text-white shadow-xs">
            <BookOpen className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Cloud Note
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {mode === 'login'
              ? 'আপনার অ্যাকাউন্টে প্রবেশ করুন'
              : mode === 'register'
                ? 'নতুন ক্লাউড অ্যাকাউন্ট তৈরি করুন'
                : 'পাসওয়ার্ড পুনরুদ্ধার করুন'}
          </p>
        </div>

        {/* Minimal Mode Switcher */}
        <div
          role="tablist"
          aria-label="অথেনটিকেশন মোড"
          className="grid grid-cols-2 gap-1 p-1 bg-slate-100 dark:bg-[#121212] rounded-xl text-xs font-semibold"
        >
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'login'}
            onClick={() => switchMode('login')}
            className={`py-2 rounded-lg transition-all ${
              mode === 'login'
                ? 'bg-white dark:bg-[#1e1e1e] text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            লগইন
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'register'}
            onClick={() => switchMode('register')}
            className={`py-2 rounded-lg transition-all ${
              mode === 'register'
                ? 'bg-white dark:bg-[#1e1e1e] text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            নতুন অ্যাকাউন্ট
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div
            role="status"
            className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Minimal Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5" noValidate>
          <div>
            <label
              htmlFor="auth-email-input"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
            >
              ইমেইল
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                id="auth-email-input"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-[#262626] bg-white dark:bg-[#111111] text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label
                htmlFor="auth-password-input"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                {mode === 'reset' ? 'নতুন পাসওয়ার্ড' : 'পাসওয়ার্ড'}
              </label>
              {mode === 'login' && (
                <button
                  type="button"
                  onClick={() => switchMode('reset')}
                  className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  পাসওয়ার্ড ভুলে গেছেন?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                id="auth-password-input"
                type={showPassword ? 'text' : 'password'}
                required
                minLength={6}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="কমপক্ষে ৬ অক্ষর"
                className="w-full pl-9 pr-9 py-2 text-xs rounded-xl border border-slate-200 dark:border-[#262626] bg-white dark:bg-[#111111] text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-2.5 top-2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                aria-label={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 rounded-xl transition-all shadow-xs mt-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>লোড হচ্ছে...</span>
              </>
            ) : mode === 'login' ? (
              <>
                <span>লগইন করুন</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            ) : mode === 'register' ? (
              <>
                <span>অ্যাকাউন্ট তৈরি করুন</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            ) : (
              <>
                <span>পাসওয়ার্ড আপডেট করুন</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </form>

        <div className="space-y-2">
          <button
            type="button"
            onClick={onContinueAsGuest}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>লগইন ছাড়াই সরাসরি ব্যবহার করুন (গেস্ট মোড)</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
