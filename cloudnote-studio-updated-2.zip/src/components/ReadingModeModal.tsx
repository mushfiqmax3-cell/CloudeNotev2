'use client';

import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  X,
  ListTree,
  Printer,
  Type,
  Sun,
  Moon,
  BookOpen,
  Minus,
  Plus,
  ChevronRight,
  AlignLeft,
  Columns,
  Maximize2,
} from 'lucide-react';
import type { NoteFontFamily, NoteItem } from '../lib/types';
import { extractTocEntries, computeSectionsMetrics } from '../lib/text-normalizer';
import { exportNoteToPDF } from '../lib/pdf-export';
import { MarkdownRenderer } from './MarkdownRenderer';

interface ReadingModeModalProps {
  note: NoteItem | null;
  isOpen: boolean;
  onClose: () => void;
}

const FONT_CLASS_MAP: Record<NoteFontFamily, string> = {
  sans: 'font-bengali-sans',
  serif: 'font-bengali-serif',
  hind: 'font-bengali-hind',
  tiro: 'font-bengali-tiro',
  mono: 'font-bengali-mono',
};

type ReaderTheme = 'light' | 'sepia' | 'sage' | 'dark';
type ContentWidth = 'narrow' | 'normal' | 'wide';

export const ReadingModeModal: React.FC<ReadingModeModalProps> = ({
  note,
  isOpen,
  onClose,
}) => {
  const [theme, setTheme] = useState<ReaderTheme>('sepia');
  const [fontSize, setFontSize] = useState<number>(18);
  const [fontFamily, setFontFamily] = useState<NoteFontFamily>(note?.fontFamily || 'serif');
  const [contentWidth, setContentWidth] = useState<ContentWidth>('normal');
  const [showToc, setShowToc] = useState<boolean>(false);
  const [scrollProgress, setScrollProgress] = useState<number>(0);

  const containerRef = useRef<HTMLDivElement>(null);

  const tocEntries = useMemo(() => {
    if (!note) return [];
    return extractTocEntries(note.sections || []);
  }, [note]);

  const metrics = useMemo(() => {
    if (!note) return { wordCount: 0, charCount: 0, byteSize: 0, readingTimeMinutes: 0 };
    return computeSectionsMetrics(note.sections || []);
  }, [note]);

  // Keyboard shortcut: Esc to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    const total = scrollHeight - clientHeight;
    if (total > 0) {
      setScrollProgress(Math.min(100, Math.max(0, (scrollTop / total) * 100)));
    }
  };

  if (!isOpen || !note) return null;

  const themeClasses =
    theme === 'dark'
      ? 'theme-dark'
      : theme === 'sepia'
        ? 'theme-sepia'
        : theme === 'sage'
          ? 'theme-sage'
          : 'theme-light';

  const widthClass =
    contentWidth === 'narrow'
      ? 'max-w-2xl'
      : contentWidth === 'wide'
        ? 'max-w-5xl'
        : 'max-w-3xl';

  const jumpToTarget = (elementId: string) => {
    const el = document.getElementById(`reading-${elementId}`) || document.getElementById(elementId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col overflow-hidden transition-colors duration-200 ${themeClasses}`}
      role="dialog"
      aria-modal="true"
      aria-label="পূর্ণ পঠন মোড (Reading Mode)"
    >
      {/* Scroll Progress Bar */}
      <div
        className="h-1 bg-indigo-600 transition-all duration-150 shrink-0"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Top Reading Toolbar */}
      <header className="flex items-center justify-between gap-3 px-4 sm:px-8 py-3 border-b border-black/10 dark:border-white/10 shrink-0 backdrop-blur-md">
        <div className="flex items-center gap-2.5 min-w-0">
          <BookOpen className="w-5 h-5 text-indigo-500 shrink-0" />
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-bold truncate">{note.title}</h2>
            <p className="text-[11px] opacity-70 tabular-nums">
              {note.category} · {metrics.wordCount.toLocaleString('bn-BD')} শব্দ · আনুমানিক{' '}
              {metrics.readingTimeMinutes.toLocaleString('bn-BD')} মিনিট পাঠ
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Table of Contents Toggle */}
          <button
            type="button"
            onClick={() => setShowToc((prev) => !prev)}
            className={`flex items-center gap-1 px-2.5 py-1.5 min-h-[36px] text-xs font-medium rounded-lg border transition-colors ${
              showToc
                ? 'bg-indigo-600 text-white border-indigo-600'
                : 'border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
            title="সূচিপত্র"
          >
            <ListTree className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">সূচিপত্র</span>
          </button>

          {/* Font Selector */}
          <div className="hidden lg:flex items-center gap-1 border border-black/10 dark:border-white/10 rounded-lg px-2 py-1">
            <Type className="w-3.5 h-3.5 opacity-60" />
            <select
              aria-label="পঠন ফন্ট নির্বাচন"
              value={fontFamily}
              onChange={(e) => setFontFamily(e.target.value as NoteFontFamily)}
              className="text-xs bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="sans" className="text-slate-900">Noto Sans (স্যান্স)</option>
              <option value="serif" className="text-slate-900">Noto Serif (সেরিফ)</option>
              <option value="hind" className="text-slate-900">Hind Siliguri (হিন্দ)</option>
              <option value="tiro" className="text-slate-900">Tiro Bangla (তিরো)</option>
              <option value="mono" className="text-slate-900">JetBrains Mono (কোড)</option>
            </select>
          </div>

          {/* Font Size Controls */}
          <div className="hidden sm:flex items-center border border-black/10 dark:border-white/10 rounded-lg overflow-hidden">
            <button
              type="button"
              onClick={() => setFontSize((s) => Math.max(14, s - 1))}
              className="p-1.5 px-2 hover:bg-black/5 dark:hover:bg-white/5"
              aria-label="ফন্ট ছোট করুন"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 text-xs font-mono tabular-nums font-bold">{fontSize}px</span>
            <button
              type="button"
              onClick={() => setFontSize((s) => Math.min(28, s + 1))}
              className="p-1.5 px-2 hover:bg-black/5 dark:hover:bg-white/5"
              aria-label="ফন্ট বড় করুন"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Theme Cycle Button */}
          <button
            type="button"
            onClick={() => {
              const themes: ReaderTheme[] = ['light', 'sepia', 'sage', 'dark'];
              const nextIndex = (themes.indexOf(theme) + 1) % themes.length;
              setTheme(themes[nextIndex]);
            }}
            className="sm:hidden p-2 min-h-[36px] min-w-[36px] rounded-lg border border-black/10 dark:border-white/10 flex items-center justify-center text-xs font-bold"
            title={`বর্তমান থিম: ${theme}। ট্যাপ করে পরিবর্তন করুন`}
          >
            {theme === 'light' ? '☀️' : theme === 'sepia' ? '📜' : theme === 'sage' ? '🌿' : '🌙'}
          </button>

          {/* Desktop Theme Switcher */}
          <div className="hidden sm:flex items-center border border-black/10 dark:border-white/10 rounded-lg p-0.5">
            <button
              type="button"
              onClick={() => setTheme('light')}
              className={`px-2 py-1 text-xs rounded-md ${
                theme === 'light' ? 'bg-black/10 dark:bg-white/20 font-bold' : 'opacity-60'
              }`}
              title="শুভ্র থিম"
            >
              শুভ্র
            </button>
            <button
              type="button"
              onClick={() => setTheme('sepia')}
              className={`px-2 py-1 text-xs rounded-md ${
                theme === 'sepia' ? 'bg-black/10 dark:bg-white/20 font-bold text-amber-900' : 'opacity-60'
              }`}
              title="কাগজ (Sepia) থিম"
            >
              কাগজ
            </button>
            <button
              type="button"
              onClick={() => setTheme('sage')}
              className={`px-2 py-1 text-xs rounded-md ${
                theme === 'sage' ? 'bg-black/10 dark:bg-white/20 font-bold text-emerald-400' : 'opacity-60'
              }`}
              title="শান্ত সবুজ থিম"
            >
              সবুজ
            </button>
            <button
              type="button"
              onClick={() => setTheme('dark')}
              className={`px-2 py-1 text-xs rounded-md ${
                theme === 'dark' ? 'bg-indigo-600 text-white font-bold' : 'opacity-60'
              }`}
              title="ডার্ক থিম"
            >
              ডার্ক
            </button>
          </div>

          {/* Width Selector */}
          <button
            type="button"
            onClick={() =>
              setContentWidth((w) => (w === 'normal' ? 'wide' : w === 'wide' ? 'narrow' : 'normal'))
            }
            className="hidden md:flex p-2 border border-black/10 dark:border-white/10 rounded-lg hover:bg-black/5 dark:hover:bg-white/5"
            title={`কন্টেন্ট প্রস্থ: ${contentWidth}`}
          >
            <Columns className="w-3.5 h-3.5 opacity-70" />
          </button>

          {/* Print / PDF */}
          <button
            type="button"
            onClick={() => exportNoteToPDF(note)}
            className="hidden sm:flex p-2 border border-black/10 dark:border-white/10 rounded-lg hover:bg-black/5 dark:hover:bg-white/5"
            title="পিডিএফ প্রিন্ট করুন"
            aria-label="পিডিএফ প্রিন্ট করুন"
          >
            <Printer className="w-3.5 h-3.5" />
          </button>

          {/* Close Reading Mode */}
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-colors whitespace-nowrap active:scale-95"
            aria-label="পঠন মোড বন্ধ করুন"
          >
            <X className="w-4 h-4" />
            <span className="hidden sm:inline">বন্ধ</span>
          </button>
        </div>
      </header>

      {/* Main Reading Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Table of Contents Sidebar */}
        {showToc && tocEntries.length > 0 && (
          <aside className="w-64 sm:w-72 border-r border-black/10 dark:border-white/10 overflow-y-auto p-4 shrink-0 bg-black/5 dark:bg-white/5 backdrop-blur-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider opacity-60 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ListTree className="w-3.5 h-3.5 text-indigo-500" />
                <span>সূচিপত্র ({tocEntries.length})</span>
              </span>
              <button
                type="button"
                onClick={() => setShowToc(false)}
                className="p-1 opacity-50 hover:opacity-100"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </h3>
            <nav aria-label="পঠন মোড সূচিপত্র" className="space-y-1">
              {tocEntries.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  onClick={() => jumpToTarget(entry.id)}
                  className={`w-full text-left flex items-center gap-1.5 py-1.5 px-2.5 rounded-lg text-xs hover:bg-indigo-500/10 transition-colors ${
                    entry.level === 0
                      ? 'font-bold'
                      : entry.level === 1
                        ? 'pl-5 opacity-90'
                        : 'pl-8 opacity-75'
                  }`}
                >
                  <ChevronRight className="w-3 h-3 shrink-0 opacity-50" />
                  <span className="truncate">{entry.text}</span>
                </button>
              ))}
            </nav>
          </aside>
        )}

        {/* Scrollable Reading Canvas */}
        <main
          ref={containerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-4 sm:px-12 py-8 sm:py-14"
        >
          <article
            className={`${widthClass} mx-auto space-y-10 ${FONT_CLASS_MAP[fontFamily]}`}
            style={{ fontSize: `${fontSize}px` }}
          >
            {/* Header / Note Info */}
            <div className="pb-6 border-b border-black/10 dark:border-white/10">
              <h1 className="text-2xl sm:text-4xl font-bold leading-tight mb-3">{note.title}</h1>
              <div className="text-xs opacity-70 flex flex-wrap items-center gap-2">
                <span>ক্যাটাগরি: {note.category}</span>
                {note.subCategory && (
                  <>
                    <span>·</span>
                    <span>উপ-বিভাগ: {note.subCategory}</span>
                  </>
                )}
                <span>·</span>
                <span>হালনাগাদ: {new Date(note.updatedAt).toLocaleDateString('bn-BD')}</span>
              </div>
            </div>

            {/* Sections Loop */}
            {(note.sections || []).map((sec, idx) => (
              <section
                key={sec.id}
                id={`reading-toc-sec-${sec.id}`}
                className="space-y-4 scroll-mt-12"
              >
                <div className="flex items-center gap-2.5 pb-2 border-b border-black/5 dark:border-white/5">
                  <span className="w-6 h-6 rounded-md bg-indigo-600 text-white text-xs font-bold flex items-center justify-center shrink-0 tabular-nums">
                    {idx + 1}
                  </span>
                  <h2 className="text-xl sm:text-2xl font-bold">{sec.title || `অনুচ্ছেদ ${idx + 1}`}</h2>
                </div>
                <MarkdownRenderer
                  content={sec.content}
                  sectionId={sec.id}
                  fontClassName={FONT_CLASS_MAP[fontFamily]}
                />
              </section>
            ))}
          </article>
        </main>
      </div>
    </div>
  );
};

export default ReadingModeModal;
