'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Cloud,
  HardDrive,
  Mail,
  Lock,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Download,
  Upload,
  History,
  RotateCcw,
  ShieldCheck,
  LogOut,
} from 'lucide-react';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import { auth, isFirebaseConfigured } from '../lib/firebase';
import {
  registerAccountInVault,
  authenticateAccountInVault,
  savePersistedSessionUser,
  upsertUserProfileToFirestore,
  createCloudBackupBundle,
  restoreFromCloudBackupBundle,
  getNoteVersionHistory,
} from '../lib/storage';
import type { NoteItem, NoteVersionSnapshot, UserProfile } from '../lib/types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  allNotes: NoteItem[];
  onSelectUser: (user: UserProfile) => void;
  onManualSync: () => Promise<void>;
  onRestoreNotes: (restoredNotes: NoteItem[]) => void;
  onRestoreSingleVersion: (snapshot: NoteVersionSnapshot) => Promise<void>;
  onLogout: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  allNotes,
  onSelectUser,
  onManualSync,
  onRestoreNotes,
  onRestoreSingleVersion,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'sync' | 'backup' | 'versions'>('sync');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState(currentUser.email || '');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [versions, setVersions] = useState<NoteVersionSnapshot[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const timer = setTimeout(() => {
      setEmail(currentUser.email || '');
      setError(null);
      setStatusMsg(null);
    }, 0);
    void getNoteVersionHistory().then(setVersions);
    return () => clearTimeout(timer);
  }, [isOpen, currentUser.email]);

  if (!isOpen) return null;

  const handleTriggerCloudSync = async () => {
    setLoading(true);
    setError(null);
    setStatusMsg(null);
    try {
      await onManualSync();
      setStatusMsg('সকল নোট ও ডেটা সফলভাবে ক্লাউড এবং লোকাল স্টোরেজে সিঙ্ক হয়েছে!');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'ক্লাউড সিঙ্ক সম্পন্ন করা যায়নি।');
    } finally {
      setLoading(false);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setStatusMsg(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setError('অনুগ্রহ করে একটি বৈধ ইমেইল ঠিকানা লিখুন।');
      return;
    }
    if (!password || password.length < 6) {
      setError('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }

    setLoading(true);
    try {
      if (authMode === 'register') {
        if (isFirebaseConfigured && auth) {
          try {
            const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
            const fbProfile: UserProfile = {
              uid: cred.user.uid,
              email: cred.user.email || cleanEmail,
              displayName: cleanEmail.split('@')[0],
              photoURL: cred.user.photoURL,
              isLocalMode: false,
              authProvider: 'firebase-email',
              lastSyncedAt: new Date().toISOString(),
            };
            savePersistedSessionUser(fbProfile);
            await upsertUserProfileToFirestore(fbProfile);
            onSelectUser(fbProfile);
            setStatusMsg('নতুন ক্লাউড অ্যাকাউন্ট তৈরি ও সিঙ্ক সম্পন্ন হয়েছে!');
            setPassword('');
            return;
          } catch {
            // Fallback to Account Vault if Email/Password provider isn't toggled in Console yet
          }
        }
        const vaultProfile = await registerAccountInVault(
          cleanEmail,
          password,
          cleanEmail.split('@')[0]
        );
        onSelectUser(vaultProfile);
        setStatusMsg('অ্যাকাউন্ট নিবন্ধিত হয়েছে এবং নোটগুলো সুরক্ষিত করা হয়েছে!');
        setPassword('');
      } else {
        if (isFirebaseConfigured && auth) {
          try {
            const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
            const fbProfile: UserProfile = {
              uid: cred.user.uid,
              email: cred.user.email || cleanEmail,
              displayName: cred.user.displayName || cleanEmail.split('@')[0],
              photoURL: cred.user.photoURL,
              isLocalMode: false,
              authProvider: 'firebase-email',
              lastSyncedAt: new Date().toISOString(),
            };
            savePersistedSessionUser(fbProfile);
            await upsertUserProfileToFirestore(fbProfile);
            onSelectUser(fbProfile);
            setStatusMsg('সফলভাবে ক্লাউড অ্যাকাউন্টে লগইন ও সিঙ্ক সম্পন্ন হয়েছে!');
            setPassword('');
            return;
          } catch {
            // Check Account Vault
          }
        }
        const vaultProfile = await authenticateAccountInVault(cleanEmail, password);
        onSelectUser(vaultProfile);
        setStatusMsg('সফলভাবে অ্যাকাউন্টে লগইন ও নোট লোড করা হয়েছে!');
        setPassword('');
      }
    } catch (err: unknown) {
      setError(
        err instanceof Error
          ? err.message
          : 'লগইন সম্পন্ন করা যায়নি। ইমেইল বা পাসওয়ার্ড যাচাই করুন।'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleExportBackupJson = () => {
    const bundle = createCloudBackupBundle(allNotes, currentUser);
    const jsonString = JSON.stringify(bundle, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const datePart = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `cloudnote-backup-${datePart}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setStatusMsg(`${allNotes.length}টি নোটের সম্পূর্ণ ব্যাকআপ ফাইল ডাউনলোড হয়েছে!`);
  };

  const handleImportBackupFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    setError(null);
    setStatusMsg(null);
    try {
      const rawText = await file.text();
      const merged = await restoreFromCloudBackupBundle(rawText, currentUser.uid);
      onRestoreNotes(merged);
      setStatusMsg(`ব্যাকআপ ফাইল থেকে সফলভাবে নোট পুনরুদ্ধার ও মার্জ করা হয়েছে! (মোট ${merged.length}টি নোট)`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'ব্যাকআপ ফাইল রিস্টোর করা যায়নি।');
    } finally {
      setLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <Cloud className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <div>
              <h2
                id="auth-modal-title"
                className="text-base font-bold text-slate-900 dark:text-white"
              >
                ক্লাউড সিঙ্ক, ডেটা রিকভারি ও ব্যাকআপ হাব
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                ক্রস-ডিভাইস অ্যাক্সেস, ফায়ারস্টোর সিঙ্ক এবং সম্পূর্ণ ব্যাকআপ ব্যবস্থাপনা
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg"
            aria-label="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-1 p-2 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveTab('sync');
              setError(null);
              setStatusMsg(null);
            }}
            className={`py-2 px-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'sync'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>অ্যাকাউন্ট ও সিঙ্ক</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('backup');
              setError(null);
              setStatusMsg(null);
            }}
            className={`py-2 px-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'backup'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>ব্যাকআপ ও রিস্টোর</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('versions');
              setError(null);
              setStatusMsg(null);
              void getNoteVersionHistory().then(setVersions);
            }}
            className={`py-2 px-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'versions'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>ভার্সন রিকভারি ({versions.length})</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {statusMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{statusMsg}</span>
            </div>
          )}

          {activeTab === 'sync' && (
            <div className="space-y-4">
              {/* Active User Status Card */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      <ShieldCheck className="w-3 h-3" />
                      {currentUser.isLocalMode ? 'কুইক স্টুডিও মোড' : 'অ্যাকাউন্ট সক্রিয়'}
                    </span>
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {currentUser.displayName || 'ব্যবহারকারী'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    ইমেইল: <strong>{currentUser.email || 'সংযুক্ত নয়'}</strong> • মোট নোট:{' '}
                    <strong>{allNotes.length.toLocaleString('bn-BD')}টি</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handleTriggerCloudSync}
                    disabled={loading}
                    className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                    <span>এখনই সিঙ্ক করুন</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onLogout();
                    }}
                    className="flex items-center gap-1 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>লগআউট</span>
                  </button>
                </div>
              </div>

              {/* Switch Account / Login or Register another account */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                    {authMode === 'login'
                      ? 'অন্য অ্যাকাউন্টে লগইন / সুইচ করুন'
                      : 'নতুন ক্লাউড অ্যাকাউন্ট নিবন্ধন করুন'}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
                    className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    {authMode === 'login' ? 'নতুন অ্যাকাউন্ট খুলুন' : 'আগের অ্যাকাউন্টে লগইন'}
                  </button>
                </div>

                <form onSubmit={handleAuthSubmit} className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      ইমেইল ঠিকানা
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="name@example.com"
                        className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      পাসওয়ার্ড
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="password"
                        required
                        minLength={6}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড"
                        className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                    <button
                      type="submit"
                      disabled={loading}
                      className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-500 rounded-lg transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>
                        {authMode === 'login' ? 'ইমেইল দিয়ে লগইন' : 'নতুন অ্যাকাউন্ট তৈরি'}
                      </span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-start gap-3">
                  <Download className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      সম্পূর্ণ ক্লাউড নোট ব্যাকআপ ডাউনলোড (.json)
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      আপনার সকল নোট, অনুচ্ছেদ, গাণিতিক সূত্র এবং ট্যাগগুলো একটি পোর্টেবল JSON ব্যাকআপ ফাইলে ডাউনলোড করে রাখুন। এটি অন্য যেকোনো ডিভাইসে আপলোড করলেই সব নোট চলে আসবে।
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleExportBackupJson}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>সম্পূর্ণ ব্যাকআপ ডাউনলোড করুন ({allNotes.length}টি নোট)</span>
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-start gap-3">
                  <Upload className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      ব্যাকআপ ফাইল থেকে নোট রিস্টোর ও রিকভারি
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      পূর্বে ডাউনলোড করা <code>.json</code> ব্যাকআপ ফাইল নির্বাচন করলে আপনার বর্তমান নোটগুলোর সাথে স্বয়ংক্রিয়ভাবে মার্জ ও ক্লাউডে সিঙ্ক হয়ে যাবে।
                    </p>
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".json,application/json"
                  onChange={handleImportBackupFile}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-900 dark:text-white bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl transition-colors"
                >
                  <Upload className="w-4 h-4 text-emerald-600" />
                  <span>ব্যাকআপ ফাইল (.json) নির্বাচন করে রিস্টোর করুন</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'versions' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>
                  প্রতিবার নোট সংরক্ষণের সময় স্বয়ংক্রিয়ভাবে স্ন্যাপশট তৈরি হয় যেন ভুলবশত কোনো লেখা মুছে গেলেও তাৎক্ষণিকভাবে ফিরিয়ে আনা যায়।
                </span>
              </div>

              {versions.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                  এখনো কোনো ভার্সন স্ন্যাপশট তৈরি হয়নি। কোনো নোট সম্পাদনা ও সংরক্ষণ করলে এখানে তার ইতিহাস জমা হবে।
                </div>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {versions.map((ver) => (
                    <div
                      key={ver.versionId}
                      className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {ver.title}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {new Date(ver.savedAt).toLocaleString('bn-BD')} •{' '}
                          {ver.wordCount.toLocaleString('bn-BD')} শব্দ
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          await onRestoreSingleVersion(ver);
                          setStatusMsg(`"${ver.title}" নোটের সংস্করণটি সফলভাবে পুনরুদ্ধার করা হয়েছে!`);
                        }}
                        className="shrink-0 flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 rounded-lg transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>পুনরুদ্ধার</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
