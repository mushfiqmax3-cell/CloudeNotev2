'use client';

import React, { useState, useEffect } from 'react';
import { Lock, Unlock, ShieldAlert, X, KeyRound, Trash2 } from 'lucide-react';
import { hashPin, verifyPin } from '../lib/text-normalizer';

interface PinLockModalProps {
  isOpen: boolean;
  mode: 'set' | 'unlock' | 'manage';
  noteTitle: string;
  existingPinHash?: string | null;
  onClose: () => void;
  onSuccess: (newPinHash: string | null) => void;
}

export const PinLockModal: React.FC<PinLockModalProps> = ({
  isOpen,
  mode,
  noteTitle,
  existingPinHash,
  onClose,
  onSuccess,
}) => {
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        setPin('');
        setConfirmPin('');
        setError(null);
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [isOpen, mode]);

  if (!isOpen) return null;

  const handlePinDigitChange = (val: string, setter: (v: string) => void) => {
    // Convert Bengali digits (০-৯) to ASCII (0-9) automatically so users can type in either layout
    const bengaliToAscii = val.replace(/[০-৯]/g, (d) =>
      String('০১২৩৪৫৬৭৮৯'.indexOf(d))
    );
    const digitsOnly = bengaliToAscii.replace(/\D/g, '').slice(0, 4);
    setter(digitsOnly);
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length !== 4) {
      setError('অনুগ্রহ করে ৪ সংখ্যার পিন লিখুন (যেমন: ১২৩৪ বা 1234)।');
      return;
    }

    if (mode === 'set') {
      if (pin !== confirmPin) {
        setError('দুটি পিন মিলছে না। পুনরায় যাচাই করুন।');
        return;
      }
      onSuccess(hashPin(pin));
      onClose();
      return;
    }

    if (mode === 'unlock' || mode === 'manage') {
      if (verifyPin(pin, existingPinHash)) {
        onSuccess(existingPinHash || null);
        onClose();
      } else {
        setError('ভুল পিন কোড! সঠিক ৪ সংখ্যার পিন দিন।');
      }
    }
  };

  const handleRemovePin = () => {
    if (pin.length !== 4) {
      setError('পিন লক সরাতে বর্তমান ৪ সংখ্যার পিনটি লিখুন।');
      return;
    }
    if (verifyPin(pin, existingPinHash)) {
      onSuccess(null);
      onClose();
    } else {
      setError('ভুল পিন কোড! পিন সরাতে সঠিক বর্তমান পিন দিন।');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pin-modal-title"
    >
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            {mode === 'set' ? (
              <KeyRound className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            ) : (
              <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            )}
            <h2 id="pin-modal-title" className="text-sm font-bold text-slate-900 dark:text-white">
              {mode === 'set'
                ? 'নোট পিন লক সেট করুন (৪-ডিজিট)'
                : mode === 'manage'
                  ? 'পিন লক পরিবর্তন বা সরান'
                  : 'লক করা নোট আনলক করুন'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-lg"
            aria-label="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <p className="text-xs text-slate-600 dark:text-slate-400 truncate">
            নোট: <span className="font-semibold text-slate-900 dark:text-slate-200">{noteTitle}</span>
          </p>

          {error && (
            <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label
              htmlFor="pin-input"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
            >
              {mode === 'set' ? 'নতুন ৪-সংখ্যার পিন দিন' : '৪-সংখ্যার পিন কোড দিন'}
            </label>
            <input
              id="pin-input"
              type="password"
              inputMode="numeric"
              autoFocus
              maxLength={4}
              value={pin}
              onChange={(e) => handlePinDigitChange(e.target.value, setPin)}
              placeholder="••••"
              className="w-full px-4 py-2.5 text-center text-lg font-mono tracking-[0.5em] rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {mode === 'set' && (
            <div>
              <label
                htmlFor="pin-confirm-input"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
              >
                পিন কোড নিশ্চিত করুন
              </label>
              <input
                id="pin-confirm-input"
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={confirmPin}
                onChange={(e) => handlePinDigitChange(e.target.value, setConfirmPin)}
                placeholder="••••"
                className="w-full px-4 py-2.5 text-center text-lg font-mono tracking-[0.5em] rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}

          <div className="flex items-center justify-between gap-2 pt-2">
            {mode === 'manage' && existingPinHash ? (
              <button
                type="button"
                onClick={handleRemovePin}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>পিন লক সরান</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                বাতিল
              </button>
            )}

            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-500 rounded-lg transition-colors"
            >
              {mode === 'set' ? (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>পিন লক সক্রিয় করুন</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3.5 h-3.5" />
                  <span>আনলক করুন</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PinLockModal;
