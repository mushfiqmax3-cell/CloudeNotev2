'use client';

import React, { useState, useMemo } from 'react';
import {
  Plus,
  Star,
  Trash2,
  RotateCcw,
  Lock,
  Unlock,
  FileText,
  Database,
  Search,
  FolderOpen,
  Pin,
  Sparkles,
  Palette,
  FolderPlus,
  Check,
} from 'lucide-react';
import type { CategoryItem, NoteItem } from '../lib/types';
import { AIActionModal } from './AIActionModal';
import type { AIAction } from '../lib/gemini-service';

interface RecentNotesViewProps {
  notes: NoteItem[];
  allCategories: CategoryItem[];
  activeView: 'all' | 'favorites' | 'trash' | 'category';
  selectedCategory: string | null;
  onSelectCategory: (cat: string | null) => void;
  onOpenCreateCategory: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  unlockedNoteIds: Set<string>;
  onSelectNote: (note: NoteItem) => void;
  onCreateNewNote: () => void;
  onToggleFavorite: (note: NoteItem, e: React.MouseEvent) => void;
  onTogglePin: (note: NoteItem, e: React.MouseEvent) => void;
  onChangeNoteColor: (note: NoteItem, color: string, e: React.MouseEvent) => void;
  onSoftDelete: (note: NoteItem, e: React.MouseEvent) => void;
  onRestoreNote: (note: NoteItem, e: React.MouseEvent) => void;
  onPermanentDelete: (noteId: string, e: React.MouseEvent) => void;
  onEmptyTrash: () => void;
  onApplyAIUpdate: (note: NoteItem) => Promise<unknown>;
}

const COLOR_SWATCHES = [
  { label: 'ডিফল্ট', value: '' },
  { label: 'Indigo', value: '#6366f1' },
  { label: 'Emerald', value: '#10b981' },
  { label: 'Amber', value: '#f59e0b' },
  { label: 'Rose', value: '#f43f5e' },
  { label: 'Purple', value: '#a855f7' },
  { label: 'Sky', value: '#0ea5e9' },
  { label: 'Slate', value: '#64748b' },
];

export const RecentNotesView: React.FC<RecentNotesViewProps> = ({
  notes,
  allCategories,
  activeView,
  selectedCategory,
  onSelectCategory,
  onOpenCreateCategory,
  searchQuery,
  onSearchChange,
  unlockedNoteIds,
  onSelectNote,
  onCreateNewNote,
  onToggleFavorite,
  onTogglePin,
  onChangeNoteColor,
  onSoftDelete,
  onRestoreNote,
  onPermanentDelete,
  onEmptyTrash,
  onApplyAIUpdate,
}) => {
  const [colorPickerNoteId, setColorPickerNoteId] = useState<string | null>(null);
  const [aiModalState, setAiModalState] = useState<{
    isOpen: boolean;
    note: NoteItem | null;
    initialAction: AIAction;
  }>({
    isOpen: false,
    note: null,
    initialAction: 'summarize',
  });

  const categoryNames = useMemo(
    () => allCategories.map((c) => c.name),
    [allCategories]
  );

  // Category counts based on non-deleted active notes
  const categoryCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const c of allCategories) {
      map.set(c.name.toLowerCase(), 0);
    }
    for (const n of notes) {
      if (!n.isDeleted && n.category) {
        const key = n.category.toLowerCase();
        map.set(key, (map.get(key) || 0) + 1);
      }
    }
    return map;
  }, [allCategories, notes]);

  // Sort notes: Pinned notes always stick to the top
  const sortedNotes = useMemo(() => {
    return [...notes].sort((a, b) => {
      if (activeView !== 'trash') {
        const aPinned = Boolean(a.isPinned);
        const bPinned = Boolean(b.isPinned);
        if (aPinned && !bPinned) return -1;
        if (!aPinned && bPinned) return 1;
      }
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    });
  }, [notes, activeView]);

  const viewTitle =
    activeView === 'trash'
      ? 'ট্র্যাশ বিন'
      : activeView === 'favorites'
        ? 'প্রিয় নোট'
        : activeView === 'category' && selectedCategory
          ? selectedCategory
          : 'সকল নোট';

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-5 bg-slate-50 dark:bg-black text-slate-900 dark:text-white">
      <div className="max-w-6xl mx-auto space-y-5">
        {/* Header & Search */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-[#1f1f1f]">
          <div className="flex items-center gap-3">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
              {viewTitle}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-mono bg-slate-200/80 dark:bg-[#141414] text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-[#262626]">
              {notes.length.toLocaleString('bn-BD')}
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            {/* Live Search */}
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="নোট খুঁজুন..."
                aria-label="নোট খুঁজুন"
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-[#262626] bg-white dark:bg-[#0a0a0a] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {activeView === 'trash' ? (
              notes.length > 0 && (
                <button
                  type="button"
                  onClick={onEmptyTrash}
                  className="flex items-center justify-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-xl transition-colors whitespace-nowrap"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>ট্র্যাশ খালি করুন</span>
                </button>
              )
            ) : (
              <button
                type="button"
                onClick={onCreateNewNote}
                className="flex items-center justify-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors whitespace-nowrap shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>নতুন নোট</span>
              </button>
            )}
          </div>
        </div>

        {/* Dynamic Category Filtering Row with "All Notes" Reset & "Create Category" Button */}
        {activeView !== 'trash' && (
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {/* All Notes Reset Pill */}
            <button
              type="button"
              onClick={() => onSelectCategory(null)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all shrink-0 ${
                activeView === 'all' && selectedCategory === null
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-black border-slate-900 dark:border-white shadow-xs'
                  : 'bg-white dark:bg-[#0a0a0a] text-slate-600 dark:text-slate-400 border-slate-200 dark:border-[#222222] hover:border-slate-400 dark:hover:border-slate-600'
              }`}
            >
              <span>সকল নোট</span>
            </button>

            {/* Dynamic Custom & Default Categories */}
            {allCategories.map((cat) => {
              const isSelected =
                activeView === 'category' &&
                selectedCategory?.toLowerCase() === cat.name.toLowerCase();
              const count = categoryCounts.get(cat.name.toLowerCase()) || 0;

              return (
                <button
                  key={cat.id || cat.name}
                  type="button"
                  onClick={() => onSelectCategory(cat.name)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-xl border transition-all shrink-0 ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-[#121212] text-indigo-700 dark:text-white border-indigo-500 dark:border-indigo-400 ring-1 ring-indigo-500'
                      : 'bg-white dark:bg-[#0a0a0a] text-slate-600 dark:text-slate-400 border-slate-200 dark:border-[#222222] hover:border-slate-400 dark:hover:border-slate-600'
                  }`}
                >
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: cat.color || '#6366f1' }}
                  />
                  <span>{cat.name}</span>
                  {count > 0 && (
                    <span className="text-[10px] opacity-70 font-mono">
                      ({count})
                    </span>
                  )}
                </button>
              );
            })}

            {/* Create Category Modal Trigger */}
            <button
              type="button"
              onClick={onOpenCreateCategory}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-[#0e0e0e] hover:bg-indigo-100 dark:hover:bg-[#171717] border border-dashed border-indigo-300 dark:border-indigo-900/60 rounded-xl transition-colors shrink-0"
            >
              <FolderPlus className="w-3.5 h-3.5" />
              <span>+ ক্যাটাগরি</span>
            </button>
          </div>
        )}

        {/* Empty State */}
        {sortedNotes.length === 0 ? (
          <div className="py-16 px-6 text-center bg-white dark:bg-[#070707] border border-slate-200 dark:border-[#1f1f1f] rounded-2xl space-y-3">
            <FolderOpen className="w-8 h-8 text-slate-400 mx-auto" />
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              {activeView === 'trash'
                ? 'ট্র্যাশ বিন খালি'
                : activeView === 'favorites'
                  ? 'কোনো প্রিয় নোট নেই'
                  : 'কোনো নোট পাওয়া যায়নি'}
            </h2>
            {activeView !== 'trash' && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={onCreateNewNote}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>নোট তৈরি করুন</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Notes Grid with High-Contrast AMOLED Deep Black Surfaces */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {sortedNotes.map((note) => {
              const isPinProtected = Boolean(note.pinHash);
              const isUnlocked = unlockedNoteIds.has(note.id);
              const snippetText =
                isPinProtected && !isUnlocked
                  ? '🔒 এই নোটটি পিন লক দ্বারা সুরক্ষিত।'
                  : note.contentSnippet ||
                    (note.content || '').slice(0, 160) ||
                    'কোনো বিস্তারিত লেখা নেই...';

              const wordCount = note.wordCount ?? 0;
              const isColorMenuOpen = colorPickerNoteId === note.id;
              const noteColor = note.color || '';

              const categoryMatch = allCategories.find(
                (c) => c.name.toLowerCase() === (note.category || '').toLowerCase()
              );
              const tagColor = categoryMatch?.color || '#6366f1';

              return (
                <article
                  key={note.id}
                  onClick={() => onSelectNote(note)}
                  style={
                    noteColor
                      ? {
                          borderLeftColor: noteColor,
                          borderLeftWidth: '4px',
                        }
                      : {}
                  }
                  className={`group flex flex-col justify-between p-4 rounded-2xl bg-white dark:bg-[#080808] border transition-all text-left cursor-pointer hover:shadow-sm ${
                    note.isPinned
                      ? 'border-indigo-300 dark:border-indigo-900/60 ring-1 ring-indigo-500/20'
                      : 'border-slate-200 dark:border-[#1f1f1f] hover:border-slate-400 dark:hover:border-[#333333]'
                  }`}
                >
                  <div className="space-y-2">
                    {/* Top kicker: Category dot + Pinned Badge + Lock */}
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <div className="flex items-center gap-1.5 truncate">
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{ backgroundColor: tagColor }}
                        />
                        <span className="font-medium truncate">{note.category}</span>
                        {note.subCategory && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="truncate">{note.subCategory}</span>
                          </>
                        )}
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        {note.isPinned && (
                          <span
                            className="flex items-center gap-0.5 text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-1.5 py-0.5 rounded-md"
                            title="পিন করা নোট (শীর্ষে সংরক্ষিত)"
                          >
                            <Pin className="w-2.5 h-2.5 fill-current" />
                            <span>Pinned</span>
                          </span>
                        )}
                        {isPinProtected && (
                          <span className="text-amber-500" title="পিন লকড">
                            {isUnlocked ? (
                              <Unlock className="w-3.5 h-3.5" />
                            ) : (
                              <Lock className="w-3.5 h-3.5" />
                            )}
                          </span>
                        )}
                        {note.isChunked && (
                          <span className="text-emerald-500" title="অটো-চাংকড নোট">
                            <Database className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Note Title */}
                    <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectNote(note);
                        }}
                        className="text-left w-full focus:outline-none"
                      >
                        {note.title}
                      </button>
                    </h2>

                    {/* Snippet Preview */}
                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-3 leading-relaxed">
                      {snippetText}
                    </p>
                  </div>

                  {/* Card Footer: Metadata + Quick AI Assistant + Actions */}
                  <div className="pt-3 mt-3 border-t border-slate-100 dark:border-[#1a1a1a] flex items-center justify-between gap-1 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-1.5 tabular-nums text-[11px]">
                      <FileText className="w-3 h-3 shrink-0" />
                      <span>{wordCount.toLocaleString('bn-BD')} শব্দ</span>
                    </div>

                    <div
                      className="flex items-center gap-1 shrink-0 relative"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {activeView === 'trash' ? (
                        <>
                          <button
                            type="button"
                            onClick={(e) => onRestoreNote(note, e)}
                            className="px-2 py-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg flex items-center gap-1"
                            title="পুনরুদ্ধার করুন"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>পুনরুদ্ধার</span>
                          </button>
                          <button
                            type="button"
                            onClick={(e) => onPermanentDelete(note.id, e)}
                            className="p-1 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg"
                            title="স্থায়ীভাবে মুছুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <>
                          {/* Gemini AI Quick Button */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setAiModalState({
                                isOpen: true,
                                note,
                                initialAction: 'summarize',
                              });
                            }}
                            className="p-1.5 rounded-lg text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-[#141414] transition-colors"
                            title="Gemini AI (Summarize, To-Dos, Polish, Categorize)"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                          </button>

                          {/* Color Picker Toggle */}
                          <div className="relative">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setColorPickerNoteId(isColorMenuOpen ? null : note.id);
                              }}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#141414] transition-colors"
                              title="নোটের কালার পরিবর্তন"
                            >
                              <Palette className="w-3.5 h-3.5" />
                            </button>

                            {isColorMenuOpen && (
                              <div
                                className="absolute right-0 bottom-full mb-2 p-2 bg-white dark:bg-[#111111] border border-slate-200 dark:border-[#262626] rounded-xl shadow-xl z-30 flex items-center gap-1"
                                onClick={(e) => e.stopPropagation()}
                              >
                                {COLOR_SWATCHES.map((swatch) => (
                                  <button
                                    key={swatch.value || 'none'}
                                    type="button"
                                    onClick={(e) => {
                                      onChangeNoteColor(note, swatch.value, e);
                                      setColorPickerNoteId(null);
                                    }}
                                    style={{
                                      backgroundColor: swatch.value || '#94a3b8',
                                    }}
                                    className="w-5 h-5 rounded-full border border-black/10 dark:border-white/20 transition-transform hover:scale-110 flex items-center justify-center"
                                    title={swatch.label}
                                  >
                                    {note.color === swatch.value && (
                                      <Check className="w-3 h-3 text-white" />
                                    )}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* Pin to Top Button */}
                          <button
                            type="button"
                            onClick={(e) => onTogglePin(note, e)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              note.isPinned
                                ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60'
                                : 'text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#141414]'
                            }`}
                            title={note.isPinned ? 'আনপিন করুন' : 'শীর্ষে পিন করুন'}
                          >
                            <Pin
                              className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-current' : ''}`}
                            />
                          </button>

                          {/* Favorite Star Button */}
                          <button
                            type="button"
                            onClick={(e) => onToggleFavorite(note, e)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              note.isFavorite
                                ? 'text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/40'
                                : 'text-slate-400 hover:text-slate-700 dark:hover:text-white'
                            }`}
                            title={note.isFavorite ? 'প্রিয় থেকে সরান' : 'প্রিয় তালিকায় যুক্ত করুন'}
                          >
                            <Star
                              className={`w-3.5 h-3.5 ${note.isFavorite ? 'fill-current' : ''}`}
                            />
                          </button>

                          {/* Trash Delete */}
                          <button
                            type="button"
                            onClick={(e) => onSoftDelete(note, e)}
                            className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      {/* Gemini AI Action Modal */}
      {aiModalState.isOpen && aiModalState.note && (
        <AIActionModal
          isOpen={aiModalState.isOpen}
          onClose={() => setAiModalState({ isOpen: false, note: null, initialAction: 'summarize' })}
          note={aiModalState.note}
          categories={categoryNames}
          initialAction={aiModalState.initialAction}
          onApplyToNote={onApplyAIUpdate}
        />
      )}
    </div>
  );
};

export default RecentNotesView;
