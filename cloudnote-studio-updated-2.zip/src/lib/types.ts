export interface NoteSection {
  id: string;
  title: string;
  content: string;
  color?: string;
}

export type NoteFontFamily = 'sans' | 'serif' | 'hind' | 'tiro' | 'mono';

export interface CategoryItem {
  id: string;
  name: string;
  color: string;
  createdAt?: string;
}

export interface NoteItem {
  id: string;
  title: string;
  category: string;
  subCategory?: string;
  /**
   * In memory: assembled full text across all sections for fast search/export.
   * In Firestore: truncated to a 300-character snippet to avoid duplicating sections and hitting the 1MiB limit.
   */
  content: string;
  contentSnippet?: string;
  sections: NoteSection[];
  tags?: string[];
  isFavorite: boolean;
  isPinned?: boolean;
  color?: string;
  isDeleted?: boolean;
  deletedAt?: string | null;
  /**
   * 4-digit PIN hash (or plain 4-digit PIN hash string) for locking sensitive notes.
   */
  pinHash?: string | null;
  isLocked?: boolean;
  /**
   * Storage metadata for automatic Firestore chunking (>600KB notes).
   */
  isChunked?: boolean;
  chunkCount?: number;
  byteSize?: number;
  wordCount?: number;
  createdAt: string;
  updatedAt: string;
  userId?: string;
  fontFamily?: NoteFontFamily;
}

export interface NoteChunkDoc {
  id: string;
  noteId: string;
  userId: string;
  chunkIndex: number;
  totalChunks: number;
  payload: string;
  byteLength: number;
  updatedAt: string;
}

export interface NoteDraft {
  noteId: string;
  title: string;
  category: string;
  subCategory?: string;
  sections: NoteSection[];
  tags: string[];
  fontFamily?: NoteFontFamily;
  updatedAt: string;
}

export interface NoteVersionSnapshot {
  versionId: string;
  noteId: string;
  title: string;
  category: string;
  sections: NoteSection[];
  wordCount: number;
  byteSize: number;
  savedAt: string;
}

export interface CloudBackupBundle {
  version: string;
  exportedAt: string;
  accountEmail: string | null;
  accountName: string | null;
  totalNotes: number;
  notes: NoteItem[];
}

export type CloudSyncState = 'synced' | 'syncing' | 'offline-vault' | 'error';

export interface TocEntry {
  id: string;
  text: string;
  level: number; // 0 = Section Title, 1..4 = Markdown H1..H4
  sectionId: string;
  sectionIndex: number;
  headingIndex?: number;
}

export type AIActionType =
  | 'summarize'
  | 'extract_todos'
  | 'polish_text'
  | 'auto_categorize'
  | 'format'
  | 'grammar'
  | 'translate_bn_en'
  | 'translate_en_bn';

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL?: string | null;
  isLocalMode?: boolean;
  authProvider?: 'firebase-email' | 'firebase-google' | 'cloud-vault' | 'guest';
  lastSyncedAt?: string | null;
}
