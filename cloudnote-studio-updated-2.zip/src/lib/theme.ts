/**
 * Cloud Note theme system.
 * - light     : standard light
 * - dark      : soft dark (slate) with high contrast text
 * - sepia     : warm reading
 * - midnight  : deep OLED black (the original AMOLED look)
 * - forest    : soft mint
 * - paper     : soft paper
 *
 * The chosen theme is persisted in localStorage and applied on <html> via
 * `data-theme` (+ the `dark` class for dark-family themes).
 */

export type ThemeId = 'light' | 'dark' | 'sepia' | 'midnight' | 'forest' | 'paper';

export interface ThemeOption {
  id: ThemeId;
  label: string;
  labelBn: string;
  isDark: boolean;
  /** Preview swatch colors */
  swatch: { bg: string; fg: string };
  /** Browser UI color (<meta name="theme-color">) */
  themeColor: string;
}

export const THEMES: ThemeOption[] = [
  { id: 'light', label: 'Light', labelBn: 'লাইট', isDark: false, swatch: { bg: '#ffffff', fg: '#0f172a' }, themeColor: '#ffffff' },
  { id: 'dark', label: 'Dark', labelBn: 'ডার্ক', isDark: true, swatch: { bg: '#0f1729', fg: '#f1f5f9' }, themeColor: '#0f1729' },
  { id: 'sepia', label: 'Sepia / Warm Reading', labelBn: 'সেপিয়া (উষ্ণ পাঠ)', isDark: false, swatch: { bg: '#f4ecd8', fg: '#2c221a' }, themeColor: '#f4ecd8' },
  { id: 'midnight', label: 'Midnight (OLED Black)', labelBn: 'মিডনাইট (গাঢ় কালো)', isDark: true, swatch: { bg: '#000000', fg: '#f8fafc' }, themeColor: '#000000' },
  { id: 'forest', label: 'Forest / Soft Mint', labelBn: 'ফরেস্ট (নরম মিন্ট)', isDark: false, swatch: { bg: '#e9f3ec', fg: '#14291f' }, themeColor: '#e9f3ec' },
  { id: 'paper', label: 'Paper Soft', labelBn: 'পেপার সফট', isDark: false, swatch: { bg: '#f3f3ef', fg: '#1c1c1a' }, themeColor: '#f3f3ef' },
];

export const THEME_STORAGE_KEY = 'cloudnote_theme';
/** Legacy key from the old Light/AMOLED toggle ('true' = AMOLED, 'false' = light). */
const LEGACY_STORAGE_KEY = 'cloudnote_amoled_mode';
export const DEFAULT_THEME: ThemeId = 'midnight';

export function isThemeId(value: unknown): value is ThemeId {
  return typeof value === 'string' && THEMES.some((t) => t.id === value);
}

export function getThemeOption(id: ThemeId): ThemeOption {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}

export function isDarkTheme(id: ThemeId): boolean {
  return getThemeOption(id).isDark;
}

export function loadSavedTheme(): ThemeId {
  if (typeof window === 'undefined') return DEFAULT_THEME;
  try {
    const saved = window.localStorage.getItem(THEME_STORAGE_KEY);
    if (isThemeId(saved)) return saved;
    // Migrate from the previous Light/AMOLED toggle so existing users keep their look
    const legacy = window.localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacy === 'true') return 'midnight';
    if (legacy === 'false') return 'light';
  } catch {
    // localStorage unavailable
  }
  return DEFAULT_THEME;
}

export function applyTheme(id: ThemeId, persist = true): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const option = getThemeOption(id);

  root.setAttribute('data-theme', option.id);
  root.classList.toggle('dark', option.isDark);
  root.classList.toggle('amoled', option.id === 'midnight');

  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', option.themeColor);

  if (persist) {
    try {
      window.localStorage.setItem(THEME_STORAGE_KEY, option.id);
    } catch {
      // localStorage unavailable
    }
  }
}

/**
 * Inline script (string) that runs before first paint so there is no flash of the wrong theme.
 * Mirrors loadSavedTheme()/applyTheme().
 */
export const THEME_INIT_SCRIPT = `(function(){try{var d={light:0,dark:1,sepia:0,midnight:1,forest:0,paper:0};var t=localStorage.getItem('${THEME_STORAGE_KEY}');if(!(t in d)){var l=localStorage.getItem('${LEGACY_STORAGE_KEY}');t=l==='false'?'light':'${DEFAULT_THEME}';}var r=document.documentElement;r.setAttribute('data-theme',t);if(d[t])r.classList.add('dark');if(t==='midnight')r.classList.add('amoled');}catch(e){}})();`;
