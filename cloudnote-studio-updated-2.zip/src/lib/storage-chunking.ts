import type { NoteChunkDoc, NoteFontFamily, NoteItem, NoteSection } from './types.ts';
import { computeSectionsMetrics, normalizeUnicodeText } from './text-normalizer.ts';

/**
 * Threshold in UTF-8 bytes above which a note's sections are automatically chunked
 * into the `note_chunks` subcollection/collection (~600 KB, well below Firestore's 1 MiB limit).
 */
export const MAX_FIRESTORE_INLINE_BYTES = 600 * 1024;

/**
 * Target maximum UTF-8 byte size for each individual chunk document (~450 KB).
 */
export const CHUNK_TARGET_BYTES = 450 * 1024;

/**
 * Maximum characters stored in the main Firestore document's `content` / `contentSnippet` field
 * so full text is never duplicated in Firestore.
 */
export const FIRESTORE_SNIPPET_MAX_CHARS = 300;

/**
 * Blueprint schema constraints (synchronized with firebase-blueprint.json & firestore.rules).
 */
export const MAX_ID_LENGTH = 128;
export const ID_PATTERN_REGEX = /^[a-zA-Z0-9_\-]+$/;
export const MAX_TITLE_CHARS = 500;
export const MAX_CATEGORY_CHARS = 120;
export const MAX_TAG_COUNT = 50;
export const MAX_TAG_CHARS = 60;
export const MAX_INLINE_SECTIONS = 200;
export const ALLOWED_FONT_FAMILIES: NoteFontFamily[] = ['sans', 'serif', 'hind', 'tiro', 'mono'];

const utf8Encoder = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;

export function sanitizeFirestoreId(rawId: string, fallbackPrefix = 'doc'): string {
  const cleaned = (rawId || '')
    .trim()
    .replace(/[^a-zA-Z0-9_\-]/g, '_')
    .slice(0, MAX_ID_LENGTH);
  if (!cleaned || !ID_PATTERN_REGEX.test(cleaned)) {
    return `${fallbackPrefix}_${Date.now()}`;
  }
  return cleaned;
}

export function getUtf8ByteLength(str: string): number {
  if (!str) return 0;
  if (utf8Encoder) {
    return utf8Encoder.encode(str).byteLength;
  }
  return unescape(encodeURIComponent(str)).length;
}

/**
 * Assembles full in-memory text from a note's sections.
 */
export function assembleFullContent(sections: NoteSection[]): string {
  if (!sections || sections.length === 0) return '';
  return sections
    .map((sec) => {
      const title = (sec.title || '').trim();
      const body = sec.content || '';
      return title ? `## ${title}\n${body}` : body;
    })
    .join('\n\n');
}

/**
 * Creates a clean 300-character search snippet for the main Firestore document.
 */
export function createSearchSnippet(
  fullText: string,
  maxChars = FIRESTORE_SNIPPET_MAX_CHARS
): string {
  if (!fullText) return '';
  const cleaned = normalizeUnicodeText(fullText)
    .replace(/[#*`~>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (cleaned.length <= maxChars) return cleaned;
  return cleaned.slice(0, maxChars).trim() + '…';
}

/**
 * Splits a UTF-8 string into slices where each slice is at most `maxBytes` UTF-8 bytes,
 * without ever splitting a multi-byte UTF-8 character or surrogate pair in half.
 */
export function splitStringByUtf8Bytes(input: string, maxBytes: number): string[] {
  if (!input) return [''];
  const totalBytes = getUtf8ByteLength(input);
  if (totalBytes <= maxBytes) return [input];

  const chunks: string[] = [];
  let currentChars: string[] = [];
  let currentBytes = 0;

  for (const codePoint of input) {
    const cpBytes = getUtf8ByteLength(codePoint);
    if (currentBytes + cpBytes > maxBytes && currentChars.length > 0) {
      chunks.push(currentChars.join(''));
      currentChars = [codePoint];
      currentBytes = cpBytes;
    } else {
      currentChars.push(codePoint);
      currentBytes += cpBytes;
    }
  }

  if (currentChars.length > 0) {
    chunks.push(currentChars.join(''));
  }

  return chunks;
}

/**
 * Splits serialized `NoteSection[]` into `NoteChunkDoc[]` so notes of unlimited size
 * (even 10MB+ or 100,000+ Bengali words) can be stored in Firestore `note_chunks`.
 */
export function splitSectionsIntoChunks(
  noteId: string,
  sections: NoteSection[],
  maxChunkBytes = CHUNK_TARGET_BYTES,
  userId = 'local-user'
): NoteChunkDoc[] {
  const safeNoteId = sanitizeFirestoreId(noteId, 'note');
  const safeUserId = sanitizeFirestoreId(userId, 'user');
  const normalizedSections: NoteSection[] = (sections || []).map((sec, idx) => ({
    id: sec.id || `sec-${idx + 1}`,
    title: normalizeUnicodeText(sec.title || ''),
    content: normalizeUnicodeText(sec.content || ''),
    ...(sec.color ? { color: sec.color } : {}),
  }));

  const serialized = JSON.stringify(normalizedSections);
  const rawSlices = splitStringByUtf8Bytes(serialized, maxChunkBytes);
  const now = new Date().toISOString();

  return rawSlices.map((payload, idx) => ({
    id: sanitizeFirestoreId(`${safeNoteId}_chunk_${String(idx).padStart(4, '0')}`, 'chunk'),
    noteId: safeNoteId,
    userId: safeUserId,
    chunkIndex: idx,
    totalChunks: rawSlices.length,
    payload,
    byteLength: getUtf8ByteLength(payload),
    updatedAt: now,
  }));
}

/**
 * Reassembles `NoteSection[]` from ordered or unordered `NoteChunkDoc[]`.
 */
export function reassembleSectionsFromChunks(chunks: NoteChunkDoc[]): NoteSection[] {
  if (!chunks || chunks.length === 0) return [];
  const sorted = [...chunks].sort((a, b) => a.chunkIndex - b.chunkIndex);
  const combinedJson = sorted.map((c) => c.payload).join('');
  try {
    const parsed = JSON.parse(combinedJson);
    if (Array.isArray(parsed)) {
      return parsed.map((sec, idx) => ({
        id: String(sec.id || `sec-${idx + 1}`),
        title: normalizeUnicodeText(String(sec.title || '')),
        content: normalizeUnicodeText(String(sec.content || '')),
        ...(sec.color ? { color: String(sec.color) } : {}),
      }));
    }
  } catch {
    return [
      {
        id: 'sec-recovered-1',
        title: 'মূল অনুচ্ছেদ',
        content: normalizeUnicodeText(combinedJson),
      },
    ];
  }
  return [];
}

/**
 * Prepares a `NoteItem` for saving to Firestore with strict defensive truncation/validation
 * synchronized with `firebase-blueprint.json` and `firestore.rules`.
 */
export function prepareNoteForFirestore(
  note: NoteItem,
  inlineThresholdBytes = MAX_FIRESTORE_INLINE_BYTES,
  chunkTargetBytes = CHUNK_TARGET_BYTES
): {
  firestoreDoc: Record<string, unknown>;
  chunks: NoteChunkDoc[];
  hydratedNote: NoteItem;
} {
  const safeId = sanitizeFirestoreId(note.id, 'note');
  const safeUserId = sanitizeFirestoreId(note.userId || 'local-user', 'user');

  const normalizedSections: NoteSection[] =
    note.sections && note.sections.length > 0
      ? note.sections.map((sec, idx) => ({
          id: sec.id || `sec-${idx + 1}`,
          title: normalizeUnicodeText(sec.title || ''),
          content: normalizeUnicodeText(sec.content || ''),
          ...(sec.color ? { color: sec.color } : {}),
        }))
      : [
          {
            id: 'sec-1',
            title: 'মূল নোট',
            content: normalizeUnicodeText(note.content || ''),
          },
        ];

  const fullContent = assembleFullContent(normalizedSections);
  const snippet = createSearchSnippet(fullContent, FIRESTORE_SNIPPET_MAX_CHARS);
  const metrics = computeSectionsMetrics(normalizedSections);
  const serializedSectionsBytes = getUtf8ByteLength(JSON.stringify(normalizedSections));

  const needsChunking =
    serializedSectionsBytes > inlineThresholdBytes ||
    normalizedSections.length > MAX_INLINE_SECTIONS;

  const chunks = needsChunking
    ? splitSectionsIntoChunks(safeId, normalizedSections, chunkTargetBytes, safeUserId)
    : [];

  const now = note.updatedAt || new Date().toISOString();
  const safeTitle =
    normalizeUnicodeText(note.title || 'শিরোনামহীন নোট')
      .trim()
      .slice(0, MAX_TITLE_CHARS) || 'শিরোনামহীন নোট';
  const safeCategory =
    normalizeUnicodeText(note.category || 'সাধারণ')
      .trim()
      .slice(0, MAX_CATEGORY_CHARS) || 'সাধারণ';
  const safeSubCategory = note.subCategory
    ? normalizeUnicodeText(note.subCategory).trim().slice(0, MAX_CATEGORY_CHARS)
    : '';
  const baseTags = (note.tags || [])
    .map((t) => normalizeUnicodeText(String(t)).trim().slice(0, MAX_TAG_CHARS))
    .filter((t) => Boolean(t) && t !== 'pinned' && !t.startsWith('color:'))
    .slice(0, 48);
  const safeTags = [
    ...(note.isPinned ? ['pinned'] : []),
    ...(note.color ? [`color:${note.color}`] : []),
    ...baseTags,
  ];
  const safeFontFamily: NoteFontFamily = ALLOWED_FONT_FAMILIES.includes(
    note.fontFamily as NoteFontFamily
  )
    ? (note.fontFamily as NoteFontFamily)
    : 'sans';

  const hydratedNote: NoteItem = {
    ...note,
    id: safeId,
    title: safeTitle,
    category: safeCategory,
    subCategory: safeSubCategory || undefined,
    sections: normalizedSections,
    tags: safeTags,
    content: fullContent,
    contentSnippet: snippet,
    isFavorite: Boolean(note.isFavorite),
    isPinned: Boolean(note.isPinned),
    color: note.color,
    isDeleted: Boolean(note.isDeleted),
    deletedAt: note.deletedAt ? String(note.deletedAt).slice(0, 64) : null,
    pinHash: note.pinHash ? String(note.pinHash).slice(0, 256) : null,
    isLocked: Boolean(note.pinHash),
    isChunked: needsChunking,
    chunkCount: chunks.length,
    byteSize: Math.min(100000000, Math.max(0, metrics.byteSize)),
    wordCount: Math.min(20000000, Math.max(0, metrics.wordCount)),
    createdAt: (note.createdAt || now).slice(0, 64),
    updatedAt: now.slice(0, 64),
    userId: safeUserId,
    fontFamily: safeFontFamily,
  };

  // Main Firestore document strictly matches NoteDoc schema in firebase-blueprint.json & firestore.rules
  const firestoreDoc: Record<string, unknown> = {
    id: hydratedNote.id,
    title: hydratedNote.title,
    category: hydratedNote.category,
    subCategory: safeSubCategory,
    content: snippet,
    contentSnippet: snippet,
    sections: needsChunking ? [] : normalizedSections,
    tags: safeTags,
    isFavorite: hydratedNote.isFavorite,
    isDeleted: hydratedNote.isDeleted,
    deletedAt: hydratedNote.deletedAt,
    pinHash: hydratedNote.pinHash,
    isLocked: hydratedNote.isLocked,
    isChunked: needsChunking,
    chunkCount: chunks.length,
    byteSize: hydratedNote.byteSize,
    wordCount: hydratedNote.wordCount,
    createdAt: hydratedNote.createdAt,
    updatedAt: hydratedNote.updatedAt,
    userId: safeUserId,
    fontFamily: safeFontFamily,
  };

  return { firestoreDoc, chunks, hydratedNote };
}

/**
 * Reassembles a `NoteItem` loaded from Firestore (and optional `note_chunks`) into memory
 * with full `sections` and assembled `content`.
 */
export function hydrateNoteInMemory(
  rawDoc: Partial<NoteItem> & { id: string },
  chunks?: NoteChunkDoc[]
): NoteItem {
  let sections: NoteSection[] = [];

  if (rawDoc.isChunked && chunks && chunks.length > 0) {
    sections = reassembleSectionsFromChunks(chunks);
  } else if (Array.isArray(rawDoc.sections) && rawDoc.sections.length > 0) {
    sections = rawDoc.sections.map((sec, idx) => ({
      id: sec.id || `sec-${idx + 1}`,
      title: normalizeUnicodeText(sec.title || ''),
      content: normalizeUnicodeText(sec.content || ''),
      ...(sec.color ? { color: sec.color } : {}),
    }));
  } else if (rawDoc.content) {
    sections = [
      {
        id: 'sec-1',
        title: 'মূল নোট',
        content: normalizeUnicodeText(rawDoc.content),
      },
    ];
  } else {
    sections = [
      {
        id: 'sec-1',
        title: 'মূল নোট',
        content: '',
      },
    ];
  }

  const fullContent = assembleFullContent(sections);
  const metrics = computeSectionsMetrics(sections);
  const snippet = rawDoc.contentSnippet || createSearchSnippet(fullContent);

  return {
    id: rawDoc.id,
    title: normalizeUnicodeText(rawDoc.title || 'শিরোনামহীন নোট'),
    category: normalizeUnicodeText(rawDoc.category || 'সাধারণ'),
    subCategory: rawDoc.subCategory ? normalizeUnicodeText(rawDoc.subCategory) : undefined,
    content: fullContent,
    contentSnippet: snippet,
    sections,
    tags: Array.isArray(rawDoc.tags) ? rawDoc.tags : [],
    isFavorite: Boolean(rawDoc.isFavorite),
    isPinned: Boolean(
      rawDoc.isPinned || (Array.isArray(rawDoc.tags) && rawDoc.tags.includes('pinned'))
    ),
    color:
      rawDoc.color ||
      (Array.isArray(rawDoc.tags)
        ? rawDoc.tags.find((t) => typeof t === 'string' && t.startsWith('color:'))?.replace('color:', '')
        : undefined),
    isDeleted: Boolean(rawDoc.isDeleted),
    deletedAt: rawDoc.deletedAt ?? null,
    pinHash: rawDoc.pinHash ?? null,
    isLocked: Boolean(rawDoc.pinHash || rawDoc.isLocked),
    isChunked: Boolean(rawDoc.isChunked),
    chunkCount: rawDoc.chunkCount ?? (chunks ? chunks.length : 0),
    byteSize: metrics.byteSize,
    wordCount: metrics.wordCount,
    createdAt: rawDoc.createdAt || new Date().toISOString(),
    updatedAt: rawDoc.updatedAt || new Date().toISOString(),
    userId: rawDoc.userId,
    fontFamily: rawDoc.fontFamily || 'sans',
  };
}
