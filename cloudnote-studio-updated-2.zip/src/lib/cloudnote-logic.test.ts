import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeUnicodeText,
  convertAILaTeXDelimiters,
  smartCleanAIPaste,
  extractTocEntries,
  findMatchesInSections,
  replaceInSections,
  hashPin,
  verifyPin,
  deriveUserIdFromEmail,
  hashAccountPassword,
  verifyAccountPassword,
} from './text-normalizer.ts';
import {
  prepareNoteForFirestore,
  hydrateNoteInMemory,
  FIRESTORE_SNIPPET_MAX_CHARS,
  sanitizeFirestoreId,
  ID_PATTERN_REGEX,
} from './storage-chunking.ts';
import type { NoteItem, NoteSection } from './types.ts';

test('normalizeUnicodeText preserves Bengali ZWNJ/ZWJ while stripping broken zero-width artifacts', () => {
  const bengaliWithZwjAndArtifacts = '\uFEFFর\u200D্য\u200B এবং ক\u200C্\u2060';
  const normalized = normalizeUnicodeText(bengaliWithZwjAndArtifacts);

  assert.equal(normalized.includes('\uFEFF'), false, 'Should strip BOM');
  assert.equal(normalized.includes('\u200B'), false, 'Should strip ZWSP');
  assert.equal(normalized.includes('\u2060'), false, 'Should strip Word Joiner');
  assert.equal(normalized.includes('\u200D'), true, 'Must preserve Bengali ZWJ');
  assert.equal(normalized.includes('\u200C'), true, 'Must preserve Bengali ZWNJ');
});

test('convertAILaTeXDelimiters converts \\[...\\] and \\(...\\) to $$...$$ and $...$ without altering code blocks', () => {
  const aiPaste = [
    'আইনস্টাইনের সমীকরণ \\( E = mc^2 \\) এবং নিউটনের সূত্র:',
    '\\[ F = G \\frac{m_1 m_2}{r^2} \\]',
    '```python',
    'formula = "\\[ not_converted \\] and \\( inline \\)"',
    '```',
  ].join('\n');

  const converted = convertAILaTeXDelimiters(aiPaste);
  assert.equal(converted.includes('$E = mc^2$'), true);
  assert.equal(converted.includes('$$\nF = G \\frac{m_1 m_2}{r^2}\n$$'), true);
  assert.equal(converted.includes('"\\[ not_converted \\] and \\( inline \\)"'), true);
});

test('smartCleanAIPaste repairs broken GFM table blank lines', () => {
  const brokenTable = [
    '| বিষয় | সূত্র |',
    '',
    '| --- | --- |',
    '',
    '| গতিশক্তি | \\( E_k = \\frac{1}{2}mv^2 \\) |',
  ].join('\n');

  const cleaned = smartCleanAIPaste(brokenTable);
  assert.equal(
    cleaned,
    ['| বিষয় | সূত্র |', '| --- | --- |', '| গতিশক্তি | $E_k = \\frac{1}{2}mv^2$ |']
      .join('\n')
      .normalize('NFC')
  );
});

test('extractTocEntries builds section and heading outline for Table of Contents', () => {
  const sections: NoteSection[] = [
    {
      id: 's1',
      title: 'প্রথম অধ্যায়: বলবিদ্যা',
      content: '# নিউটনের গতিসূত্র\nকিছু লেখা\n## প্রথম সূত্র\n```\n# কোড কমেন্ট\n```',
    },
    {
      id: 's2',
      title: 'দ্বিতীয় অধ্যায়: তাপগতিবিদ্যা',
      content: '### কার্নোর ইঞ্জিন',
    },
  ];

  const toc = extractTocEntries(sections);
  assert.equal(toc.length, 5);
  assert.equal(toc[0].level, 0);
  assert.equal(toc[0].text, 'প্রথম অধ্যায়: বলবিদ্যা');
  assert.equal(toc[1].level, 1);
  assert.equal(toc[1].text, 'নিউটনের গতিসূত্র');
  assert.equal(toc[2].level, 2);
  assert.equal(toc[2].text, 'প্রথম সূত্র');
  assert.equal(toc[3].level, 0);
  assert.equal(toc[4].level, 3);
  assert.equal(toc[4].text, 'কার্নোর ইঞ্জিন');
});

test('findMatchesInSections and replaceInSections work across Bengali and English text', () => {
  const sections: NoteSection[] = [
    { id: '1', title: 'কৃত্রিম বুদ্ধিমত্তা নোট', content: 'এআই বা কৃত্রিম বুদ্ধিমত্তা ভবিষ্যৎ বদলে দিচ্ছে।' },
    { id: '2', title: 'ব্যবহার', content: 'কৃত্রিম বুদ্ধিমত্তা শিক্ষা ও চিকিৎসায় ব্যবহৃত হয়।' },
  ];

  const matchResult = findMatchesInSections(sections, 'কৃত্রিম বুদ্ধিমত্তা');
  assert.equal(matchResult.totalMatches, 3);
  assert.equal(matchResult.matchesBySection['1'], 2);
  assert.equal(matchResult.matchesBySection['2'], 1);

  const replaced = replaceInSections(sections, 'কৃত্রিম বুদ্ধিমত্তা', 'মেশিন লার্নিং', {
    replaceAll: true,
  });
  assert.equal(replaced.replacedCount, 3);
  assert.equal(replaced.sections[0].title, 'মেশিন লার্নিং নোট');
});

test('PIN lock hashing and verification works deterministically', () => {
  const hash = hashPin('2580');
  assert.equal(verifyPin('2580', hash), true);
  assert.equal(verifyPin('1234', hash), false);
});

test('Account Vault email-to-UID derivation and password hashing work deterministically and obey Firestore ID regex', () => {
  const uid1 = deriveUserIdFromEmail('Mushfiq@Example.com ');
  const uid2 = deriveUserIdFromEmail('mushfiq@example.com');
  assert.equal(uid1, uid2);
  assert.equal(ID_PATTERN_REGEX.test(uid1), true);
  assert.equal(uid1.length <= 128, true);

  const pwHash = hashAccountPassword('mushfiq@example.com', 'SecretPass123');
  assert.equal(verifyAccountPassword('mushfiq@example.com', 'SecretPass123', pwHash), true);
  assert.equal(verifyAccountPassword('mushfiq@example.com', 'WrongPass999', pwHash), false);
  assert.equal(sanitizeFirestoreId('bad$id!@#', 'note').match(ID_PATTERN_REGEX) !== null, true);
});

test('prepareNoteForFirestore truncates duplicate content and automatically chunks large Bengali notes', () => {
  const longBengaliParagraph = 'বাংলা ইউনিকোড ও গাণিতিক প্রতীক 𝕏, 𝒜, ∑, ∫, √, ∞, ≠, ≤, ≥ সহ দীর্ঘ নোট। '.repeat(120);
  const sections: NoteSection[] = [
    { id: 'sec-1', title: 'বৃহৎ অনুচ্ছেদ ১', content: longBengaliParagraph },
    { id: 'sec-2', title: 'বৃহৎ অনুচ্ছেদ ২', content: longBengaliParagraph },
  ];

  const sampleNote: NoteItem = {
    id: 'note-large-1',
    title: 'বৃহৎ গবেষণা নোট',
    category: 'বিজ্ঞান',
    content: longBengaliParagraph + longBengaliParagraph,
    sections,
    isFavorite: true,
    createdAt: '2026-10-17T00:00:00.000Z',
    updatedAt: '2026-10-17T00:00:00.000Z',
    userId: 'usr_test_1',
  };

  const { firestoreDoc, chunks, hydratedNote } = prepareNoteForFirestore(sampleNote, 5000, 2000);

  assert.equal(typeof firestoreDoc.content, 'string');
  assert.equal((firestoreDoc.content as string).length <= FIRESTORE_SNIPPET_MAX_CHARS + 1, true);
  assert.equal(firestoreDoc.isChunked, true);
  assert.equal((firestoreDoc.sections as unknown[]).length, 0);
  assert.equal(chunks.length > 5, true);
  assert.equal(chunks[0].userId, 'usr_test_1');

  const reassembled = hydrateNoteInMemory(
    firestoreDoc as Partial<NoteItem> & { id: string },
    chunks
  );
  assert.equal(reassembled.sections.length, 2);
  assert.equal(reassembled.sections[0].content, hydratedNote.sections[0].content);
  assert.equal(reassembled.sections[1].content, hydratedNote.sections[1].content);
  assert.equal(reassembled.content.includes('𝕏, 𝒜, ∑, ∫, √, ∞, ≠, ≤, ≥'), true);
});

test('convertMarkdownAndMathToHtml converts Markdown, tables, code blocks, and KaTeX math into styled HTML', async () => {
  const { convertMarkdownAndMathToHtml } = await import('./pdf-export.ts');
  const sample = [
    '# পদার্থবিজ্ঞান নোট',
    'ভর-শক্তি সমীকরণ: \\( E = mc^2 \\)',
    '',
    '| রাশি | একক |',
    '| --- | --- |',
    '| বল | নিউটন |',
    '',
    '```js',
    'const x = 42;',
    '```',
  ].join('\n');

  const html = convertMarkdownAndMathToHtml(sample);
  assert.equal(html.includes('<h1>পদার্থবিজ্ঞান নোট</h1>'), true);
  assert.equal(html.includes('<table>'), true);
  assert.equal(html.includes('katex'), true);
  assert.equal(html.includes('<code class="language-js">'), true);
});
