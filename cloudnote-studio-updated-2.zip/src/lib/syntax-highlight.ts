/**
 * Tiny dependency-free syntax highlighter for fenced code blocks.
 * Produces a flat list of { type, text } tokens that the renderer maps to <span class="tok-*">.
 * It is intentionally lightweight (comments, strings, numbers, keywords, functions, types, operators)
 * and never throws - unknown languages are returned as a single plain token.
 */

export type TokenType =
  | 'comment'
  | 'keyword'
  | 'string'
  | 'number'
  | 'function'
  | 'type'
  | 'attr'
  | 'tag'
  | 'op'
  | 'punct'
  | 'plain';

export interface Token {
  type: TokenType;
  text: string;
}

type Family = 'c' | 'python' | 'shell' | 'sql' | 'json' | 'markup' | 'css' | 'plain';

const KEYWORDS: Record<string, string[]> = {
  c: (
    'abstract as async await break case catch class const continue debugger default delete do else enum export extends ' +
    'false final finally for from function goto if implements import in instanceof interface let namespace new null of ' +
    'package private protected public readonly return static struct super switch this throw throws true try type typeof ' +
    'undefined var void volatile while with yield fn impl mod pub use mut match loop self crate trait where func defer ' +
    'go chan select range map int float double long short char bool boolean string byte unsigned signed auto sizeof ' +
    'typedef union extern inline using template typename virtual override nullptr final val object fun when is'
  ).split(' '),
  python: (
    'False None True and as assert async await break class continue def del elif else except finally for from global ' +
    'if import in is lambda nonlocal not or pass raise return try while with yield self print match case'
  ).split(' '),
  shell: (
    'if then else elif fi for while do done case esac in function return export local echo cd ls cat grep sed awk ' +
    'sudo apt npm npx yarn pnpm pip git curl wget mkdir rm cp mv chmod chown source exit set unset alias'
  ).split(' '),
  sql: (
    'SELECT FROM WHERE INSERT INTO VALUES UPDATE SET DELETE CREATE TABLE DROP ALTER ADD JOIN LEFT RIGHT INNER OUTER ON ' +
    'GROUP BY ORDER HAVING LIMIT OFFSET AS AND OR NOT NULL IS IN LIKE DISTINCT UNION ALL INDEX PRIMARY KEY FOREIGN ' +
    'REFERENCES DEFAULT CASE WHEN THEN ELSE END COUNT SUM AVG MIN MAX BETWEEN EXISTS ASC DESC'
  ).split(' '),
  json: ['true', 'false', 'null'],
};

const LANGUAGE_FAMILY: Record<string, Family> = {
  js: 'c', javascript: 'c', jsx: 'c', ts: 'c', typescript: 'c', tsx: 'c', java: 'c', c: 'c', cpp: 'c', 'c++': 'c',
  cs: 'c', csharp: 'c', go: 'c', golang: 'c', rust: 'c', rs: 'c', kotlin: 'c', swift: 'c', dart: 'c', php: 'c',
  scala: 'c', solidity: 'c',
  python: 'python', py: 'python', ruby: 'python', rb: 'python', yaml: 'python', yml: 'python', toml: 'python',
  bash: 'shell', sh: 'shell', shell: 'shell', zsh: 'shell', console: 'shell', terminal: 'shell', powershell: 'shell',
  sql: 'sql', mysql: 'sql', postgres: 'sql', postgresql: 'sql', sqlite: 'sql',
  json: 'json', jsonc: 'json',
  html: 'markup', xml: 'markup', svg: 'markup', vue: 'markup',
  css: 'css', scss: 'css', less: 'css',
};

export function normalizeLanguage(lang?: string | null): string {
  return (lang || '').trim().toLowerCase().replace(/^language-/, '');
}

function push(tokens: Token[], type: TokenType, text: string) {
  if (!text) return;
  const last = tokens[tokens.length - 1];
  if (last && last.type === type) {
    last.text += text;
  } else {
    tokens.push({ type, text });
  }
}

function tokenizeMarkup(code: string): Token[] {
  const tokens: Token[] = [];
  const re = /(<!--[\s\S]*?-->)|(<\/?)([A-Za-z][\w:-]*)((?:\s+[^\s=>/]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?)*)\s*(\/?>)|([^<]+)|(<)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(code)) !== null) {
    if (m[1]) {
      push(tokens, 'comment', m[1]);
    } else if (m[3]) {
      push(tokens, 'punct', m[2]);
      push(tokens, 'tag', m[3]);
      const attrs = m[4] || '';
      const attrRe = /(\s+)([^\s=>/]+)(?:(\s*=\s*)("[^"]*"|'[^']*'|[^\s>]+))?/g;
      let a: RegExpExecArray | null;
      while ((a = attrRe.exec(attrs)) !== null) {
        push(tokens, 'plain', a[1]);
        push(tokens, 'attr', a[2]);
        if (a[3]) push(tokens, 'op', a[3]);
        if (a[4]) push(tokens, 'string', a[4]);
      }
      push(tokens, 'punct', m[5]);
    } else if (m[6]) {
      push(tokens, 'plain', m[6]);
    } else if (m[7]) {
      push(tokens, 'plain', m[7]);
    }
  }
  return tokens;
}

function tokenizeCss(code: string): Token[] {
  const tokens: Token[] = [];
  const re = /(\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(#[0-9a-fA-F]{3,8}\b|-?\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms|deg)?)|(@[\w-]+)|([\w-]+)(?=\s*:)|([{}();:,>+~])|([\s\S])/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(code)) !== null) {
    if (m[1]) push(tokens, 'comment', m[1]);
    else if (m[2]) push(tokens, 'string', m[2]);
    else if (m[3]) push(tokens, 'number', m[3]);
    else if (m[4]) push(tokens, 'keyword', m[4]);
    else if (m[5]) push(tokens, 'attr', m[5]);
    else if (m[6]) push(tokens, 'punct', m[6]);
    else push(tokens, 'plain', m[7]);
  }
  return tokens;
}

function tokenizeGeneric(code: string, family: Exclude<Family, 'markup' | 'css' | 'plain'>): Token[] {
  const tokens: Token[] = [];
  const keywords = new Set(
    (KEYWORDS[family] || []).map((k) => (family === 'sql' ? k.toUpperCase() : k))
  );

  const commentPattern =
    family === 'python' || family === 'shell'
      ? '#[^\\n]*'
      : family === 'sql'
        ? '--[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/'
        : family === 'json'
          ? '\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/'
          : '\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/';
  const stringPattern =
    family === 'python'
      ? '"""[\\s\\S]*?"""|\'\'\'[\\s\\S]*?\'\'\'|"(?:\\\\.|[^"\\\\\\n])*"|\'(?:\\\\.|[^\'\\\\\\n])*\''
      : '`(?:\\\\[\\s\\S]|[^`\\\\])*`|"(?:\\\\.|[^"\\\\\\n])*"|\'(?:\\\\.|[^\'\\\\\\n])*\'';

  const re = new RegExp(
    `(${commentPattern})|(${stringPattern})|(\\b0x[0-9a-fA-F]+\\b|\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b)|([A-Za-z_$\\u0980-\\u09FF][\\w$\\u0980-\\u09FF]*)|([{}()\\[\\];,.])|([+\\-*/%=<>!&|^~?:]+)|([\\s\\S])`,
    'g'
  );

  let m: RegExpExecArray | null;
  while ((m = re.exec(code)) !== null) {
    if (m[1]) {
      push(tokens, 'comment', m[1]);
    } else if (m[2]) {
      // JSON keys are strings followed by ':'
      const after = code.slice(re.lastIndex).match(/^\s*:/);
      push(tokens, family === 'json' && after ? 'attr' : 'string', m[2]);
    } else if (m[3]) {
      push(tokens, 'number', m[3]);
    } else if (m[4]) {
      const word = m[4];
      const cmp = family === 'sql' ? word.toUpperCase() : word;
      const next = code.slice(re.lastIndex).match(/^\s*\(/);
      if (keywords.has(cmp)) push(tokens, 'keyword', word);
      else if (next) push(tokens, 'function', word);
      else if (/^[A-Z][A-Za-z0-9_]*$/.test(word) && word.length > 1 && family !== 'sql') push(tokens, 'type', word);
      else push(tokens, 'plain', word);
    } else if (m[5]) {
      push(tokens, 'punct', m[5]);
    } else if (m[6]) {
      push(tokens, 'op', m[6]);
    } else {
      push(tokens, 'plain', m[7]);
    }
  }
  return tokens;
}

export function highlightCode(code: string, language?: string | null): Token[] {
  const lang = normalizeLanguage(language);
  const family = LANGUAGE_FAMILY[lang];
  // Guard: very large blocks stay plain to keep rendering fast
  if (!family || code.length > 60000) return [{ type: 'plain', text: code }];
  try {
    if (family === 'markup') return tokenizeMarkup(code);
    if (family === 'css') return tokenizeCss(code);
    if (family === 'plain') return [{ type: 'plain', text: code }];
    return tokenizeGeneric(code, family);
  } catch {
    return [{ type: 'plain', text: code }];
  }
}
