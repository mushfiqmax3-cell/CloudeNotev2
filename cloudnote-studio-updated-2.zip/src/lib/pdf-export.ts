import { marked } from 'marked';
import katex from 'katex';
import type { NoteItem } from './types.ts';
import { prepareMarkdownForRender, normalizeUnicodeText } from './text-normalizer.ts';

function sanitizeFilename(title: string): string {
  const cleaned = normalizeUnicodeText(title || 'CloudNote')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '')
    .replace(/\s+/g, '_')
    .slice(0, 80);
  return cleaned || 'CloudNote_Export';
}

/**
 * Converts Markdown, GFM tables, fenced code blocks, blockquotes, and LaTeX math
 * ($$...$$ and $...$) into complete, styled HTML using `marked` and `katex.renderToString`.
 * Never outputs raw unparsed Markdown syntax.
 */
export function convertMarkdownAndMathToHtml(rawMarkdown: string): string {
  if (!rawMarkdown) return '';

  const prepared = prepareMarkdownForRender(rawMarkdown);
  const mathPlaceholders: { token: string; html: string }[] = [];
  let counter = 0;

  // Protect code blocks first so math inside code blocks is not rendered by KaTeX
  const codePlaceholders: { token: string; raw: string }[] = [];
  let codeCounter = 0;

  let working = prepared.replace(/(```[\s\S]*?```|`[^`\n]+`)/g, (match) => {
    const token = `@@CODE_TOKEN_${codeCounter++}@@`;
    codePlaceholders.push({ token, raw: match });
    return token;
  });

  // Render display math $$ ... $$ via KaTeX
  working = working.replace(/\$\$([\s\S]*?)\$\$/g, (_m, formula: string) => {
    const token = `@@MATH_TOKEN_${counter++}@@`;
    try {
      const html = katex.renderToString(formula.trim(), {
        displayMode: true,
        throwOnError: false,
        output: 'htmlAndMathml',
      });
      mathPlaceholders.push({
        token,
        html: `<div class="katex-display-wrapper">${html}</div>`,
      });
    } catch {
      mathPlaceholders.push({
        token,
        html: `<pre class="math-fallback">${formula.trim()}</pre>`,
      });
    }
    return token;
  });

  // Render inline math $ ... $ via KaTeX
  working = working.replace(/\$([^\$\n]+?)\$/g, (_m, formula: string) => {
    const token = `@@MATH_TOKEN_${counter++}@@`;
    try {
      const html = katex.renderToString(formula.trim(), {
        displayMode: false,
        throwOnError: false,
        output: 'htmlAndMathml',
      });
      mathPlaceholders.push({ token, html });
    } catch {
      mathPlaceholders.push({ token, html: `<code>${formula.trim()}</code>` });
    }
    return token;
  });

  // Restore code blocks before running `marked` so `marked` formats fenced/inline code properly
  for (const item of codePlaceholders) {
    working = working.replace(item.token, () => item.raw);
  }

  const parsedHtml = marked.parse(working, {
    gfm: true,
    breaks: true,
    async: false,
  }) as string;

  // Restore rendered KaTeX HTML blocks
  let finalHtml = parsedHtml;
  for (const item of mathPlaceholders) {
    finalHtml = finalHtml.replace(item.token, () => item.html);
  }

  return finalHtml;
}

/**
 * Builds a complete, standalone styled HTML document for a NoteItem
 * (used for both PDF Print and .doc Word export).
 */
export function buildNoteStyledHtmlDocument(note: NoteItem): string {
  const safeTitle = normalizeUnicodeText(note.title || 'শিরোনামহীন নোট');
  const safeCategory = normalizeUnicodeText(note.category || 'সাধারণ');
  const formattedDate = new Date(note.updatedAt || Date.now()).toLocaleDateString('bn-BD', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const sectionsHtml = (note.sections || [])
    .map((sec, idx) => {
      const secTitle = normalizeUnicodeText(sec.title || `অনুচ্ছেদ ${idx + 1}`);
      const renderedBody = convertMarkdownAndMathToHtml(sec.content || '');
      return `
        <section class="note-section">
          <div class="section-header">
            <span class="section-index">${idx + 1}</span>
            <h2 class="section-title">${secTitle}</h2>
          </div>
          <div class="section-content markdown-body">
            ${renderedBody}
          </div>
        </section>
      `;
    })
    .join('\n');

  return `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <title>${safeTitle} — CloudNote Studio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&family=Noto+Sans+Bengali:wght@400;500;600;700&family=Noto+Sans+Math&family=Noto+Sans+Symbols+2&family=Noto+Serif+Bengali:wght@400;600;700&family=Tiro+Bangla:ital@0;1&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css" />
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: 'Noto Sans Bengali', 'Hind Siliguri', 'Noto Sans Math', 'Noto Sans Symbols 2', system-ui, -apple-system, sans-serif;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.75;
      padding: 36px 44px;
      max-width: 900px;
      margin: 0 auto;
    }
    .doc-header {
      border-bottom: 2px solid #e2e8f0;
      padding-bottom: 18px;
      margin-bottom: 28px;
    }
    .doc-title {
      font-size: 26px;
      font-weight: 700;
      color: #0f172a;
      margin: 0 0 8px 0;
    }
    .doc-meta {
      font-size: 13px;
      color: #475569;
    }
    .note-section {
      margin-bottom: 28px;
      padding: 20px 24px;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      background: #ffffff;
      page-break-inside: avoid;
    }
    .section-header {
      display: flex;
      align-items: center;
      gap: 10px;
      border-bottom: 1px solid #f1f5f9;
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .section-index {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 24px;
      height: 24px;
      border-radius: 6px;
      background: #0f172a;
      color: #ffffff;
      font-size: 12px;
      font-weight: 600;
    }
    .section-title {
      font-size: 18px;
      font-weight: 600;
      margin: 0;
      color: #0f172a;
    }
    .markdown-body h1, .markdown-body h2, .markdown-body h3, .markdown-body h4 {
      color: #0f172a;
      font-weight: 600;
      margin-top: 1.2em;
      margin-bottom: 0.5em;
      line-height: 1.4;
    }
    .markdown-body h1 { font-size: 1.4rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 0.3rem; }
    .markdown-body h2 { font-size: 1.22rem; }
    .markdown-body h3 { font-size: 1.08rem; }
    .markdown-body p { margin: 0.65em 0; }
    .markdown-body ul, .markdown-body ol { margin: 0.6em 0; padding-left: 1.5rem; }
    .markdown-body li { margin: 0.25em 0; }
    .markdown-body table {
      width: 100%;
      border-collapse: collapse;
      margin: 1rem 0;
      font-size: 0.94rem;
    }
    .markdown-body th, .markdown-body td {
      border: 1px solid #cbd5e1;
      padding: 8px 12px;
      text-align: left;
      vertical-align: top;
    }
    .markdown-body th {
      background: #f8fafc;
      font-weight: 600;
    }
    .markdown-body pre {
      background: #0f172a;
      color: #f8fafc;
      padding: 14px 16px;
      border-radius: 8px;
      overflow-x: auto;
      font-family: 'JetBrains Mono', monospace;
      font-size: 13px;
      line-height: 1.55;
      white-space: pre-wrap;
    }
    .markdown-body code {
      font-family: 'JetBrains Mono', monospace;
      background: #f1f5f9;
      padding: 2px 5px;
      border-radius: 4px;
      font-size: 0.88em;
    }
    .markdown-body pre code {
      background: transparent;
      padding: 0;
      color: inherit;
    }
    .markdown-body blockquote {
      margin: 0.85rem 0;
      padding: 10px 16px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      color: #334155;
    }
    .katex-display-wrapper {
      margin: 1rem 0;
      overflow-x: auto;
      padding: 6px 0;
    }
    @media print {
      body { padding: 12px; }
      .note-section { break-inside: avoid; }
    }
  </style>
</head>
<body>
  <header class="doc-header">
    <h1 class="doc-title">${safeTitle}</h1>
    <div class="doc-meta">
      <span>ক্যাটাগরি: ${safeCategory}</span>
      ${note.subCategory ? ` · <span>উপ-বিভাগ: ${normalizeUnicodeText(note.subCategory)}</span>` : ''}
      · <span>সর্বশেষ হালনাগাদ: ${formattedDate}</span>
    </div>
  </header>
  <main>
    ${sectionsHtml}
  </main>
</body>
</html>`;
}

function triggerBlobDownload(blob: Blob, filename: string): void {
  if (typeof document === 'undefined') return;
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  setTimeout(() => {
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }, 500);
}

/**
 * Exports a NoteItem to PDF via an embedded print iframe (no window.open popup blocker issues)
 * with full Markdown, table, code block, and KaTeX math formula rendering.
 */
export function exportNoteToPDF(note: NoteItem): void {
  if (typeof document === 'undefined') return;
  const htmlContent = buildNoteStyledHtmlDocument(note);

  const existingIframe = document.getElementById('cloudnote-print-frame');
  if (existingIframe) {
    existingIframe.remove();
  }

  const iframe = document.createElement('iframe');
  iframe.id = 'cloudnote-print-frame';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (doc) {
    doc.open();
    doc.write(htmlContent);
    doc.close();

    setTimeout(() => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
      } catch (err) {
        console.error('Print dialog error:', err);
      }
    }, 450);
  }
}

/**
 * 1-Click Export to Plain Text (.txt) with UTF-8 BOM so Bengali & Unicode symbols open cleanly on all OSes.
 */
export function exportNoteToTXT(note: NoteItem): void {
  const lines: string[] = [
    `${normalizeUnicodeText(note.title || 'শিরোনামহীন নোট')}`,
    `ক্যাটাগরি: ${normalizeUnicodeText(note.category || 'সাধারণ')}`,
    `তারিখ: ${new Date(note.updatedAt || Date.now()).toLocaleString('bn-BD')}`,
    '====================================================================',
    '',
  ];

  (note.sections || []).forEach((sec, idx) => {
    lines.push(`[${idx + 1}] ${normalizeUnicodeText(sec.title || `অনুচ্ছেদ ${idx + 1}`)}`);
    lines.push('--------------------------------------------------------------------');
    lines.push(normalizeUnicodeText(sec.content || ''));
    lines.push('');
  });

  const utf8WithBom = '\uFEFF' + lines.join('\n');
  const blob = new Blob([utf8WithBom], { type: 'text/plain;charset=utf-8' });
  triggerBlobDownload(blob, `${sanitizeFilename(note.title)}.txt`);
}

/**
 * 1-Click Export to Markdown (.md) with normalized Unicode and standard LaTeX delimiters.
 */
export function exportNoteToMarkdown(note: NoteItem): void {
  const lines: string[] = [
    `# ${normalizeUnicodeText(note.title || 'শিরোনামহীন নোট')}`,
    '',
    `> **ক্যাটাগরি:** ${normalizeUnicodeText(note.category || 'সাধারণ')}${
      note.subCategory ? ` | **উপ-বিভাগ:** ${normalizeUnicodeText(note.subCategory)}` : ''
    }`,
    '',
  ];

  (note.sections || []).forEach((sec, idx) => {
    lines.push(`## ${idx + 1}. ${normalizeUnicodeText(sec.title || `অনুচ্ছেদ ${idx + 1}`)}`);
    lines.push('');
    lines.push(prepareMarkdownForRender(sec.content || ''));
    lines.push('');
  });

  const utf8WithBom = '\uFEFF' + lines.join('\n');
  const blob = new Blob([utf8WithBom], { type: 'text/markdown;charset=utf-8' });
  triggerBlobDownload(blob, `${sanitizeFilename(note.title)}.md`);
}

/**
 * 1-Click Export to Microsoft Word (.doc) with complete HTML/CSS styling, tables, code blocks, and math formulas.
 */
export function exportNoteToWord(note: NoteItem): void {
  const htmlContent = buildNoteStyledHtmlDocument(note);
  const wordPayload = '\uFEFF' + htmlContent;
  const blob = new Blob([wordPayload], {
    type: 'application/msword;charset=utf-8',
  });
  triggerBlobDownload(blob, `${sanitizeFilename(note.title)}.doc`);
}
