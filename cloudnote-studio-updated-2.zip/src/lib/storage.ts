import { openDB, type IDBPDatabase } from 'idb';
import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  writeBatch,
  query,
  where,
  onSnapshot,
  type Unsubscribe,
} from 'firebase/firestore';
import {
  auth,
  db,
  isFirebaseConfigured,
  handleFirestoreError,
  OperationType,
} from './firebase';
import type {
  CategoryItem,
  CloudBackupBundle,
  NoteChunkDoc,
  NoteDraft,
  NoteItem,
  NoteVersionSnapshot,
  UserProfile,
} from './types';
import {
  deriveUserIdFromEmail,
  hashAccountPassword,
  verifyAccountPassword,
  normalizeUnicodeText,
} from './text-normalizer';
import {
  MAX_FIRESTORE_INLINE_BYTES,
  CHUNK_TARGET_BYTES,
  FIRESTORE_SNIPPET_MAX_CHARS,
  getUtf8ByteLength,
  assembleFullContent,
  createSearchSnippet,
  splitSectionsIntoChunks,
  reassembleSectionsFromChunks,
  prepareNoteForFirestore,
  hydrateNoteInMemory,
  sanitizeFirestoreId,
} from './storage-chunking';

export {
  MAX_FIRESTORE_INLINE_BYTES,
  CHUNK_TARGET_BYTES,
  FIRESTORE_SNIPPET_MAX_CHARS,
  getUtf8ByteLength,
  assembleFullContent,
  createSearchSnippet,
  splitSectionsIntoChunks,
  reassembleSectionsFromChunks,
  prepareNoteForFirestore,
  hydrateNoteInMemory,
};

const DB_NAME = 'cloudnote-studio-idb';
const DB_VERSION = 3;
const SESSION_STORAGE_KEY = 'cloudnote_active_user_v2';

export interface VaultAccountRecord {
  email: string;
  uid: string;
  displayName: string;
  passwordHash: string;
  createdAt: string;
  updatedAt: string;
}

interface CloudNoteDBSchema {
  notes: {
    key: string;
    value: NoteItem;
  };
  drafts: {
    key: string;
    value: NoteDraft;
  };
  settings: {
    key: string;
    value: { key: string; value: unknown };
  };
  accounts: {
    key: string;
    value: VaultAccountRecord;
  };
  versions: {
    key: string;
    value: NoteVersionSnapshot;
  };
}

let dbPromise: Promise<IDBPDatabase<CloudNoteDBSchema>> | null = null;

function getLocalDB(): Promise<IDBPDatabase<CloudNoteDBSchema>> {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('IndexedDB is only available in browser runtime'));
  }
  if (!dbPromise) {
    dbPromise = openDB<CloudNoteDBSchema>(DB_NAME, DB_VERSION, {
      upgrade(database) {
        if (!database.objectStoreNames.contains('notes')) {
          database.createObjectStore('notes', { keyPath: 'id' });
        }
        if (!database.objectStoreNames.contains('drafts')) {
          database.createObjectStore('drafts', { keyPath: 'noteId' });
        }
        if (!database.objectStoreNames.contains('settings')) {
          database.createObjectStore('settings', { keyPath: 'key' });
        }
        if (!database.objectStoreNames.contains('accounts')) {
          database.createObjectStore('accounts', { keyPath: 'email' });
        }
        if (!database.objectStoreNames.contains('versions')) {
          database.createObjectStore('versions', { keyPath: 'versionId' });
        }
      },
    });
  }
  return dbPromise;
}

function isFirestoreAuthActiveForUser(userId?: string | null): boolean {
  return Boolean(
    isFirebaseConfigured &&
      db &&
      auth?.currentUser &&
      userId &&
      auth.currentUser.uid === userId
  );
}

function checkAndRethrowPermissionError(
  error: unknown,
  op: OperationType,
  path: string
): void {
  if (
    error instanceof Error &&
    (error.message.includes('Missing or insufficient permissions') ||
      error.message.includes('permission-denied'))
  ) {
    handleFirestoreError(error, op, path);
  }
}

/**
 * Rich default starter notes in Bengali demonstrating Universal Unicode, KaTeX Math,
 * GFM Tables, Code Blocks, and multi-section Table of Contents.
 */
const RAW_STARTER_NOTES: Array<Partial<NoteItem> & { id: string }> = [
  {
    id: 'seed-note-quantum-math',
    title: 'কোয়ান্টাম বলবিদ্যা, আপেক্ষিকতা ও গাণিতিক ইউনিকোড গাইড',
    category: 'বিজ্ঞান ও গণিত',
    subCategory: 'পদার্থবিজ্ঞান',
    isFavorite: true,
    isDeleted: false,
    tags: ['কোয়ান্টাম', 'গণিত', 'LaTeX', 'ইউনিকোড'],
    fontFamily: 'sans',
    createdAt: '2026-10-15T10:30:00.000Z',
    updatedAt: '2026-10-17T08:00:00.000Z',
    sections: [
      {
        id: 'sec-qm-1',
        title: '১. গাণিতিক প্রতীক ও বাংলা যুক্তবর্ণ পরীক্ষা',
        content: [
          '# ইউনিভার্সাল ইউনিকোড ও বাংলা যুক্তবর্ণ',
          'এই নোটবুকটিতে বাংলা জটিল যুক্তবর্ণ যেমন **ক্ষ, জ্ঞ, হ্ম, র‍্য (র+ZWJ+য), ত্র্য, ক্ত্র, ষ্ণ, ন্ত্র** এবং গাণিতিক আলফানিউমেরিক প্রতীক **𝕏, 𝒜, 𝓜, 𝛼, 𝛽, 𝛾, ∑, ∫, ∮, √, ∞, ≠, ≤, ≥, ≈, ∂, ∇, ∈, ℝ, ℂ** নিখুঁতভাবে রেন্ডার হয়।',
          '',
          '## আইনস্টাইনের ভর-শক্তি সমীকরণ',
          'আপেক্ষিকতা তত্ত্ব অনুসারে কোনো কণার মোট শক্তি $E = \\gamma mc^2$, যেখানে লরেন্টজ গুণনীয়ক $\\gamma = \\frac{1}{\\sqrt{1 - v^2/c^2}}$। স্থির অবস্থায় সমীকরণটি:',
          '$$',
          'E^2 = (pc)^2 + (m_0 c^2)^2',
          '$$',
          '',
          '> **বিশেষ দ্রষ্টব্য:** চ্যাটজিপিটি, জেমিনি, ক্লড বা ডিপসিক থেকে কপি করা `\\[ ... \\]` এবং `\\( ... \\)` ল্যাটেক্স সূত্র পেস্ট করার সাথে সাথেই স্বয়ংক্রিয়ভাবে সুন্দর গাণিতিক সমীকরণে রূপান্তরিত হয়।',
        ].join('\n'),
      },
      {
        id: 'sec-qm-2',
        title: '২. শ্রোডিঙ্গারের তরঙ্গ সমীকরণ ও তুলনামূলক ছক',
        content: [
          '# শ্রোডিঙ্গারের সময়-নির্ভর সমীকরণ',
          'কোয়ান্টাম সিস্টেমের তরঙ্গ ফাংশন $\\Psi(\\mathbf{r}, t)$ নিচের ব্যবকলনীয় সমীকরণটি মেনে চলে:',
          '$$',
          'i\\hbar \\frac{\\partial}{\\partial t}\\Psi(\\mathbf{r}, t) = \\left( -\\frac{\\hbar^2}{2m}\\nabla^2 + V(\\mathbf{r}, t) \\right) \\Psi(\\mathbf{r}, t)',
          '$$',
          '',
          '## চিরায়ত ও কোয়ান্টাম বলবিদ্যার তুলনা',
          '| বৈশিষ্ট্য | চিরায়ত বলবিদ্যা (Classical) | কোয়ান্টাম বলবিদ্যা (Quantum) | গাণিতিক রূপ |',
          '| --- | --- | --- | --- |',
          '| অবস্থা নির্ণয় | নির্দিষ্ট অবস্থান ও ভরবেগ $(x, p)$ | তরঙ্গ ফাংশন $\\Psi(x,t)$ | $\\int_{-\\infty}^{\\infty} |\\Psi|^2 dx = 1$ |',
          '| অনিশ্চয়তা | শূন্য (তাত্ত্বিকভাবে) | হাইজেনবার্গের অনিশ্চয়তা নীতি | $\\Delta x \\cdot \\Delta p_x \\ge \\frac{\\hbar}{2}$ |',
          '| শক্তির মান | অবিচ্ছিন্ন (Continuous) | কোয়ান্টায়িত (Quantized) | $E_n = \\hbar \\omega (n + \\frac{1}{2})$ |',
          '',
          '### পাইথনে সংখ্যাসূচক সমাকলন উদাহরণ',
          '```python',
          'import numpy as np',
          '',
          'def gaussian_wave_packet(x: np.ndarray, x0: float, sigma: float, k0: float) -> np.ndarray:',
          '    norm = (1.0 / (2.0 * np.pi * sigma**2)) ** 0.25',
          '    return norm * np.exp(-((x - x0) ** 2) / (4 * sigma**2)) * np.exp(1j * k0 * x)',
          '```',
        ].join('\n'),
      },
    ],
    content: '',
  },
  {
    id: 'seed-note-bengali-lit',
    title: 'বাংলা সাহিত্য, গবেষণা কাঠামো ও স্টুডিও নির্দেশিকা',
    category: 'সাহিত্য ও গবেষণা',
    subCategory: 'প্রবন্ধ',
    isFavorite: true,
    isDeleted: false,
    tags: ['সাহিত্য', 'প্রবন্ধ', 'গবেষণা'],
    fontFamily: 'serif',
    createdAt: '2026-10-14T14:20:00.000Z',
    updatedAt: '2026-10-16T19:45:00.000Z',
    sections: [
      {
        id: 'sec-lit-1',
        title: '১. আধুনিক বাংলা সাহিত্যের গতিপ্রকৃতি',
        content: [
          '# বাংলা সাহিত্যের আধুনিক ধারা',
          'বাংলা সাহিত্যের আধুনিক পর্বে সাধু রীতি থেকে চলিত রীতিতে উত্তরণ কেবল ব্যাকরণগত পরিবর্তন ছিল না; এটি ছিল স্বাধীন চিন্তা ও মননশীলতার এক উজ্জ্বল দৃষ্টান্ত।',
          '',
          '## প্রধান আলোচ্য বিষয়',
          '- মেঘনাদবধ কাব্য ও সমকালীন নাট্যসাহিত্যের প্রভাব',
          '- গীতাঞ্জলি পর্বের আধ্যাত্মিক ভাবধারা ও আধুনিক কবিতার উন্মেষ',
          '- ছোটগল্পের সমাজচেতনা ও বাস্তববাদী দৃষ্টিভঙ্গি',
        ].join('\n'),
      },
    ],
    content: '',
  },
  {
    id: 'seed-note-tasks-checklist',
    title: 'সাপ্তাহিক প্রজেক্ট পরিকল্পনা ও করণীয় কাজ',
    category: 'প্রজেক্ট ও কাজ',
    subCategory: 'চেকলিস্ট',
    isFavorite: false,
    isPinned: true,
    color: '#6366f1',
    isDeleted: false,
    tags: ['চেকলিস্ট', 'পরিকল্পনা', 'কাজ'],
    fontFamily: 'sans',
    createdAt: '2026-10-15T09:15:00.000Z',
    updatedAt: '2026-10-17T11:00:00.000Z',
    sections: [
      {
        id: 'sec-tasks-1',
        title: '১. অগ্রাধিকারমূলক করণীয় চেকলিস্ট',
        content: [
          '# করণীয় চেকলিস্ট',
          '- [x] প্রজেক্ট রূপরেখা ও প্রয়োজনীয় রিসোর্স পর্যালোচনা',
          '- [x] ক্লায়েন্ট ফিডব্যাক ও ডিজাইনের মানোন্নয়ন',
          '- [ ] এআই সামারি ও অটো-টাস্ক চেকলিস্ট যাচাই',
          '- [ ] ফাইনাল রিপোর্ট প্রস্তুত ও ক্লাউড সিঙ্ক নিশ্চিতকরণ',
          '',
          '## পরবর্তী পদক্ষেপ',
          '- দলের সদস্যদের সাথে মিটিং ও কাজের অগ্রগতি শেয়ার',
          '- সাপ্তাহিক রিভিউ সম্পন্ন করা',
        ].join('\n'),
      },
    ],
    content: '',
  },
];

export const DEFAULT_STARTER_NOTES: NoteItem[] = RAW_STARTER_NOTES.map((note) =>
  hydrateNoteInMemory(note)
);

// ============================================================================
// Account Vault & Session Persistence (Supports Firebase Auth + Local Cloud Vault)
// ============================================================================

export function loadPersistedSessionUser(): UserProfile | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as UserProfile;
    if (parsed && parsed.uid) {
      return parsed;
    }
  } catch {
    // Ignore
  }
  return null;
}

export function savePersistedSessionUser(user: UserProfile | null): void {
  if (typeof window === 'undefined') return;
  try {
    if (!user) {
      window.localStorage.removeItem(SESSION_STORAGE_KEY);
    } else {
      window.localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
    }
  } catch {
    // Ignore
  }
}

export async function registerAccountInVault(
  email: string,
  password: string,
  displayName?: string
): Promise<UserProfile> {
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes('@')) {
    throw new Error('অনুগ্রহ করে একটি বৈধ ইমেইল ঠিকানা প্রদান করুন।');
  }
  if (!password || password.length < 6) {
    throw new Error('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
  }

  const uid = deriveUserIdFromEmail(cleanEmail);
  const name =
    normalizeUnicodeText(displayName || '').trim() ||
    cleanEmail.split('@')[0] ||
    'ক্লাউডনোট ব্যবহারকারী';
  const now = new Date().toISOString();
  const passwordHash = hashAccountPassword(cleanEmail, password);

  const idb = await getLocalDB();
  const existing = await idb.get('accounts', cleanEmail);
  if (existing) {
    throw new Error('এই ইমেইল ঠিকানা দিয়ে ইতোমধ্যে একটি অ্যাকাউন্ট খোলা হয়েছে। অনুগ্রহ করে লগইন করুন।');
  }

  const record: VaultAccountRecord = {
    email: cleanEmail,
    uid,
    displayName: name,
    passwordHash,
    createdAt: now,
    updatedAt: now,
  };
  await idb.put('accounts', record);

  const profile: UserProfile = {
    uid,
    email: cleanEmail,
    displayName: name,
    isLocalMode: false,
    authProvider: 'cloud-vault',
    lastSyncedAt: now,
  };
  savePersistedSessionUser(profile);
  return profile;
}

export async function authenticateAccountInVault(
  email: string,
  password: string
): Promise<UserProfile> {
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes('@')) {
    throw new Error('অনুগ্রহ করে একটি বৈধ ইমেইল ঠিকানা লিখুন।');
  }
  if (!password) {
    throw new Error('অনুগ্রহ করে আপনার পাসওয়ার্ড লিখুন।');
  }

  const idb = await getLocalDB();
  const existing = await idb.get('accounts', cleanEmail);

  if (!existing) {
    throw new Error('এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি। প্রথমে "নতুন অ্যাকাউন্ট (Sign Up)" ট্যাব থেকে নিবন্ধন করুন।');
  }

  if (!verifyAccountPassword(cleanEmail, password, existing.passwordHash)) {
    throw new Error('পাসওয়ার্ডটি সঠিক নয়। অনুগ্রহ করে আবার চেষ্টা করুন অথবা পাসওয়ার্ড রিসেট করুন।');
  }

  const now = new Date().toISOString();
  const profile: UserProfile = {
    uid: existing.uid,
    email: existing.email,
    displayName: existing.displayName,
    isLocalMode: false,
    authProvider: 'cloud-vault',
    lastSyncedAt: now,
  };
  savePersistedSessionUser(profile);
  return profile;
}

export async function resetPasswordInVault(
  email: string,
  newPassword: string
): Promise<UserProfile> {
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes('@')) {
    throw new Error('অনুগ্রহ করে একটি বৈধ ইমেইল ঠিকানা লিখুন।');
  }
  if (!newPassword || newPassword.length < 6) {
    throw new Error('নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
  }

  const idb = await getLocalDB();
  const existing = await idb.get('accounts', cleanEmail);
  const now = new Date().toISOString();
  const uid = existing?.uid || deriveUserIdFromEmail(cleanEmail);
  const displayName = existing?.displayName || cleanEmail.split('@')[0] || 'ব্যবহারকারী';

  const updated: VaultAccountRecord = {
    email: cleanEmail,
    uid,
    displayName,
    passwordHash: hashAccountPassword(cleanEmail, newPassword),
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  };
  await idb.put('accounts', updated);

  const profile: UserProfile = {
    uid,
    email: cleanEmail,
    displayName,
    isLocalMode: false,
    authProvider: 'cloud-vault',
    lastSyncedAt: now,
  };
  savePersistedSessionUser(profile);
  return profile;
}

/**
 * Updates the display name stored for a local-vault account (no-op if the account is not in the vault).
 */
export async function updateVaultAccountDisplayName(
  email: string | null | undefined,
  displayName: string
): Promise<void> {
  const cleanEmail = (email || '').trim().toLowerCase();
  if (!cleanEmail) return;
  try {
    const idb = await getLocalDB();
    const existing = await idb.get('accounts', cleanEmail);
    if (!existing) return;
    await idb.put('accounts', {
      ...existing,
      displayName: normalizeUnicodeText(displayName).trim(),
      updatedAt: new Date().toISOString(),
    });
  } catch {
    // Vault update is best-effort
  }
}

/**
 * Syncs the authenticated user's profile document at `/users/{userId}` in Firestore.
 */
export async function upsertUserProfileToFirestore(user: UserProfile): Promise<void> {
  if (!isFirestoreAuthActiveForUser(user.uid) || !db) return;
  const safeUid = sanitizeFirestoreId(user.uid, 'user');
  const now = new Date().toISOString();
  const path = `users/${safeUid}`;
  const payload = {
    uid: safeUid,
    email: (user.email || 'user@cloudnote.app').slice(0, 254),
    displayName: (user.displayName || 'ক্লাউডনোট ব্যবহারকারী').slice(0, 120),
    lastSyncedAt: (user.lastSyncedAt || now).slice(0, 64),
    updatedAt: now.slice(0, 64),
  };

  try {
    const userRef = doc(db, 'users', safeUid);
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      await setDoc(userRef, payload);
    } else {
      await setDoc(userRef, payload, { merge: true });
    }
  } catch (err) {
    checkAndRethrowPermissionError(err, OperationType.WRITE, path);
    console.warn('Profile sync warning:', err);
  }
}

/**
 * Migrates any legacy localStorage notes to IndexedDB and clears the old localStorage key.
 */
async function migrateLegacyLocalStorageNotes(): Promise<NoteItem[]> {
  if (typeof window === 'undefined') return [];
  const legacyKeys = ['cloudnote_notes', 'cloudnote-notes', 'notes'];
  const migrated: NoteItem[] = [];

  for (const key of legacyKeys) {
    try {
      const raw = window.localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        for (const item of parsed) {
          if (item && typeof item === 'object' && item.id) {
            migrated.push(hydrateNoteInMemory(item));
          }
        }
      }
      window.localStorage.removeItem(key);
    } catch {
      // Ignore malformed legacy localStorage data
    }
  }

  return migrated;
}

/**
 * Loads all notes from IndexedDB for the active user (including seeding starter notes on first visit).
 */
export async function loadAllNotesFromIndexedDB(userId?: string | null): Promise<NoteItem[]> {
  try {
    const idb = await getLocalDB();
    let existing = await idb.getAll('notes');

    if (existing.length === 0) {
      const migrated = await migrateLegacyLocalStorageNotes();
      const initialNotes = (migrated.length > 0 ? migrated : DEFAULT_STARTER_NOTES).map((n) =>
        hydrateNoteInMemory({
          ...n,
          userId: userId || 'local-user',
        })
      );
      const tx = idb.transaction('notes', 'readwrite');
      for (const note of initialNotes) {
        await tx.store.put(note);
      }
      await tx.done;
      existing = initialNotes;
    }

    // Filter notes so user sees their own notes plus any shared starter/local notes
    const relevant = existing.filter((n) => {
      if (!userId || userId === 'local-studio-user') return true;
      return (
        !n.userId ||
        n.userId === userId ||
        n.userId === 'local-user' ||
        n.userId === 'local-studio-user' ||
        n.id.startsWith('seed-note-')
      );
    });

    return relevant
      .map((n) => hydrateNoteInMemory({ ...n, userId: userId || n.userId || 'local-user' }))
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  } catch (err) {
    console.warn('IndexedDB fallback to in-memory starter notes:', err);
    return DEFAULT_STARTER_NOTES;
  }
}

/**
 * Saves a version snapshot of a note (up to 15 per note) for data recovery.
 */
export async function saveNoteVersionSnapshot(note: NoteItem): Promise<void> {
  try {
    const idb = await getLocalDB();
    const allVersions = await idb.getAll('versions');
    const noteVersions = allVersions
      .filter((v) => v.noteId === note.id)
      .sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime());

    const now = new Date().toISOString();
    const snapshot: NoteVersionSnapshot = {
      versionId: `${note.id}_v_${Date.now()}`,
      noteId: note.id,
      title: note.title,
      category: note.category,
      sections: note.sections,
      wordCount: note.wordCount || 0,
      byteSize: note.byteSize || 0,
      savedAt: now,
    };

    const tx = idb.transaction('versions', 'readwrite');
    await tx.store.put(snapshot);

    // Keep most recent 14 previous versions + this new one = 15 max
    if (noteVersions.length >= 15) {
      for (const old of noteVersions.slice(14)) {
        await tx.store.delete(old.versionId);
      }
    }
    await tx.done;
  } catch (err) {
    console.warn('Failed to save version snapshot:', err);
  }
}

export async function getNoteVersionHistory(noteId?: string): Promise<NoteVersionSnapshot[]> {
  try {
    const idb = await getLocalDB();
    const all = await idb.getAll('versions');
    const filtered = noteId ? all.filter((v) => v.noteId === noteId) : all;
    return filtered.sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime());
  } catch {
    return [];
  }
}

/**
 * Saves a single note to IndexedDB with full sections and hydrated content.
 */
export async function saveNoteToIndexedDB(note: NoteItem): Promise<NoteItem> {
  const { hydratedNote } = prepareNoteForFirestore(note);
  try {
    const idb = await getLocalDB();
    await idb.put('notes', hydratedNote);
  } catch (err) {
    console.error('Failed to save note to IndexedDB:', err);
  }
  return hydratedNote;
}

/**
 * Saves multiple notes to IndexedDB in a single transaction.
 */
export async function saveBulkNotesToIndexedDB(notes: NoteItem[]): Promise<void> {
  try {
    const idb = await getLocalDB();
    const tx = idb.transaction('notes', 'readwrite');
    for (const note of notes) {
      const { hydratedNote } = prepareNoteForFirestore(note);
      await tx.store.put(hydratedNote);
    }
    await tx.done;
  } catch (err) {
    console.error('Failed to bulk save notes to IndexedDB:', err);
  }
}

/**
 * Permanently removes a note from IndexedDB (and its draft if any).
 */
export async function deleteNoteFromIndexedDB(noteId: string): Promise<void> {
  try {
    const idb = await getLocalDB();
    await idb.delete('notes', noteId);
    await idb.delete('drafts', noteId);
  } catch (err) {
    console.error('Failed to delete note from IndexedDB:', err);
  }
}

/**
 * Pushes a single prepared note to Firestore (including automatic chunking >600KB).
 */
async function pushNoteToFirestore(
  note: NoteItem,
  userId: string
): Promise<NoteItem> {
  const safeUserId = sanitizeFirestoreId(userId, 'user');
  const { firestoreDoc, chunks, hydratedNote } = prepareNoteForFirestore({
    ...note,
    userId: safeUserId,
  });

  if (!isFirestoreAuthActiveForUser(safeUserId) || !db) {
    return hydratedNote;
  }

  const notePath = `users/${safeUserId}/notes/${hydratedNote.id}`;
  const chunksPath = `${notePath}/note_chunks`;
  const noteRef = doc(db, 'users', safeUserId, 'notes', hydratedNote.id);
  const chunksColRef = collection(db, 'users', safeUserId, 'notes', hydratedNote.id, 'note_chunks');

  try {
    // Check if note already exists so we preserve immutable `createdAt`
    const existingSnap = await getDoc(noteRef);
    const finalDoc = existingSnap.exists()
      ? {
          ...firestoreDoc,
          createdAt: existingSnap.data().createdAt || firestoreDoc.createdAt,
        }
      : firestoreDoc;

    // 1. Write main NoteDoc first (ensures parent exists for note_chunks Master Gate rule)
    await setDoc(noteRef, finalDoc);

    // 2. Clean up any previous chunks using owner-scoped query
    const existingChunksQuery = query(chunksColRef, where('userId', '==', safeUserId));
    const existingChunksSnap = await getDocs(existingChunksQuery);
    if (!existingChunksSnap.empty) {
      const deleteBatch = writeBatch(db);
      existingChunksSnap.docs.forEach((d) => deleteBatch.delete(d.ref));
      await deleteBatch.commit();
    }

    // 3. Write new chunks if note exceeds inline threshold
    if (chunks.length > 0) {
      const BATCH_LIMIT = 20;
      for (let i = 0; i < chunks.length; i += BATCH_LIMIT) {
        const batch = writeBatch(db);
        const slice = chunks.slice(i, i + BATCH_LIMIT);
        for (const chunkDoc of slice) {
          const chunkRef = doc(chunksColRef, chunkDoc.id);
          batch.set(chunkRef, chunkDoc);
        }
        await batch.commit();
      }
    }
  } catch (err) {
    checkAndRethrowPermissionError(err, OperationType.WRITE, chunks.length > 0 ? chunksPath : notePath);
    console.warn('Firestore note sync warning (saved safely in IndexedDB):', err);
  }

  return hydratedNote;
}

/**
 * Saves a note to IndexedDB, records a recovery version snapshot, and syncs to Firestore with chunking.
 */
export async function saveNoteWithChunking(
  note: NoteItem,
  userId?: string | null
): Promise<NoteItem> {
  const effectiveUserId = sanitizeFirestoreId(userId || note.userId || 'local-user', 'user');
  const { hydratedNote } = prepareNoteForFirestore({
    ...note,
    userId: effectiveUserId,
    updatedAt: new Date().toISOString(),
  });

  // 1. Always save full hydrated note in IndexedDB (no 5MB limit)
  await saveNoteToIndexedDB(hydratedNote);
  // 2. Save automatic version history snapshot for recovery
  await saveNoteVersionSnapshot(hydratedNote);
  // 3. Clear auto-draft upon explicit save
  await clearAutoDraft(hydratedNote.id);

  // 4. Sync to Firestore if user is authenticated with Firebase
  if (isFirestoreAuthActiveForUser(effectiveUserId)) {
    await pushNoteToFirestore(hydratedNote, effectiveUserId);
  }

  return hydratedNote;
}

/**
 * Loads all notes for a user from Firestore (reassembling any chunked notes from `note_chunks`),
 * merges them with IndexedDB, and pushes any unsynced local notes up to Firestore so cross-device access is complete.
 */
export async function loadNotesWithChunkReassembly(userId?: string | null): Promise<NoteItem[]> {
  const localNotes = await loadAllNotesFromIndexedDB(userId);

  if (!userId || !isFirestoreAuthActiveForUser(userId) || !db) {
    return localNotes;
  }

  const safeUserId = sanitizeFirestoreId(userId, 'user');
  const notesPath = `users/${safeUserId}/notes`;

  try {
    const notesColRef = collection(db, 'users', safeUserId, 'notes');
    const q = query(notesColRef, where('userId', '==', safeUserId));
    const snap = await getDocs(q);

    const cloudNotes: NoteItem[] = [];

    for (const docSnap of snap.docs) {
      const rawData = docSnap.data() as Partial<NoteItem> & { id: string };
      const noteId = rawData.id || docSnap.id;
      let chunks: NoteChunkDoc[] = [];

      if (rawData.isChunked) {
        const chunksColRef = collection(db, 'users', safeUserId, 'notes', noteId, 'note_chunks');
        const chunksQuery = query(chunksColRef, where('userId', '==', safeUserId));
        const chunksSnap = await getDocs(chunksQuery);
        chunks = chunksSnap.docs.map((c) => c.data() as NoteChunkDoc);
      }

      const hydrated = hydrateNoteInMemory({ ...rawData, id: noteId }, chunks);
      cloudNotes.push(hydrated);
    }

    const cloudMap = new Map<string, NoteItem>();
    for (const cn of cloudNotes) {
      cloudMap.set(cn.id, cn);
    }

    const mergedMap = new Map<string, NoteItem>();
    const notesToPushToCloud: NoteItem[] = [];

    for (const ln of localNotes) {
      const withOwner = { ...ln, userId: safeUserId };
      mergedMap.set(ln.id, withOwner);
      const cn = cloudMap.get(ln.id);
      if (!cn || new Date(ln.updatedAt).getTime() > new Date(cn.updatedAt).getTime()) {
        notesToPushToCloud.push(withOwner);
      }
    }

    for (const cn of cloudNotes) {
      const existing = mergedMap.get(cn.id);
      if (
        !existing ||
        new Date(cn.updatedAt).getTime() >= new Date(existing.updatedAt).getTime()
      ) {
        mergedMap.set(cn.id, cn);
      }
    }

    const mergedList = Array.from(mergedMap.values()).sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );

    await saveBulkNotesToIndexedDB(mergedList);

    // Push any local notes that are not yet in Firestore (or newer locally)
    for (const noteToPush of notesToPushToCloud) {
      await pushNoteToFirestore(noteToPush, safeUserId);
    }

    return mergedList;
  } catch (err) {
    checkAndRethrowPermissionError(err, OperationType.LIST, notesPath);
    console.warn('Cloud load fell back to IndexedDB cache:', err);
    return localNotes;
  }
}

/**
 * Performs an explicit full bidirectional Cloud Sync and updates the user's `lastSyncedAt` metadata.
 */
export async function syncAllNotesWithCloud(user: UserProfile): Promise<{
  notes: NoteItem[];
  syncedAt: string;
}> {
  const syncedAt = new Date().toISOString();
  if (isFirestoreAuthActiveForUser(user.uid)) {
    await upsertUserProfileToFirestore({ ...user, lastSyncedAt: syncedAt });
  }
  const notes = await loadNotesWithChunkReassembly(user.uid);
  return { notes, syncedAt };
}

/**
 * Sets up a real-time Firestore `onSnapshot` listener for cross-device live updates when authenticated with Firebase.
 */
export function subscribeToUserNotes(
  userId: string,
  onNotesUpdated: (notes: NoteItem[]) => void
): Unsubscribe | null {
  if (!isFirestoreAuthActiveForUser(userId) || !db) return null;
  const safeUserId = sanitizeFirestoreId(userId, 'user');
  const notesPath = `users/${safeUserId}/notes`;
  const notesColRef = collection(db, 'users', safeUserId, 'notes');
  const q = query(notesColRef, where('userId', '==', safeUserId));

  return onSnapshot(
    q,
    async (snapshot) => {
      try {
        const localNotes = await loadAllNotesFromIndexedDB(safeUserId);
        const mergedMap = new Map<string, NoteItem>();
        for (const ln of localNotes) {
          mergedMap.set(ln.id, ln);
        }

        for (const docSnap of snapshot.docs) {
          const rawData = docSnap.data() as Partial<NoteItem> & { id: string };
          const noteId = rawData.id || docSnap.id;
          let chunks: NoteChunkDoc[] = [];

          if (rawData.isChunked && db) {
            const chunksColRef = collection(
              db,
              'users',
              safeUserId,
              'notes',
              noteId,
              'note_chunks'
            );
            const chunksSnap = await getDocs(
              query(chunksColRef, where('userId', '==', safeUserId))
            );
            chunks = chunksSnap.docs.map((c) => c.data() as NoteChunkDoc);
          }

          const hydrated = hydrateNoteInMemory({ ...rawData, id: noteId }, chunks);
          const existing = mergedMap.get(hydrated.id);
          if (
            !existing ||
            new Date(hydrated.updatedAt).getTime() >= new Date(existing.updatedAt).getTime()
          ) {
            mergedMap.set(hydrated.id, hydrated);
          }
        }

        const sorted = Array.from(mergedMap.values()).sort(
          (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        );
        await saveBulkNotesToIndexedDB(sorted);
        onNotesUpdated(sorted);
      } catch (err) {
        console.warn('Realtime snapshot merge error:', err);
      }
    },
    (error) => {
      checkAndRethrowPermissionError(error, OperationType.LIST, notesPath);
    }
  );
}

/**
 * Permanently deletes a note and all of its `note_chunks` from both IndexedDB and Firestore.
 */
export async function permanentlyDeleteNote(
  noteId: string,
  userId?: string | null
): Promise<void> {
  await deleteNoteFromIndexedDB(noteId);

  if (userId && isFirestoreAuthActiveForUser(userId) && db) {
    const safeUserId = sanitizeFirestoreId(userId, 'user');
    const safeNoteId = sanitizeFirestoreId(noteId, 'note');
    const notePath = `users/${safeUserId}/notes/${safeNoteId}`;
    try {
      const chunksColRef = collection(db, 'users', safeUserId, 'notes', safeNoteId, 'note_chunks');
      const existingChunks = await getDocs(
        query(chunksColRef, where('userId', '==', safeUserId))
      );
      if (!existingChunks.empty) {
        const batch = writeBatch(db);
        existingChunks.docs.forEach((d) => batch.delete(d.ref));
        await batch.commit();
      }
      await deleteDoc(doc(db, 'users', safeUserId, 'notes', safeNoteId));
    } catch (err) {
      checkAndRethrowPermissionError(err, OperationType.DELETE, notePath);
      console.error('Failed to delete note from Firestore:', err);
    }
  }
}

/**
 * Exports all notes into a portable CloudBackupBundle JSON structure for backup & cross-device recovery.
 */
export function createCloudBackupBundle(
  notes: NoteItem[],
  user: UserProfile
): CloudBackupBundle {
  return {
    version: '2.0.0',
    exportedAt: new Date().toISOString(),
    accountEmail: user.email,
    accountName: user.displayName,
    totalNotes: notes.length,
    notes: notes.map((n) => hydrateNoteInMemory({ ...n, userId: user.uid })),
  };
}

/**
 * Restores and merges notes from a CloudBackupBundle JSON string, saving to IndexedDB and syncing to Firestore.
 */
export async function restoreFromCloudBackupBundle(
  rawJson: string,
  userId: string
): Promise<NoteItem[]> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(rawJson);
  } catch {
    throw new Error('ব্যাকআপ ফাইলটি সঠিক JSON ফরম্যাটে নেই।');
  }

  let incomingNotes: Array<Partial<NoteItem> & { id: string }> = [];
  if (
    parsed &&
    typeof parsed === 'object' &&
    'notes' in parsed &&
    Array.isArray((parsed as CloudBackupBundle).notes)
  ) {
    incomingNotes = (parsed as CloudBackupBundle).notes;
  } else if (Array.isArray(parsed)) {
    incomingNotes = parsed as Array<Partial<NoteItem> & { id: string }>;
  } else {
    throw new Error('ব্যাকআপ ফাইলে কোনো নোটের তথ্য পাওয়া যায়নি।');
  }

  const existing = await loadAllNotesFromIndexedDB(userId);
  const mergedMap = new Map<string, NoteItem>();
  for (const n of existing) {
    mergedMap.set(n.id, n);
  }

  for (const raw of incomingNotes) {
    if (!raw || typeof raw !== 'object') continue;
    const id = sanitizeFirestoreId(raw.id || `restored_${Date.now()}`, 'note');
    const hydrated = hydrateNoteInMemory({
      ...raw,
      id,
      userId,
      updatedAt: raw.updatedAt || new Date().toISOString(),
    });
    mergedMap.set(hydrated.id, hydrated);
    await saveNoteWithChunking(hydrated, userId);
  }

  return Array.from(mergedMap.values()).sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

/**
 * Auto-Draft Recovery API in IndexedDB (protects unsaved editor work against refresh/battery loss).
 */
export async function saveAutoDraft(draft: NoteDraft): Promise<void> {
  try {
    const idb = await getLocalDB();
    await idb.put('drafts', {
      ...draft,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.error('Failed to save auto-draft to IndexedDB:', err);
  }
}

export async function getAutoDraft(noteId: string): Promise<NoteDraft | undefined> {
  try {
    const idb = await getLocalDB();
    return await idb.get('drafts', noteId);
  } catch {
    return undefined;
  }
}

export async function getAllAutoDrafts(): Promise<NoteDraft[]> {
  try {
    const idb = await getLocalDB();
    return await idb.getAll('drafts');
  } catch {
    return [];
  }
}

export async function clearAutoDraft(noteId: string): Promise<void> {
  try {
    const idb = await getLocalDB();
    await idb.delete('drafts', noteId);
  } catch {
    // Ignore
  }
}

export const DEFAULT_CATEGORY_ITEMS: CategoryItem[] = [
  { id: 'cat-general', name: 'সাধারণ', color: '#6366f1' },
  { id: 'cat-science', name: 'বিজ্ঞান ও গণিত', color: '#0ea5e9' },
  { id: 'cat-literature', name: 'সাহিত্য ও গবেষণা', color: '#8b5cf6' },
  { id: 'cat-tech', name: 'প্রযুক্তি ও কোডিং', color: '#10b981' },
  { id: 'cat-diary', name: 'ব্যক্তিগত ডায়েরি', color: '#f59e0b' },
];

export async function loadUserCategories(userId: string): Promise<CategoryItem[]> {
  const storageKey = `cloudnote_categories_${userId || 'default'}`;
  try {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    }
    const idb = await getLocalDB();
    const idbSetting = await idb.get('settings', storageKey);
    if (idbSetting && Array.isArray(idbSetting.value) && idbSetting.value.length > 0) {
      return idbSetting.value as CategoryItem[];
    }
  } catch (err) {
    console.warn('Could not read user categories from storage:', err);
  }
  return DEFAULT_CATEGORY_ITEMS;
}

export async function saveUserCategories(
  userId: string,
  categories: CategoryItem[]
): Promise<void> {
  const storageKey = `cloudnote_categories_${userId || 'default'}`;
  try {
    if (typeof window !== 'undefined') {
      localStorage.setItem(storageKey, JSON.stringify(categories));
    }
    const idb = await getLocalDB();
    await idb.put('settings', {
      key: storageKey,
      value: categories,
    });
  } catch (err) {
    console.error('Failed to save user categories:', err);
  }
}
