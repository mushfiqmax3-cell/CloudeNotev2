import type { NoteSection, TocEntry } from './types.ts';

/**
 * Strips broken zero-width artifacts (BOM \uFEFF, ZWSP \u200B, Word Joiner \u2060,
 * soft hyphen \u00AD, object replacement \uFFFC) while strictly preserving
 * valid Bengali ZWNJ (\u200C) and ZWJ (\u200D) required for র‍্য (র+ZWJ+য) and অর্ধ-অক্ষর.
 */
const BROKEN_ZERO_WIDTH_REGEX = /[\u200B\u200E\u200F\u202A-\u202E\u2060-\u2064\uFEFF\uFFFC]/g;

/**
 * Normalizes any Unicode string to canonical NFC form, standardizes line endings,
 * and removes broken zero-width copy-paste artifacts while preserving Bengali ZWNJ/ZWJ.
 */
export function normalizeUnicodeText(input: string): string {
  if (!input) return '';
  return input
    .replace(/\r\n?/g, '\n')
    .replace(BROKEN_ZERO_WIDTH_REGEX, '')
    .normalize('NFC');
}

/**
 * Converts AI LaTeX delimiters copied from ChatGPT, Gemini, Claude, or DeepSeek:
 * - Block math: \[ ... \] -> $$ ... $$
 * - Inline math: \( ... \) -> $ ... $
 * Protects fenced code blocks (```...```) and inline code (`...`) from modification.
 */
export function convertAILaTeXDelimiters(input: string): string {
  if (!input) return '';

  // Split by fenced code blocks and inline code so code literals are untouched
  const codeBlockRegex = /(```[\s\S]*?```|`[^`\n]+`)/g;
  const parts = input.split(codeBlockRegex);

  return parts
    .map((part, index) => {
      // Odd indices are matched code blocks / inline code spans
      if (index % 2 === 1) return part;

      let processed = part;

      // Convert block LaTeX \[ ... \] to $$ ... $$
      processed = processed.replace(/\\\[([\s\S]*?)\\\]/g, (_match, inner: string) => {
        const trimmed = inner.trim();
        return `\n$$\n${trimmed}\n$$\n`;
      });

      // Convert inline LaTeX \( ... \) to $ ... $
      processed = processed.replace(/\\\(([\s\S]*?)\\\)/g, (_match, inner: string) => {
        const trimmed = inner.trim();
        return `$${trimmed}$`;
      });

      return processed;
    })
    .join('');
}

/**
 * Cleans and normalizes AI-pasted content:
 * - Normalizes Unicode to NFC & preserves ZWNJ/ZWJ
 * - Converts \[...\] and \(...\) LaTeX delimiters to $$...$$ and $...$
 * - Repairs AI-pasted GFM tables that have accidental blank lines between rows
 * - Collapses excessive 4+ blank lines into clean paragraph breaks
 */
export function smartCleanAIPaste(rawText: string): string {
  if (!rawText) return '';

  let text = normalizeUnicodeText(rawText);
  text = convertAILaTeXDelimiters(text);

  // Repair GFM tables where AI paste inserted an empty line between table rows
  const lines = text.split('\n');
  const cleanedLines: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const current = lines[i];
    const prev = cleanedLines.length > 0 ? cleanedLines[cleanedLines.length - 1] : '';
    const next = i + 1 < lines.length ? lines[i + 1] : '';

    const isTableRow = (line: string) => {
      const t = line.trim();
      return t.startsWith('|') && t.endsWith('|') && t.length > 2;
    };

    // Skip spurious blank line sandwiched between two Markdown table rows
    if (current.trim() === '' && isTableRow(prev) && isTableRow(next)) {
      continue;
    }

    cleanedLines.push(current);
  }

  return cleanedLines.join('\n').replace(/\n{4,}/g, '\n\n\n');
}

/**
 * Prepares Markdown content right before rendering with ReactMarkdown + remark-gfm + remark-math + remark-breaks.
 */
export function prepareMarkdownForRender(rawText: string): string {
  if (!rawText) return '';
  const normalized = smartCleanAIPaste(rawText);

  const lines = normalized.split('\n');
  let inCodeFence = false;
  let inMathBlock = false;

  return lines
    .map((line) => {
      const trimmed = line.trim();

      if (trimmed.startsWith('```')) {
        inCodeFence = !inCodeFence;
        return line;
      }
      if (trimmed === '$$') {
        inMathBlock = !inMathBlock;
        return line;
      }
      if (inCodeFence || inMathBlock) {
        return line;
      }

      if (
        /^(#{1,6}\s|[-*+]\s|\d+\.\s|>\s|\||---|\*\*\*|___)/.test(trimmed) ||
        trimmed === ''
      ) {
        return line;
      }

      const leadingMatch = line.match(/^( {2,}|\t+)/);
      if (leadingMatch) {
        const indent = leadingMatch[0].replace(/\t/g, '    ').replace(/ /g, '\u00A0');
        return indent + line.slice(leadingMatch[0].length);
      }

      return line;
    })
    .join('\n');
}

export interface TextMetrics {
  wordCount: number;
  charCount: number;
  byteSize: number;
  readingTimeMinutes: number;
}

const utf8Encoder = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;

/**
 * Fast, single-pass text metrics calculator (supports Bengali, English, symbols, and emojis).
 */
export function computeTextMetrics(text: string): TextMetrics {
  if (!text) {
    return { wordCount: 0, charCount: 0, byteSize: 0, readingTimeMinutes: 0 };
  }

  const trimmed = text.trim();
  const wordCount = trimmed === '' ? 0 : trimmed.split(/\s+/).length;
  const charCount = text.length;
  const byteSize = utf8Encoder
    ? utf8Encoder.encode(text).byteLength
    : unescape(encodeURIComponent(text)).length;
  const readingTimeMinutes = wordCount === 0 ? 0 : Math.max(1, Math.ceil(wordCount / 180));

  return {
    wordCount,
    charCount,
    byteSize,
    readingTimeMinutes,
  };
}

/**
 * Computes combined metrics across an array of NoteSections without allocating a giant concatenated string.
 */
export function computeSectionsMetrics(sections: NoteSection[]): TextMetrics {
  let wordCount = 0;
  let charCount = 0;
  let byteSize = 0;

  for (let i = 0; i < sections.length; i++) {
    const sec = sections[i];
    const titleMetrics = computeTextMetrics(sec.title || '');
    const contentMetrics = computeTextMetrics(sec.content || '');
    wordCount += titleMetrics.wordCount + contentMetrics.wordCount;
    charCount += contentMetrics.charCount;
    byteSize += titleMetrics.byteSize + contentMetrics.byteSize;
  }

  const readingTimeMinutes = wordCount === 0 ? 0 : Math.max(1, Math.ceil(wordCount / 180));
  return { wordCount, charCount, byteSize, readingTimeMinutes };
}

/**
 * Extracts a structured Table of Contents (সূচিপত্র) from all sections and Markdown headings (# to ####).
 */
export function extractTocEntries(sections: NoteSection[]): TocEntry[] {
  const entries: TocEntry[] = [];

  sections.forEach((sec, sIdx) => {
    const secTitle = (sec.title || '').trim() || `অনুচ্ছেদ ${sIdx + 1}`;
    entries.push({
      id: `toc-sec-${sec.id}`,
      text: secTitle,
      level: 0,
      sectionId: sec.id,
      sectionIndex: sIdx,
    });

    if (!sec.content) return;

    const lines = sec.content.split('\n');
    let inCodeFence = false;
    let hIdx = 0;

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('```')) {
        inCodeFence = !inCodeFence;
        continue;
      }
      if (inCodeFence) continue;

      const headingMatch = trimmed.match(/^(#{1,4})\s+(.+)$/);
      if (headingMatch) {
        const level = headingMatch[1].length;
        const rawHeading = headingMatch[2]
          .replace(/[*_`~]/g, '')
          .trim();
        if (rawHeading) {
          entries.push({
            id: `toc-sec-${sec.id}-h-${hIdx}`,
            text: rawHeading,
            level,
            sectionId: sec.id,
            sectionIndex: sIdx,
            headingIndex: hIdx,
          });
          hIdx++;
        }
      }
    }
  });

  return entries;
}

function escapeRegExp(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Counts occurrences of a search query across all note sections.
 */
export function findMatchesInSections(
  sections: NoteSection[],
  query: string,
  caseSensitive = false
): { totalMatches: number; matchesBySection: Record<string, number> } {
  const normalizedQuery = normalizeUnicodeText(query);
  if (!normalizedQuery) {
    return { totalMatches: 0, matchesBySection: {} };
  }

  const flags = caseSensitive ? 'g' : 'gi';
  const regex = new RegExp(escapeRegExp(normalizedQuery), flags);
  let totalMatches = 0;
  const matchesBySection: Record<string, number> = {};

  for (const sec of sections) {
    const titleMatches = (normalizeUnicodeText(sec.title || '').match(regex) || []).length;
    const contentMatches = (normalizeUnicodeText(sec.content || '').match(regex) || []).length;
    const count = titleMatches + contentMatches;
    matchesBySection[sec.id] = count;
    totalMatches += count;
  }

  return { totalMatches, matchesBySection };
}

/**
 * Performs Find & Replace across note sections (either all occurrences or first occurrence).
 */
export function replaceInSections(
  sections: NoteSection[],
  findText: string,
  replaceText: string,
  options?: {
    caseSensitive?: boolean;
    replaceAll?: boolean;
    targetSectionId?: string;
  }
): { sections: NoteSection[]; replacedCount: number } {
  const normalizedFind = normalizeUnicodeText(findText);
  const normalizedReplace = normalizeUnicodeText(replaceText);

  if (!normalizedFind) {
    return { sections, replacedCount: 0 };
  }

  const caseSensitive = options?.caseSensitive ?? false;
  const replaceAll = options?.replaceAll ?? true;
  const targetSectionId = options?.targetSectionId;

  let replacedCount = 0;
  let singleReplacedDone = false;

  const updatedSections = sections.map((sec) => {
    if (targetSectionId && sec.id !== targetSectionId) {
      return sec;
    }
    if (!replaceAll && singleReplacedDone) {
      return sec;
    }

    const flags = (caseSensitive ? '' : 'i') + (replaceAll ? 'g' : '');
    const regex = new RegExp(escapeRegExp(normalizedFind), flags);

    let newTitle = normalizeUnicodeText(sec.title || '');
    let newContent = normalizeUnicodeText(sec.content || '');

    if (replaceAll) {
      const titleMatches = (newTitle.match(regex) || []).length;
      if (titleMatches > 0) {
        newTitle = newTitle.replace(regex, normalizedReplace);
        replacedCount += titleMatches;
      }
      const contentMatches = (newContent.match(regex) || []).length;
      if (contentMatches > 0) {
        newContent = newContent.replace(regex, normalizedReplace);
        replacedCount += contentMatches;
      }
    } else {
      if (regex.test(newContent)) {
        newContent = newContent.replace(regex, normalizedReplace);
        replacedCount += 1;
        singleReplacedDone = true;
      } else if (regex.test(newTitle)) {
        newTitle = newTitle.replace(regex, normalizedReplace);
        replacedCount += 1;
        singleReplacedDone = true;
      }
    }

    return {
      ...sec,
      title: newTitle,
      content: newContent,
    };
  });

  return { sections: updatedSections, replacedCount };
}

/**
 * Deterministic 4-digit PIN hashing & verification for Note PIN Lock (পিন লক).
 */
export function hashPin(pin: string): string {
  const clean = pin.trim();
  let hash = 2166136261;
  const salted = `cloudnote-pin-v1:${clean}`;
  for (let i = 0; i < salted.length; i++) {
    hash ^= salted.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `pin_${(hash >>> 0).toString(16).padStart(8, '0')}`;
}

export function verifyPin(inputPin: string, storedHash?: string | null): boolean {
  if (!storedHash) return true;
  if (storedHash.startsWith('pin_')) {
    return hashPin(inputPin) === storedHash;
  }
  return inputPin.trim() === storedHash.trim();
}

/**
 * Derives a safe, deterministic, Firestore-rules-compliant userId (`^[a-zA-Z0-9_\-]+$`, max 128 chars)
 * from an email address so that the same email always maps to the same isolated workspace.
 */
export function deriveUserIdFromEmail(email: string): string {
  const clean = email.trim().toLowerCase();
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < clean.length; i++) {
    const code = clean.charCodeAt(i);
    h1 ^= code;
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= code + i;
    h2 = Math.imul(h2, 0x85ebca6b);
  }
  const slug = clean
    .replace(/[^a-z0-9]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 32);
  const hex1 = (h1 >>> 0).toString(16).padStart(8, '0');
  const hex2 = (h2 >>> 0).toString(16).padStart(8, '0');
  return `usr_${slug || 'account'}_${hex1}${hex2}`;
}

/**
 * Deterministic salted password hash & verification for Account Vault authentication.
 */
export function hashAccountPassword(email: string, password: string): string {
  const normalizedEmail = email.trim().toLowerCase();
  const payload = `cloudnote-auth-v2:${normalizedEmail}:${password}`;
  let h1 = 2166136261;
  let h2 = 374761393;
  let h3 = 668265263;
  for (let i = 0; i < payload.length; i++) {
    const c = payload.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 16777619);
    h2 = Math.imul(h2 ^ (c + i), 3266489917);
    h3 = Math.imul(h3 ^ (c * 31), 2246822519);
  }
  return `pw_${(h1 >>> 0).toString(16).padStart(8, '0')}_${(h2 >>> 0)
    .toString(16)
    .padStart(8, '0')}_${(h3 >>> 0).toString(16).padStart(8, '0')}`;
}

export function verifyAccountPassword(
  email: string,
  password: string,
  storedHash: string
): boolean {
  if (!storedHash || !password) return false;
  return hashAccountPassword(email, password) === storedHash;
}
