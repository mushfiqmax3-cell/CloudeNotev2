# CloudNote Studio — Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants & Master Source of Truth

1. **Strict Tenant Isolation (`users/{userId}`)**:
   - Every user's profile (`/users/{userId}`), notes (`/users/{userId}/notes/{noteId}`), and note chunks (`/users/{userId}/notes/{noteId}/note_chunks/{chunkId}`) belong exclusively to `request.auth.uid == userId`.
   - No authenticated user may read, list, create, update, or delete another user's profile, notes, or chunks.
2. **Relational Sync (Master Gate)**:
   - A `NoteChunkDoc` at `/users/{userId}/notes/{noteId}/note_chunks/{chunkId}` cannot be read, created, or updated unless the parent `/users/{userId}/notes/{noteId}` exists (or is created in the same atomic batch via `existsAfter`) and belongs to `request.auth.uid == userId`.
3. **Immutable Identity & Creation Fields**:
   - On `UserProfileDoc` updates, `uid` is immutable (`incoming().uid == existing().uid`).
   - On `NoteDoc` updates, `id`, `userId`, and `createdAt` are strictly immutable.
   - On `NoteChunkDoc` updates, `id`, `noteId`, and `userId` are strictly immutable.
4. **Anti-Update-Gap & Shadow Field Prevention**:
   - Every `create` and `update` operation enforces `isValidUserProfile`, `isValidNoteDoc`, or `isValidNoteChunkDoc` with strict `keys().hasAll(...)` and `keys().hasOnly(...)` plus explicit `affectedKeys().hasOnly(...)` action gates on updates.
5. **Query Enforcer on List Operations**:
   - Every `allow list` rule checks `isSignedIn() && request.auth.uid == userId && resource.data.userId == request.auth.uid` (or `resource.data.uid == request.auth.uid`) without any `get()` or `exists()` calls inside `list`.

---

## 2. The "Dirty Dozen" Adversarial Payloads

1. **Payload 1 (Unauthenticated Write)**: `auth = null`, creating `/users/user_1/notes/note_1` -> `PERMISSION_DENIED`.
2. **Payload 2 (Cross-Tenant Note Hijack)**: `auth.uid = 'attacker_1'`, creating `/users/victim_1/notes/note_1` -> `PERMISSION_DENIED`.
3. **Payload 3 (Identity Spoofing in Payload)**: `auth.uid = 'user_1'`, creating `/users/user_1/notes/note_1` with `userId: 'victim_1'` -> `PERMISSION_DENIED`.
4. **Payload 4 (Shadow/Ghost Field Injection on Create)**: `auth.uid = 'user_1'`, creating `/users/user_1/notes/note_1` with extra key `isAdmin: true` -> `PERMISSION_DENIED`.
5. **Payload 5 (Shadow Field Injection on Update)**: `auth.uid = 'user_1'`, updating `/users/user_1/notes/note_1` with extra key `role: 'superuser'` -> `PERMISSION_DENIED`.
6. **Payload 6 (Immutable `createdAt` Tampering on Update)**: `auth.uid = 'user_1'`, updating `/users/user_1/notes/note_1` with modified `createdAt` -> `PERMISSION_DENIED`.
7. **Payload 7 (Immutable `userId` Transfer on Update)**: `auth.uid = 'user_1'`, updating `/users/user_1/notes/note_1` with `userId: 'user_2'` -> `PERMISSION_DENIED`.
8. **Payload 8 (ID Poisoning / Regex Violation)**: `auth.uid = 'user_1'`, creating `/users/user_1/notes/bad$id` or mismatched `id != noteId` -> `PERMISSION_DENIED`.
9. **Payload 9 (Value Poisoning / Oversized Title)**: `auth.uid = 'user_1'`, updating `/users/user_1/notes/note_1` with a 1,000-character `title` (> 500 max) -> `PERMISSION_DENIED`.
10. **Payload 10 (Unbounded Tag Array Injection)**: `auth.uid = 'user_1'`, creating `/users/user_1/notes/note_1` with 60 tags (> 50 max) or non-string first element -> `PERMISSION_DENIED`.
11. **Payload 11 (Orphaned Chunk Creation without Parent Note)**: `auth.uid = 'user_1'`, creating `/users/user_1/notes/nonexistent_note/note_chunks/chunk_0` when parent note does not exist -> `PERMISSION_DENIED`.
12. **Payload 12 (PII Cross-User Profile Read)**: `auth.uid = 'attacker_1'`, reading `/users/victim_1` containing email -> `PERMISSION_DENIED`.
