import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const rulesPath = path.resolve(process.cwd(), 'firestore.rules');
const rulesContent = fs.readFileSync(rulesPath, 'utf8');

const ID_REGEX = /^[a-zA-Z0-9_\-]+$/;

interface AuthContext {
  uid: string;
}

function isValidId(id: unknown): id is string {
  return typeof id === 'string' && id.length >= 1 && id.length <= 128 && ID_REGEX.test(id);
}

const NOTE_KEYS = [
  'id',
  'title',
  'category',
  'subCategory',
  'content',
  'contentSnippet',
  'sections',
  'tags',
  'isFavorite',
  'isDeleted',
  'deletedAt',
  'pinHash',
  'isLocked',
  'isChunked',
  'chunkCount',
  'byteSize',
  'wordCount',
  'createdAt',
  'updatedAt',
  'userId',
  'fontFamily',
];

function evaluateNoteWrite(
  op: 'create' | 'update',
  auth: AuthContext | null,
  pathUserId: string,
  pathNoteId: string,
  incoming: Record<string, unknown>,
  existing?: Record<string, unknown>
): 'ALLOWED' | 'PERMISSION_DENIED' {
  if (!auth || auth.uid !== pathUserId) return 'PERMISSION_DENIED';
  if (!isValidId(pathUserId) || !isValidId(pathNoteId)) return 'PERMISSION_DENIED';

  const keys = Object.keys(incoming);
  if (keys.length !== NOTE_KEYS.length || !NOTE_KEYS.every((k) => keys.includes(k))) {
    return 'PERMISSION_DENIED';
  }

  if (incoming.id !== pathNoteId || !isValidId(incoming.id)) return 'PERMISSION_DENIED';
  if (incoming.userId !== pathUserId || incoming.userId !== auth.uid || !isValidId(incoming.userId)) {
    return 'PERMISSION_DENIED';
  }
  if (typeof incoming.title !== 'string' || incoming.title.length < 1 || incoming.title.length > 500) {
    return 'PERMISSION_DENIED';
  }
  if (
    typeof incoming.category !== 'string' ||
    incoming.category.length < 1 ||
    incoming.category.length > 120
  ) {
    return 'PERMISSION_DENIED';
  }
  if (typeof incoming.subCategory !== 'string' || incoming.subCategory.length > 120) {
    return 'PERMISSION_DENIED';
  }
  if (typeof incoming.content !== 'string' || incoming.content.length > 2000) {
    return 'PERMISSION_DENIED';
  }
  if (typeof incoming.contentSnippet !== 'string' || incoming.contentSnippet.length > 2000) {
    return 'PERMISSION_DENIED';
  }
  if (!Array.isArray(incoming.sections) || incoming.sections.length > 200) {
    return 'PERMISSION_DENIED';
  }
  if (
    !Array.isArray(incoming.tags) ||
    incoming.tags.length > 50 ||
    (incoming.tags.length > 0 &&
      (typeof incoming.tags[0] !== 'string' || incoming.tags[0].length > 60))
  ) {
    return 'PERMISSION_DENIED';
  }
  if (typeof incoming.isFavorite !== 'boolean' || typeof incoming.isDeleted !== 'boolean') {
    return 'PERMISSION_DENIED';
  }
  if (
    typeof incoming.createdAt !== 'string' ||
    incoming.createdAt.length < 10 ||
    incoming.createdAt.length > 64
  ) {
    return 'PERMISSION_DENIED';
  }
  if (
    typeof incoming.updatedAt !== 'string' ||
    incoming.updatedAt.length < 10 ||
    incoming.updatedAt.length > 64
  ) {
    return 'PERMISSION_DENIED';
  }
  if (
    typeof incoming.fontFamily !== 'string' ||
    !['sans', 'serif', 'hind', 'tiro', 'mono'].includes(incoming.fontFamily)
  ) {
    return 'PERMISSION_DENIED';
  }

  if (op === 'update') {
    if (!existing) return 'PERMISSION_DENIED';
    if (
      incoming.id !== existing.id ||
      incoming.userId !== existing.userId ||
      incoming.createdAt !== existing.createdAt
    ) {
      return 'PERMISSION_DENIED';
    }
  }

  return 'ALLOWED';
}

function makeValidNotePayload(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    id: 'note_1',
    title: 'কোয়ান্টাম বলবিদ্যা নোট',
    category: 'বিজ্ঞান ও গণিত',
    subCategory: 'পদার্থবিজ্ঞান',
    content: 'সংক্ষিপ্ত স্নিপেট',
    contentSnippet: 'সংক্ষিপ্ত স্নিপেট',
    sections: [{ id: 'sec-1', title: 'ভূমিকা', content: 'মূল পাঠ্য' }],
    tags: ['পদার্থবিজ্ঞান'],
    isFavorite: false,
    isDeleted: false,
    deletedAt: null,
    pinHash: null,
    isLocked: false,
    isChunked: false,
    chunkCount: 0,
    byteSize: 120,
    wordCount: 15,
    createdAt: '2026-10-17T08:00:00.000Z',
    updatedAt: '2026-10-17T09:00:00.000Z',
    userId: 'user_1',
    fontFamily: 'sans',
    ...overrides,
  };
}

test('Firestore rules file contains all Eight Pillars and required invariants', () => {
  assert.ok(rulesContent.includes("rules_version = '2';"));
  assert.ok(rulesContent.includes('match /{document=**}'));
  assert.ok(rulesContent.includes('allow read, write: if false;'));
  assert.ok(rulesContent.includes('function isValidNoteDoc'));
  assert.ok(rulesContent.includes('function isValidNoteChunkDoc'));
  assert.ok(rulesContent.includes('function isValidUserProfile'));
  assert.ok(rulesContent.includes('affectedKeys().hasOnly'));
});

test('Dirty Dozen Payload 1-12 all return PERMISSION_DENIED', () => {
  const base = makeValidNotePayload();

  // 1. Unauthenticated Write
  assert.equal(evaluateNoteWrite('create', null, 'user_1', 'note_1', base), 'PERMISSION_DENIED');

  // 2. Cross-Tenant Note Hijack
  assert.equal(
    evaluateNoteWrite('create', { uid: 'attacker_1' }, 'user_1', 'note_1', base),
    'PERMISSION_DENIED'
  );

  // 3. Identity Spoofing in Payload
  assert.equal(
    evaluateNoteWrite(
      'create',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ userId: 'victim_1' })
    ),
    'PERMISSION_DENIED'
  );

  // 4. Shadow/Ghost Field Injection on Create
  assert.equal(
    evaluateNoteWrite(
      'create',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ isAdmin: true })
    ),
    'PERMISSION_DENIED'
  );

  // 5. Shadow Field Injection on Update
  assert.equal(
    evaluateNoteWrite(
      'update',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ role: 'superuser' }),
      base
    ),
    'PERMISSION_DENIED'
  );

  // 6. Immutable createdAt Tampering on Update
  assert.equal(
    evaluateNoteWrite(
      'update',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ createdAt: '2099-01-01T00:00:00.000Z' }),
      base
    ),
    'PERMISSION_DENIED'
  );

  // 7. Immutable userId Transfer on Update
  assert.equal(
    evaluateNoteWrite(
      'update',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ userId: 'user_2' }),
      base
    ),
    'PERMISSION_DENIED'
  );

  // 8. ID Poisoning / Regex Violation
  assert.equal(
    evaluateNoteWrite(
      'create',
      { uid: 'user_1' },
      'user_1',
      'bad$id!',
      makeValidNotePayload({ id: 'bad$id!' })
    ),
    'PERMISSION_DENIED'
  );

  // 9. Value Poisoning / Oversized Title (> 500 chars)
  assert.equal(
    evaluateNoteWrite(
      'update',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ title: 'ক'.repeat(505) }),
      base
    ),
    'PERMISSION_DENIED'
  );

  // 10. Unbounded Tag Array Injection (> 50 tags)
  assert.equal(
    evaluateNoteWrite(
      'create',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ tags: Array.from({ length: 55 }, (_, i) => `tag-${i}`) })
    ),
    'PERMISSION_DENIED'
  );

  // 11. Non-string Tag Element Poisoning
  assert.equal(
    evaluateNoteWrite(
      'create',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ tags: [12345] })
    ),
    'PERMISSION_DENIED'
  );

  // 12. Invalid Font Family Enum
  assert.equal(
    evaluateNoteWrite(
      'create',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ fontFamily: 'comic-sans-hacked' })
    ),
    'PERMISSION_DENIED'
  );

  // Positive control: Valid owner create & update succeed
  assert.equal(evaluateNoteWrite('create', { uid: 'user_1' }, 'user_1', 'note_1', base), 'ALLOWED');
  assert.equal(
    evaluateNoteWrite(
      'update',
      { uid: 'user_1' },
      'user_1',
      'note_1',
      makeValidNotePayload({ title: 'আপডেটেড শিরোনাম' }),
      base
    ),
    'ALLOWED'
  );
});
